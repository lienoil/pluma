<?php

namespace Comment\Models;

use Pluma\Models\Model;
use Pluma\Models\User;
use Pluma\Models\Course;
use Pluma\Support\Traits\Ownable;
use Pluma\Support\Traits\Searchable;
use Illuminate\Database\Eloquent\SoftDeletes;

class Comment extends Model
{
    // use SoftDeletes;
	use Ownable, Searchable;

    public function post()
    {
    	return $this->belongsto(Post::class);
    }

    public function user()
    {
    	return $this->belongsTo(\Pluma\Models\User::class);
    }

    public function authors()
    {
        //
    }

    public function course()
    {
        return $this->belongsTo(\Pluma\Models\Course::class);
    }
}