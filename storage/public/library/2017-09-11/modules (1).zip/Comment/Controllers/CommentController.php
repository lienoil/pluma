<?php
namespace Comment\Controllers;

// use Pluma\Controllers\Controller;
use Comment\Models\Comment;
use Illuminate\Http\Request;
use Comment\Requests\CommentRequest;
use Pluma\Controllers\AdminController as Controller;
use Pluma\Controllers\AdminController as BaseController;

use Post\Controllers\PostController;
use Post\Models\Post;

class CommentController extends Controller
{

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        return view('Comment::index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request, $post_id)
    {
        $comment = new Comment();
        $comment->parent_id = $request->input('parent_id');
        $comment->user()->associate(auth()->user());
        $user = User::find($request->input('user_id'));
        $course = Course::find($request->input('course_id'));
        $comment->user()->associate($user);
        $comment->comment = $request->input('comment');
        $comment->save();

        return response()->json( $request->input('comment') );

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        return view('Comment::show');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @return \Illuminate\Http\Response
     */

    public function trash()
    {
        $resource = Comment::onlyTrashed()->paginate();
        // $resources = Comment::onlyTrashed()->paginate(config("settings.pagination_count", $this->pagination_count));

        return view("Comment::trash")->with(compact('resources'));
    }
}