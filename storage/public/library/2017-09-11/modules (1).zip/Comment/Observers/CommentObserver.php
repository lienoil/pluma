<?php

namespace Comment\Observers;

use Comment\Models\Comment;
use Pluma\Models\Ownership;
use Illuminate\Http\Request;

class CommentObserver
{
	/**
	 * Listen to the Comment view event.
	 *
	 * @param  Illuminate\Http\Request  $request
	 * @return void
	 */
	public function view()
    {

    }

	/**
	 * Listen to the Comment created event.
	 *
	 * @param  Comment  $comment
	 * @return void
	 */
	public function created(Comment $comment)
	{
		session()->flash('title', $comment->title);
		session()->flash('icon', "fa fa-check");
		session()->flash('message', "Comment successfully saved");
		session()->flash('type', 'info');
	}

	/**
	 * Listen to the Comment updated event.
	 *
	 * @param  Comment  $comment
	 * @return void
	 */
	public function updated(Comment $comment)
	{
		session()->flash('name', $comment->name);
		session()->flash('icon', "fa fa-check");
		session()->flash('message', "Comment successfully updated");
		session()->flash('type', 'info');
	}

	/**
	 * Listen to the Comment deleted event.
	 *
	 * @param  Comment  $comment
	 * @return void
	 */
	public function deleted(Comment $comment)
	{
		session()->flash('name', $comment->name);
		session()->flash('icon', "fa fa-check");
		session()->flash('message', "Comment successfully moved to trash");
		session()->flash('type', 'info');
	}

	/**
	 * Listen to the Comment restored event.
	 *
	 * @param  Comment  $comment
	 * @return void
	 */
	public function restored(Comment $comment)
	{
		session()->flash('name', $comment->name);
		session()->flash('icon', "fa fa-check");
		session()->flash('message', "Comment successfully restored");
		session()->flash('type', 'info');
	}
}