<?php

return [
	// 'comment' => [
	// 	'name' => 'comment',
	// 	'slug' => 'comments',
	// 	'parent' => true,
	// 	'order' => 10,
	// 	'icon' => [
	// 		'class' => 'fa fa-certificate',
	// 		'tag' => 'i',
	// 		'content' => '&nbsp;',
	// 	], // or can be a html string e.g. <span class="fa fa-edit">&nbsp;</span>
	// 	'label' => [
	// 		'singular_name' => 'Comment',
	// 		'plural_name' => 'Comments',
	// 	],
	// ],

	// 'view-comment' => [
	// 	'is_child_of' => 'comment',
	// 	'name' => 'view-comment',
	// 	'slug' => '/',
	// 	'order' => 1,
	// 	'icon' => '', // or can be a html string e.g. <span class="fa fa-edit">&nbsp;</span>
	// 	'label' => [
	// 		'singular_name' => 'All Comment',
	// 		'plural_name' => 'All Comments',
	// 	],
	// ],

	// 'trash-comment' => [
	// 	'is_child_of' => 'comment',
	// 	'name' => 'trash-comment',
	// 	'slug' => 'trash',
	// 	// 'before' => '<hr>',
	// 	// 'is_always_viewable' => true,
	// 	// 'order' => 2,
	// 	'icon' => [
	// 		'class' => 'fa fa-trash',
	// 		'tag' => 'i',
	// 		'content' => '&nbsp;',
	// 	],
	// 	'label' => [
	// 		'singular_name' => 'Trash',
	// 		'plural_name' => 'Trash',
	// 	],
	// ],

	// 'view-category' => [
	// 	'is_child_of' => 'comment',
	// 	'name' => 'view-category',
	// 	'slug' => 'categories',
	// 	'order' => 1,
	// 	// 'icon' => [
	// 	// 	'class' => 'fa fa-tag',
	// 	// 	'tag' => 'i',
	// 	// 	'content' => '&nbsp;',
	// 	// ], // or can be a html string e.g. <span class="fa fa-edit">&nbsp;</span>
	// 	'label' => [
	// 		'singular_name' => 'Categories',
	// 		'plural_name' => 'Categories',
	// 	],
	// ],

	// 'refresh-category' => [
	// 	'is_child_of' => 'view-category',
	// 	'name' => 'refresh-category',
	// 	'slug' => 'refresh',
	// 	'order' => 1,
	// 	// 'icon' => [
	// 	// 	'class' => 'fa fa-tag',
	// 	// 	'tag' => 'i',
	// 	// 	'content' => '&nbsp;',
	// 	// ], // or can be a html string e.g. <span class="fa fa-edit">&nbsp;</span>
	// 	'label' => [
	// 		'singular_name' => 'Refresh Category',
	// 		'plural_name' => 'Refresh Categories',
	// 	],
	// ],
];