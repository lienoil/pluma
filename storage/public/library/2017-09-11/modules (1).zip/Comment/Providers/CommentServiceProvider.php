<?php  ?><?php

namespace Comment\Providers;

use Schema;
use Comment\Models\Comment;
use Comment\Observers\CommentObserver;
use Illuminate\Support\ServiceProvider;

/**
 * CommentServiceProvider
 * The service provider for the modules. After being registered
 * it will make sure that each of the modules are properly loaded
 * i.e. with their routes, views etc.
 *
 * @author John Lioneil Dionisio <john.dionisio1@gmail.com>
 * @package Pluma
 */
class CommentServiceProvider extends ServiceProvider
{
	/**
	 * Will make sure that the required modules have been fully loaded
	 *
	 * @return void
	 */
	public function boot()
	{
		$this->observe();
	}

	/**
	 * Register the application services.
	 *
	 * @return void
	 */
	public function register()
	{
		//
	}

	/**
	 * Observable Models
	 *
	 * @return void
	 */
	public function observe()
	{
		if ( Schema::hasTable('comments') ) {
			Comment::observe( CommentObserver::class );
		}
	}
}