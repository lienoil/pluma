<?php

/*
 | --------------------------------------
 | Permissions Array
 | --------------------------------------
 |
 | Here we define our permissions that you can attach to roles.
 |
 | These permissions corresponds to a counterpart
 | route (found in <this module>/routes/<route-files>.php).
 | All permissionable routes should have a `name` (e.g. 'forums.store')
 | for the CheckRole to work.
 |
 | These routes must have the middleware 'roles' for this to work.
 */
return [
	'view-forum' => [
		'name' =>  'forums.index',
		'slug' => 'view-forum',
		'description' => 'View forums',
	],
	'show-forum' => [
		'name' => 'forums.show',
		'slug' => 'show-forum',
		'description' => 'Show a forum',
	],
	'create-forum' => [
		'name' => 'forums.create',
		'slug' => 'create-forum',
		'description' => 'Show forum form',
	],
	'store-forum' => [
		'name' => 'forums.store',
		'slug' => 'store-forum',
		'description' => 'Store the forum',
	],
	'edit-forum' => [
		'name' => 'forums.edit',
		'slug' => 'edit-forum',
		'description' => 'Edit the forum',
	],
	'update-forum' => [
		'name' => 'forums.update',
		'slug' => 'update-forum',
		'description' => 'Update the forum',
	],
	'destroy-forum' => [
		'name' =>  'forums.destroy',
		'slug' => 'destroy-forum',
		'description' => 'Destroy the forum',
	],
	'trash-forum' => [
		'name' =>  'forums.trash',
		'slug' => 'trash-forum',
		'description' => 'Trash the forum',
	],
	'restore-forum' => [
		'name' => 'forums.restore',
		'slug' => 'restore-forum',
		'description' => 'Restore the forum',
	],
	'export-forum' => [
		'name' => 'forums.export',
		'slug' => 'export-forum',
		'description' => 'Export the forum',
	],
	'import-forum' => [
		'name' => 'forums.import',
		'slug' => 'import-forum',
		'description' => 'Import the forum',
	],
];