<?php

return [
    'forum' => [
        'name' => 'forum',
        'slug' => 'forums',
        'parent' => true,
        'order' => 10,
        'icon' => [
            'class' => 'fa fa-comments-o',
            'tag' => 'i',
            'content' => '&nbsp;',
        ], // or can be a html string e.g. <span class="fa fa-edit">&nbsp;</span>
        'label' => [
            'singular_name' => 'Discussion Board',
            'plural_name' => 'Discussion Board',
        ],
    ],

    'view-forum' => [
        'is_child_of' => 'forum',
        'name' => 'view-forum',
        'slug' => '/',
        'order' => 1,
        'icon' => '', // or can be a html string e.g. <span class="fa fa-edit">&nbsp;</span>
        'label' => [
            'singular_name' => 'All Discussion',
            'plural_name' => 'All Discussions',
        ],
    ],

    'create-forum' => [
        'is_child_of' => 'forum',
        'name' => 'create-forum',
        'slug' => 'create',
        'order' => 1,
        'icon' => '', // or can be a html string e.g. <span class="fa fa-edit">&nbsp;</span>
        'label' => [
            'singular_name' => 'Create Discussion',
            'plural_name' => 'Create Discussion',
        ],
    ],

    'trash-forum' => [
        'is_child_of' => 'forum',
        'name' => 'trash-forum',
        'slug' => 'trash',
        'icon' => [
            'class' => 'fa fa-trash',
            'tag' => 'i',
            'content' => '&nbsp;',
        ],
        'label' => [
            'singular_name' => 'Trash',
            'plural_name' => 'Trash',
        ],
    ],
];