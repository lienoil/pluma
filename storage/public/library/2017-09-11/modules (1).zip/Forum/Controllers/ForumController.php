<?php
namespace Forum\Controllers;

use Forum\Models\Forum;
use Illuminate\Http\Request;
use Forum\Requests\ForumRequest;
use Pluma\Models\Category;
use Pluma\Controllers\AdminController as Controller;

class ForumController extends Controller
{

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $categories = Category::all();
        $resources = Forum::filter()->paginate(config("settings.pagination_count", $this->pagination_count));
        $trashed = Forum::onlyTrashed();
        $filtered = count ( $request->all() ) ? true : false;

        return view("Forum::forums.index")->with(compact('resources', 'trashed', 'filtered', 'categories'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        // Suppliments
        // $categories = Category::pluck('name', 'id');

        // Load
        return view("Forum::forums.create");

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(ForumRequest $request)
    {
        $forum = new Forum();
        $forum->title = $request->input('title');
        $forum->slug = $request->input('slug');
        $forum->body = $request->input('body');
        $forum->save();

        $forum->categories()->attach( $request->input('categories') );
        return back();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $resource = Forum::findOrFail($id);

        return view("Forum::forums.show")->with(compact('resource'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $resource = Forum::findOrFail($id);
        // $categories = Category::pluck('name', 'id');

        return view("Forum::forums.edit")->with(compact('resource'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $forum = Forum::findOrFail ( $id );
        $forum->title = $request->input('title');
        $forum->slug = $request->input('slug');
        $forum->body = $request->input('body');


        $forum->categories()->sync( $request->input('categories') ? $request->input('categories') : []);
        $forum->save();

        return back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $forum = Forum::findOrFail($id);
        $forum->delete();

        return back();
    }

    /**
     * Display a listing of the trashed resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function trash()
    {
        // Find
        $resource = Forum::onlyTrashed()->paginate();
        $resources = Forum::onlyTrashed()->paginate(config("settings.pagination_count", $this->pagination_count));

        //Load
        return view("Forum::forums.trash")->with(compact('resources'));
    }

    /**
     * Restore the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function restore($id)
    {
        $resource = Forum::onlyTrashed()->findOrFail($id);
        $resource->restore();

        return back();
    }

    /**
     * Restore a specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function delete($id)
    {
        $forum = Forum::onlyTrashed()->findOrFail( $id );
        $forum->forceDelete();

        return back();
    }
}