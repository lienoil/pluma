<?php

Route::get('forums/trash', 'Forum\Controllers\ForumController@trash')->name('forums.trash');
Route::post('forums/{forum}/restore', 'Forum\Controllers\ForumController@restore')->name('forums.restore');
Route::delete('forums/{forum}/delete', 'Forum\Controllers\ForumController@delete')->name('forums.delete');
Route::resource('forums', 'Forum\Controllers\ForumController');