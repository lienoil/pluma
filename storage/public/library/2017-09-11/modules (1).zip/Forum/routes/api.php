<?php

Route::group(['prefix' => 'api', 'as' => 'api', 'middleware' => ['api']], function () {
	Route::post('forums/lists', '\Forum\Controllers\API\ForumController@index')->name('forums.lists');
	Route::post('forums/store', '\Forum\Controllers\API\ForumController@index')->name('forums.store');
});