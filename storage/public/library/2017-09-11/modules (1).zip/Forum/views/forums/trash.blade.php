@extends("Pluma::layouts.admin")

@section("content")

    <div class="container-fluid">
        <div class="row">
            <div class="col-md-9">
                <div class="box no-border">
                    <div class="box-header with-border">
                        <h3 class="box-title">Threads</h3>
                    </div>
                    <div class="box-body">
                        @if ( $resources->isEmpty() )
                            <div class="text-center">
                                <p class="text-muted">No trashed discussions found.</p>
                            </div>
                        @endif
                        <ul class="collection m-b-0">
                            @foreach ( $resources as $i => $resource )
                                <li class="collection-item avatar m-b-1">
                                    <div class="m-b-1">
                                        <img src="{{ auth()->user()->avatar }}" alt="" class="circle">
                                        <a href=""><span class="title bold-weight">{{ $resource->title }}</span></a>
                                        <span class="new badge text-uppercase">solved</span>
                                         <br>
                                        <span class="label label-danger">PSDM</span>
                                        <span class="text-dark-gray">• {{ $resource->created }}</span>
                                        <span class="text-dark-gray">• by <a class="text-green" href="#!">{{ $resource->owner->displayname }}</a></span>
                                        <div class="m-t-2">
                                            <p>{{ $resource->body }}</p>
                                        </div>

                                        <div class="m-t-2">
                                           <form class="right" action="{{ route('forums.delete', $resource->id) }}" method="POST">
                                                {{ csrf_field() }}
                                                {{ method_field('DELETE') }}
                                                <button type="submit" class="delete-btn text-red" data-toggle="tooltip" data-placement="top" title="Delete permanently"><i class="fa fa-times"></i> Delete Permanently</button>
                                            </form>

                                            <form action="{{ route('forums.restore', $resource->id) }}" method="POST">
                                                {{ csrf_field() }}
                                                <button type="submit" class="delete-btn text-red"><i class="fa fa-refresh"></i> Restore</button>
                                            </form>
                                        </div>
                                    </div>
                                </li>
                            @endforeach
                        </ul>
                    </div>

                    <div class="card-footer">
                        <div class="pull-right">
                            @include("Pluma::partials.pagination", compact('resources'))
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                @include("Yggdrasil::widgets.forum-filter")

                <div class="text-center">
                    <a class="waves-effect btn btn-yellow waves-light" href="{{ route('forums.create') }}">Create</a>
                </div>
            </div>
        </div>
    </div>
@endsection

@push("pre-footer")
    @include("Pluma::partials.alert")
@endpush

@push('css')
    <style>
        .collection {
            border: none !important;
        }

        .collection .collection-item:hover {
            background: transparent !important;
        }

        .collection .collection-item:last-child {
            border-bottom: none !important;
            margin-bottom: 0 !important;
        }

        .bold-weight {
            font-weight: 500;
        }

        .m-b-1 {
            margin-bottom: 10px !important;
        }

        .m-b-2 {
            margin-bottom: 20px !important;
        }

        .m-t-2 {
            margin-top: 20px !important;
        }

        .collection-item .new:after {
            content: '' !important;
        }

        .badge .badge-danger {
            color: #D8462A;
        }

        .badge .badge-success {
            color: #5cb85c;
        }

        .font-14 {
            font-size: 14px !important;
        }

        .float-right {
            float: right !important;
        }
    </style>
@endpush