@extends("Pluma::layouts.admin")

@section("content")
    @include("Pluma::partials.alert")

    <div class="container-fluid">
        <div class="row">
            <div class="col-md-9">
                <div class="box no-border">
                    <div class="box-header with-border">
                        <h3 class="box-title">Threads</h3>
                    </div>
                    <div class="box-body">
                        @if ( $resources->isEmpty() )
                            <div class="text-center">
                                <p class="text-muted">No discussions found.</p>
                            </div>
                        @endif

                        <ul class="collection m-b-0">
                            @foreach ( $resources as $i => $resource )
                                <li class="collection-item avatar m-b-1">
                                    <div class="m-b-1">
                                        <img src="{{ auth()->user()->avatar }}" alt="" class="circle">
                                        <a href="{{ route('forums.show', $resource->id) }}"><span class="title bold-weight">{{ $resource->title }}</span></a>
                                        {{-- <span class="new badge text-uppercase">solved</span> --}}
                                        <br>

                                        <div class="pull-left">
                                            <span class="label label-danger">
                                                @if ( !$resource->categories->isEmpty() )
                                                    @foreach ( $resource->categories as $category )
                                                       {{ $category->name }}
                                                    @endforeach
                                                @endif
                                            </span>
                                        </div>

                                        <span class="text-dark-gray">• {{ $resource->created }}</span>
                                        <span class="text-dark-gray">• by <a class="text-green" href="{{ route('forums.index', ['author' => $resource->owner->id]) }}">{{ $resource->owner->displayname }}</a></span>

                                        <div class="m-t-2">
                                            <p>{{ $resource->body }}</p>
                                        </div>

                                        <div class="m-t-2">
                                            <form class="form-inline right" action="{{ route('forums.destroy', $resource->id) }}" method="POST">
                                                {{ csrf_field() }}
                                                {{ method_field('DELETE') }}
                                                <button type="submit" class="delete-btn text-red" data-toggle="tooltip" data-placement="top" title="Delete" data-swal='{"title":"Are you sure?","text":"{{ $resource->title }} page will be moved to Trash.","type":"warning","showCancelButton":"true","confirmButtonText":"Remove"}'><i class="fa fa-trash"></i> Delete</button>
                                            </form>

                                            <a class="delete-btn m-t-1 text-red" data-toggle="tooltip" data-placement="top" title="edit" href="{{ route('forums.edit', $resource->id) }}"><i class="fa fa-pencil font-14"></i> Edit</a>
                                        </div>
                                    </div>
                                </li>
                            @endforeach
                        </ul>
                    </div>
                    <div class="card-footer">
                        <div class="pull-right">
                            @include("Pluma::partials.pagination", compact('resources'))
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                @include("Yggdrasil::widgets.forum-filter")
                <div class="text-center">
                    <a class="waves-effect btn btn-yellow waves-light" href="{{ route('forums.create') }}">Create</a>
                </div>
            </div>
        </div>
    </div>
@endsection

{{-- @push('pre-footer')
    @include("Pluma::partials.alert")
@endpush
 --}}
@push('css')
    <style>
        .collection {
            border: none !important;
        }

        .collection .collection-item:hover {
            background: transparent !important;
        }

        .collection .collection-item:last-child {
            border-bottom: none !important;
            margin-bottom: 0 !important;
        }

        .bold-weight {
            font-weight: 500;
        }

        .m-b-1 {
            margin-bottom: 10px !important;
        }

        .m-b-2 {
            margin-bottom: 20px !important;
        }

        .m-t-2 {
            margin-top: 20px !important;
        }

        .collection-item .new:after {
            content: '' !important;
        }

        .badge-danger {
            color: #D8462A !important;
        }

        .badge-success {
            color: #5cb85c !important;
        }

        .font-14 {
            font-size: 14px !important;
        }
    </style>
@endpush