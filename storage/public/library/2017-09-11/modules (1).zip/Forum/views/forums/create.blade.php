@extends("Pluma::layouts.admin")

@section("content")

	<div class="container-fluid">
		<form action="{{ route('forums.store') }}" method="POST">
			<div class="row">
				<div class="col-md-9">
					{{ csrf_field() }}
					<div class="card">
						<div class="box-header with-border">
							<h3 class="box-title">New Discussion</h3>
						</div>
						<div class="box-body">
							<div class="input-field">
								<input name="title" type="text" class="validate inputfield m-b-0" value="{{ old('title') }}" data-slugger>
								<label class="inputtext slug-form" for="title">Title</label>
								@include("Pluma::errors.span", ['field' => 'title'])
							</div>

							<div class="input-field">
								<span class="slug inline">{{ url('/') }}/</span>
								<input name="slug" type="text" class="validate slug-form" readonly value="{{ old('slug') }}" placeholder="url-slug">
								@include("Pluma::errors.span", ['field' => 'slug'])
							</div>

							<div class="input-field m-t-3">
			                	<textarea name="body" class="materialize-textarea inputfield textarea-rows">{{ old('body') }}</textarea>
			                	<label for="textarea1"  class="inputtext">Message</label>
			                	@include("Pluma::errors.span", ['field' => 'body'])
			              	</div>
			            </div>
					</div>
				</div>

				<div class="col-md-3">
					@include("Pluma::partials.widget-saving")
					@include("Pluma::widgets.categories")
				</div>
			</div>
		</form>
	</div>
@endsection

@push("pre-footer")
    @include("Pluma::partials.alert")
@endpush


@push('css')
	<style>
		.select-dropdown {
			margin-bottom: 0 !important;
		}
	</style>
@endpush

@push('js')
	<script src="{{ assets('Pluma/vendor/jquery-slugger/dist/jquery.slugger.min.js') }}"></script>
	<script src="//cdn.ckeditor.com/4.7.1/standard/ckeditor.js"></script>
	{{-- <script src="//cdn.ckeditor.com/4.5.7/standard/ckeditor.js"></script> --}}
	<script>
		$(document).ready(function() {
		    $('select').material_select();
	 	});


        // CKEDITOR.replace( 'messageArea' );
	</script>
@endpush