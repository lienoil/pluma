@extends("Pluma::layouts.admin")
@section("content")
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-9">
				<div class="box no-border card">
					<div class="box-header">
						<h3 class="box-title">{{ $resource->title }}</h3>
						<p class="m-t-1">
							<span class="text-dark-gray">{{ $resource->created }}</span>
                        	<span class="text-dark-gray m-t-0">• by <a class="text-green" href="{{ route('forums.index', ['author' => $resource->owner->id]) }}">{{ $resource->owner->displayname }}</a></span>
						</p>
					</div>


                    {{-- thread --}}
					<div class="box-body p-t-0">
						<p>
							{{ $resource->body }}
						</p>
						<div class="p-2">
                            <form class="form-inline right" action="{{ route('forums.destroy', $resource->id) }}" method="POST">
                                {{ csrf_field() }}
                                {{ method_field('DELETE') }}
                                <button type="submit" class="delete-btn text-red" data-toggle="tooltip" data-placement="top" title="delete" data-swal='{"title":"Are you sure?","text":"{{ $resource->title }} page will be moved to Trash.","type":"warning","showCancelButton":"true","confirmButtonText":"Remove"}'><i class="fa fa-trash-o"></i> Delete</button>
                            </form>

                            <a class="delete-btn m-t-1 text-red" data-toggle="tooltip" data-placement="top" title="edit" href="{{ route('forums.edit', $resource->id) }}"><i class="fa fa-pencil font-14"></i> Edit</a>
                        </div>

                        {{-- replies --}}
						<div class="box-body top-border">
							{{-- <ul class="collection m-b-0">
                                <li class="collection-item avatar m-b-1 tline">
                                    <div class="m-b-1">
                                        <img src="{{ auth()->user()->avatar }}" alt="" class="circle">
                                        <a href="{{ route('forums.index', ['author' => $resource->owner->id]) }}">
                                            <span class="title bold-weight">{{ $resource->owner->displayname }}</span>
                                        </a>
                                        <span class="text-dark-gray{{ $resource->created }}"></span>

                                        <p for="name" class="control-label m-t-2">sample reply to a thread</p>
                                        <textarea class="materialize-textarea m-t-1 input-medium inputfield" style="display:none;"></textarea>

                                        <div width="20" class="controls-edit reveal-btn reveal-position">
                                            <a class="delete-btn text-red p-r-1" href="#" data-toggle="tooltip" data-placement="bottom" title="Edit" onclick="edit(this);"><i class="font-14 fa fa-pencil"></i></a>
                                            <a class="delete-btn right" data-toggle="tooltip" data-placement="top" title="Delete" data-swal='{"title:"}'>
                                                <i class="fa fa-trash-o"></i>
                                            </a>
                                        </div>

                                        <div class="controls-update" style="display:none;">
                                            <a class="waves-effect waves-yellow btn btn-default" href="#" onclick="update(this);">Update</a>
                                        </div>
                                    </div>
                                </li>

                                <li class="collection-item avatar m-b-1">
                                    <div class="m-b-1 tline">
                                        <img src="{{ auth()->user()->avatar }}" alt="" class="circle">
                                        <div class="input-field s12">
                                            <textarea id="textarea1" class="materialize-textarea m-t-1 inputfield">{{ old('body') }}</textarea>
                                            <label class="inputtext" for="comment">Reply to a message</label>
                                        </div>

                                        <div class="text-right">
                                            <a class="waves-effect waves-light btn btn-yellow" href="#">Post a Reply</a>
                                        </div>
                                    </div>
                                </li>
                        	</ul> --}}

                            <div id="comments-container"></div>
						</div>
					</div>
				</div>
			</div>
        </div>
	</div>
@endsection

@push('css')
    <link rel="stylesheet" href="{{ assets('Pluma/vendor/jquery-comments/css/jquery-comments.css') }}">

    <style>
        /* start of jquery-comments*/
            .spinner {
                display: none !important;
            }

            .btn-danger {
                background: #D8462A !important;
                color: #fff !important;
            }

            .wrapper {
                background: #fff !important;
            }

            .content {
                min-height: 0 !important;
            }

            .edit {
                position: static !important;
            }
        /*end of jquery-comments*/

        .card-image a img {
            border-radius: 50% !important;
            padding: 20px;
        }

        .top-border {
            border-top: 2px dotted #d8d8d8;
        }

        .collection {
            border: none !important;
        }

        .collection .collection-item:hover {
            background: transparent !important;
        }

        .collection .collection-item:last-child {
            border-bottom: none !important;
            margin-bottom: 0 !important;
        }

        .bold-weight {
            font-weight: 500;
        }

        .m-b-1 {
            margin-bottom: 10px !important;
        }

        .m-b-2 {
            margin-bottom: 20px !important;
        }

        .m-t-2 {
            margin-top: 20px !important;
        }

        .collection-item .new:after {
            content: '' !important;
        }

        .badge .badge-danger {
            color: #D8462A;
        }

        .badge .badge-success {
            color: #5cb85c;
        }

        .font-14 {
            font-size: 14px !important;
        }

        .reveal-position {
            position: absolute;
            top: 0;
            right: 0;
        }

        .text-center {
            text-align: center;
        }

        /*editable*/
        .edit {
            display:block;
            cursor: pointer;
            position: relative;
            left: 100px;

        }
    </style>
@endpush

@push('js')
    <script src="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/js/bootstrap.min.js"></script>

    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery.textcomplete/1.8.0/jquery.textcomplete.js"></script>
    <script type="text/javascript" src="{{ assets('Pluma/vendor/jquery-comments/js/jquery-comments.js') }}"></script>
    <script type="text/javascript" src="{{ assets('Pluma/vendor/jquery-comments/js/jquery-comments.js') }}"></script>


    <script>
        // jquery-comments
            $(function() {
                var saveComment = function(data) {
                    // Convert pings to human readable format
                    $(data.pings).each(function(index, id) {
                        var user = usersArray.filter(function(user){return user.id == id})[0];
                        data.content = data.content.replace('@' + id, '@' + user.fullname);
                    });

                    return data;
                }

                $('#comments-container').comments({
                    profilePictureURL: '{{ auth()->user()->avatar }}',
                    currentUserId: 1,
                    roundProfilePictures: true,
                    textareaRows: 1,
                    enableAttachments: false,
                    enableHashtags: true,
                    enablePinging: true,
                    getUsers: function(success, error) {
                        setTimeout(function() {
                            success(usersArray);
                        }, 500);
                    },
                    getComments: function(success, error) {
                        setTimeout(function() {
                            $.ajax({
                                url: "{{ route('api.comments.lists') }}",
                                type: 'POST',
                                success: function (data) {
                                    success(data);
                                }
                             });
                        }, 500);
                    },
                    postComment: function(data, success, error) {
                        // console.log(data);
                        setTimeout(function() {
                            $.ajax({
                                url: "{{ route('api.comments.store') }}",
                                type: 'POST',
                                data: data,
                                success: function (data) {
                                    console.log(data, "success");
                                },
                                error:function(ww) {
                                    // console.log(ww, "error");
                                    log();
                                },
                            });
                            success(saveComment(data));
                            // console.log(data, "test-data");
                        }, 500);
                    },
                    deleteComment: function(data, success, error) {
                        setTimeout(function() {
                            success(data);
                        }, 500);
                    },
                    upvoteComment: function(data, success, error) {
                        setTimeout(function() {
                            success(data);
                        }, 500);
                    },
                    uploadAttachments: function(dataArray, success, error) {
                        setTimeout(function() {
                            success(dataArray);
                        }, 500);
                    },
                });
            });
        // end of jquery-comments

        // function edit(element) {
        //     var parent = $(element).parent().parent();
        //     var placeholder = $(parent).find('p').text();
        //     $(parent).find('p').hide();
        //     var textarea = $(parent).find('textarea');
        //     var edit = $(parent).find('.controls-edit');
        //     var update = $(parent).find('.controls-update');
        //     $(textarea).show();
        //     $(edit).hide();
        //     $(update).show();
        // }

        // function update(element) {
        //     var parent = $(element).parent().parent();
        //     var placeholder = $(parent).find('p').text();
        //     $(parent).find('p').show();
        //     var textarea = $(parent).find('textarea');
        //     var edit = $(parent).find('.controls-edit');
        //     var update = $(parent).find('.controls-update');
        //     $(textarea).hide();
        //     $(edit).show();
        //     $(update).hide();
        //     $(parent).find('p').text($(textarea).val());
        // }
    </script>
@endpush