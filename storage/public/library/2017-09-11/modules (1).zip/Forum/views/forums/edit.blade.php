@extends("Pluma::layouts.admin")

@section("content")
	@include("Pluma::partials.alert")

	<div class="container-fluid">
		<form action="{{ route('forums.update', $resource->id) }}" method="POST">
    		{{ csrf_field() }}
            {{ method_field('PUT') }}
			<div class="row">
				<div class="col-md-9">
					<div class="card">
						<div class="box-header with-border">
							<h3 class="box-title">Edit Discussion</h3>
						</div>
						<div class="box-body">
							<div class="input-field">
								<input name="title" type="text" class="validate inputfield m-b-0" value="{{ $resource->title }}" data-slugger>
								<label class="inputtext slug-form" for="title">Title</label>
								@include("Pluma::errors.span", ['field' => 'title'])
							</div>

							<div class="input-field">
								<span class="slug inline">{{ url('/') }}/</span>
								<input name="slug" type="text" class="validate slug-form" readonly value="{{ $resource->slug }}" placeholder="url-slug">
								@include("Pluma::errors.span", ['field' => 'slug'])
							</div>

							<div class="input-field m-t-3">
			                	<textarea name="body" class="materialize-textarea inputfield textarea-rows">{{ $resource->body }}</textarea>
			                	<label for="textarea1"  class="inputtext">Message</label>
			                	@include("Pluma::errors.span", ['field' => 'body'])
			              	</div>
			            </div>
					</div>
				</div>

				<div class="col-md-3">
					@include("Pluma::partials.widget-saving", ['label' => 'Update'])
					@include("Pluma::widgets.categories", ['is_updating' => 1])
				</div>
			</div>
		</form>
	</div>
@endsection

@push('css')
	<style>
		.select-dropdown {
			margin-bottom: 0 !important;
		}
	</style>
@endpush

@push('js')
	<script src="{{ assets('Pluma/vendor/jquery-slugger/dist/jquery.slugger.min.js') }}"></script>
	<script>
		$(document).ready(function() {
            $('.select').material_select();
        });
	</script>
@endpush