<?php

namespace Forum\Observers;

use Forum\Models\Forum;
use Pluma\Models\Ownership;
use Illuminate\Http\Request;

class ForumObserver
{
	/**
	 * Listen to the Forum view event.
	 *
	 * @param  Illuminate\Http\Request  $request
	 * @return void
	 */
	public function view()
    {

    }

	/**
	 * Listen to the Forum created event.
	 *
	 * @param  Forum  $forum
	 * @return void
	 */
	public function created(Forum $forum)
	{
		$ownership = new Ownership();
		$ownership->created_by = auth()->user()->id;
		$ownership->updated_by = auth()->user()->id;
		$ownership->user()->associate( auth()->user() );
		$ownership->save();

		$forum->ownerships()->save( $ownership );

		session()->flash('title', $forum->title);
		session()->flash('icon', "fa fa-check");
		session()->flash('message', "Forum successfully saved");
		session()->flash('type', 'info');
	}

	/**
	 * Listen to the Forum updated event.
	 *
	 * @param  Forum  $forum
	 * @return void
	 */
	public function updated(Forum $forum)
	{
		session()->flash('name', $forum->name);
		session()->flash('icon', "fa fa-check");
		session()->flash('message', "Forum successfully updated");
		session()->flash('type', 'info');
	}

	/**
	 * Listen to the Forum deleted event.
	 *
	 * @param  Forum  $forum
	 * @return void
	 */
	public function deleted(Forum $forum)
	{
		session()->flash('name', $forum->name);
		session()->flash('icon', "fa fa-check");
		session()->flash('message', "Forum successfully moved to trash");
		session()->flash('type', 'info');
	}

	/**
	 * Listen to the Forum restored event.
	 *
	 * @param  Forum  $forum
	 * @return void
	 */
	public function restored(Forum $forum)
	{
		session()->flash('name', $forum->name);
		session()->flash('icon', "fa fa-check");
		session()->flash('message', "Forum successfully restored");
		session()->flash('type', 'info');
	}
}