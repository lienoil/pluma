<?php

namespace Yggdrasil\Controllers\Front;

use Illuminate\Http\Request;
use Pluma\Controllers\AdminController as Controller;
use Yggdrasil\Models\Course;
use Yggdrasil\Models\Content;
use Yggdrasil\Models\Student;
use Yggdrasil\Requests\CourseRequest;
use Form\Support\Builder\FormBuilder;

class CourseController extends Controller
{
    public function showCourseList(Request $request)
    {
        $resources = Course::paginate();

        return view("Yggdrasil::courses.front.list")->with(compact('resources'));
    }

    public function showSingleCourse($slug = null, $id = null)
    {
        $resource = Course::whereSlug($slug)->orWhere('code', $slug)->first();

        return view("Yggdrasil::courses.show")->with(compact('resource'));
    }

    /**
     * Show the content of the Course
     *
     * @param  string $slug
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function showSingleCourseContent($slug = null, $id = null)
    {
        $course = Course::whereSlug($slug)->orWhere('code', $slug)->firstOrFail();
        $resource = $course->contents()->findOrFail($id)->collected();

        // if ($resource->type == get_class(new \Form\Models\Form)) {
        //     $resource->form = FormBuilder::make($resource);
        // }

        return view("Yggdrasil::courses.contents.single")
            ->with(compact('id', 'course', 'resource'));
    }

    public function showSingleCourseContentXXX($slug = null, $id = null)
    {
        $student = Student::findOrFail(auth()->user()->id);

        $course = $student->courses()->whereSlug($slug)->orWhere('code', $slug)->first();
        $contents = isset($course->collected_contents) ? $course->collected_contents : null;
        $resource = $course->contents()->findOrFail($id)->collected();
        $resource->viewable = $course->students->contains(auth()->user()->id);

        if ($resource->type == get_class(new \Form\Models\Form)) {
            $resource->form = FormBuilder::make($resource);
        }

        return view("Yggdrasil::courses.front.single-content")
            ->with(compact('id', 'course', 'resource', 'contents'));
    }
}
