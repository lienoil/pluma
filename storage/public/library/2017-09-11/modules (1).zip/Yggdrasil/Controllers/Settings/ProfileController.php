<?php
namespace Yggdrasil\Controllers\Settings;

use Pluma\Controllers\AdminController as Controller;
use Illuminate\Http\Request;
use Pluma\Models\User;

class ProfileController extends Controller
{

    /**
     * Show the form for creating a new resource.
     *
     * @param  String $handle
     * @return \Illuminate\Http\Response
     */
    public function getProfileForm($handle)
    {
        $resource = User::whereUsername( $handle )->first();

        return view("Yggdrasil::profile.show")->with( compact('resource') );
    }
}