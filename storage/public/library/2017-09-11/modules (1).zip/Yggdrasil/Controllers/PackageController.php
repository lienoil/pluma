<?php
namespace Yggdrasil\Controllers;

use Chumper\Zipper\Zipper;
use Illuminate\Http\Request;
use Pluma\Controllers\AdminController as Controller;
use Yggdrasil\Models\Package;
use Yggdrasil\Requests\PackageRequest;
use File;
use Storage;

class PackageController extends Controller
{

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $resources = Package::all();
        $trashed = Package::onlyTrashed();
        $filtered = count( $request->all() ) ? true : false;

        return view("Yggdrasil::packages.index")->with( compact('resources', 'trashed', 'filtered') );
    }

    /**
     * Show the upload form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view("Yggdrasil::packages.upload");
    }

    public function show($id)
    {
        $resource = Package::findOrFail( $id );

        return view("Yggdrasil::packages.show")->with( compact('resource') );
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $resource = Package::findOrFail( $id );

        return view("Yggdrasil::packages.edit")->with( compact('resource') );
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(PackageRequest $request, $id)
    {
        $package = Package::findOrFail( $id );
        $package->name = $request->input('name');
        $package->description = $request->input('description');
        $package->save();

        return back();
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(PackageRequest $request)
    {
        // Find
        $path = config("settings.yggdrasil.package_storage_path", 'app/packages');

        // Commit
        if ($request->file('upload') && $file = $request->file('upload')) {
            $filename = date("mdHisY-") . $file->getClientOriginalName();
            $fullFilename = "$path/$filename";
            $file->move(storage_path("$path"), $filename);
            // $imsmanifestFile = $this->parse(storage_path("$path/$package"), 'imsmanifest.xml');

            // Find
            $package = new Package();
            $package->name = $request->input('name');
            $package->description = $request->input('description');
            $package->originalname = $filename;
            $package->pathname = $fullFilename;
            $package->url = $fullFilename;
            $package->size = $file->getClientSize();
            $package->mime = File::mimeType(storage_path($fullFilename));
            $package->type = get_class(new Package);
            $package->save();

            // Unpack
            $this->unpack(storage_path($path), $fullFilename, $package->name);
        }

        // Back
        return back();
    }

    public function upload(PackageRequest $request, $uploadDir = 'uploads', $prefixDir = 'app/public')
    {
        return response()->json( $request->all() );
    }

    public function unpack($path, $fullFilename, $name)
    {
        if (File::exists(storage_path($fullFilename))) {
            $zipper = new Zipper;
            $zipper->zip(storage_path($fullFilename))->extractTo("$path/$name");
        }
    }

    public function parse($path)
    {
        // if SCORM
        $manifestFile = "$path/imsmanifest.xml";
        if (File::exists($manifestFile)) {
            //
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        // Find
        $package = Package::findOrFail( $id );

        // Commit
        $package->delete();

        // Back
        return back();
    }

    /**
     * Display a listing of the trashed resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function trash()
    {
        $resources = Package::onlyTrashed()->paginate();

        return view("Yggdrasil::packages.trash")->with( compact('resources') );
    }

    /**
     * Restore the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function restore($id)
    {
        $package = Package::onlyTrashed()->findOrFail( $id );
        $package->restore();

        return back();
    }

    /**
     * Delete the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function delete($id)
    {
        $package = Package::onlyTrashed()->findOrFail( $id );

        if ( File::exists( storage_path( $package->pathname ) ) ) {
            File::delete( storage_path( $package->pathname ) );
            File::deleteDirectory( storage_path("app/packages/{$package->name}") );
        }

        $package->forceDelete();

        return back();
    }

    public function explorer()
    {
        $resources = Package::all();

        return view("Yggdrasil::packages.explorer")->with( compact('resources') );
    }
}