<?php
namespace Yggdrasil\Controllers\Content;

use Pluma\Controllers\AdminController as Controller;
use Illuminate\Http\Request;
use Yggdrasil\Models\Content;
use Yggdrasil\Requests\ContentRequest;

class ContentController extends Controller
{

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $resources = Content::paginate();
        $filtered = count( $request->all() ) ? true : false;

        foreach ($resources as $resource) {
            dd($resource->thumbnail);
        }

        return view("Yggdrasil::contents.index")->with( compact('resources', 'filtered') );
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view("Yggdrasil::contents.create");
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(ContentRequest $request)
    {
        $content = new Content();
        $content->title = $request->input('title');
        $content->slug = $request->input('slug');
        $content->code = $request->input('code');
        $content->description = $request->input('description');
        $content->interactive = $request->input('interactive');
        $content->save();

        return back();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $resource = Content::findOrFail( $id );

        return view("Yggdrasil::contents.edit")->with( compact('resource') );
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $content = Content::findOrFail( $id );
        $content->title = $request->input('title');
        $content->slug = $request->input('slug');
        $content->code = $request->input('code');
        $content->interactive = $request->input('interactive');
        $content->description = $request->input('description');
        $content->save();

        return back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}