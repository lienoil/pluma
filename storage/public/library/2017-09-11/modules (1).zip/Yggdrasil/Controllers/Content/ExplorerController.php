<?php
namespace Yggdrasil\Controllers\Content;

use Illuminate\Http\Request;
use Pluma\Controllers\Library\ExplorerController as Controller;
use Pluma\Models\Library;
use Yggdrasil\Models\Package;
use Form\Models\Form;

class ExplorerController extends Controller
{

    public function showExplorerForm($mime = null)
    {
        $packages = Package::all();
        $forms = \Form\Models\Form::all();
        $survey = \Survey\Models\Survey::all();

        return view("Yggdrasil::contents.explorer")->with( compact('packages', 'forms', 'survey') );
    }
}