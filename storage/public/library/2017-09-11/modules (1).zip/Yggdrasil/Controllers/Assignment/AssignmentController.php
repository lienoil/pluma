<?php

namespace Yggdrasil\Controllers\Assignment;

use Illuminate\Http\Request;
use Pluma\Controllers\AdminController as Controller;
use Yggdrasil\Models\Assignment;
use Yggdrasil\Models\Content;
use Yggdrasil\Requests\AssignmentRequest;

class AssignmentController extends Controller
{

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        // Find
        $resources = Assignment::paginate();

        // Load
        return view("Yggdrasil::assignments.index")->with(compact('resources'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        // Find
        $contents = Content::with('package')->get()->pluck('package.name', 'id');

        // Load
        return view("Yggdrasil::assignments.create")->with(compact('contents'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(AssignmentRequest $request)
    {
        $assignment = new Assignment();
        $assignment->name = $request->input('name');
        $assignment->description = $request->input('description');
        $assignment->content()->associate(Content::find($request->input('content_id')));
        $assignment->save();

        $file = $request->file('upload') ? $request->file('upload') : null;
        if (null !== $file) {
            $storagePath = config("settings.yggdrasil.assignments.storage_path", 'app/public/assignments');
            $storagePath .= "/{$assignment->id}-".str_slug($assignment->name);
            $filePath = $storagePath . "/" . $file->getClientOriginalName();

            if ($file->move(storage_path($storagePath), $file->getClientOriginalName())) {
                $assignment->upload = $filePath;
                $assignment->save();
            }
        }

        return back();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        // Find
        $resource = Assignment::findOrFail($id);
        $contents = Content::with('package')->get()->pluck('package.name', 'id');

        // Load
        return view("Yggdrasil::assignments.edit")->with(compact('resource', 'contents'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(AssignmentRequest $request, $id)
    {
        $assignment = Assignment::findOrFail($id);
        $assignment->name = $request->input('name');
        $assignment->description = $request->input('description');
        $assignment->content()->associate(Content::find($request->input('content_id')));
        $assignment->save();

        $file = $request->file('upload') ? $request->file('upload') : null;
        if (null !== $file) {
            $storagePath = config("settings.yggdrasil.assignments.storage_path", 'app/public/assignments');
            $storagePath .= "/{$assignment->id}-".str_slug($assignment->name);
            $filePath = $storagePath . "/" . $file->getClientOriginalName();

            if ($file->move(storage_path($storagePath), $file->getClientOriginalName())) {
                $assignment->upload = $filePath;
                $assignment->save();
            }
        }

        return back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $assignment = Assignment::findOrFail($id);
        $assignment->delete();

        return back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function trash()
    {
        $resources = Assignment::onlyTrashed()->paginate(config("settings.pagination_count", $this->pagination_count));

        return view("Yggdrasill::assignments.trash")->with(compact('resources'));
    }
}
