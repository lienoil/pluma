<?php

namespace Yggdrasil\Controllers;

use Form\Models\Form;
use Illuminate\Http\Request;
use Pluma\Controllers\AdminController as Controller;
use Pluma\Models\Category;
use Yggdrasil\Models\Content;
use Yggdrasil\Models\Course;
use Yggdrasil\Models\Package;
use Yggdrasil\Requests\CourseRequest;

class CourseController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        // Find
        $resources = Course::paginate();
        $trashed = Course::onlyTrashed();
        $filtered = count($request->all()) ? true : false;

        // Load
        return view("Yggdrasil::courses.index")->with(compact('resources', 'trashed', 'filtered'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        // Suppliments
        $contents = collect([
            get_class(new Package) => Package::pluck('name', 'id'),
            get_class(new Form) => Form::pluck('name', 'id'),
        ]);

        // Load
        return view("Yggdrasil::courses.create")->with(compact('contents'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(CourseRequest $request)
    {
        // Find
        $course = new Course();
        $course->title = $request->input('title');
        $course->slug = $request->input('slug');
        $course->code = $request->input('code');
        $course->img = $request->input('img');
        $course->description = $request->input('description');

        // Commit
        $course->save();

        // Suppliment
        # Contents
        foreach ($request->input('contents') as $contents) {
            // New
            $content = new Content($contents);
            $content->package()->associate(Package::find($contents['package_id']));
            $content->sort = $contents['sort'];

            // Commit
            $course->contents()->save($content);
        }

        # Categories
        $course->categories()->attach($request->input('categories'));

        // Back
        return back();
    }

    /**
     * Display the specified resource.
     *
     * @param  string  $code
     * @return \Illuminate\Http\Response
     */
    public function show($code)
    {
        // Find
        $resource = Course::whereCode($code)->orWhere('slug', $code)->first();

        // Load
        return view("Yggdrasil::courses.show")->with(compact('resource'));
    }

     /**
     * Display the specified resource.
     *
     * @param  string  $code
     * @return \Illuminate\Http\Response
     */
    public function register($id)
    {
        // return view("Yggdrasil::courses.register")->with(compact('resources'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        // Find
        $resource = Course::findOrFail($id);

        // Suppliments
        $contents = collect([
            get_class(new Package) => Package::pluck('name', 'id'),
            get_class(new Form) => Form::pluck('name', 'id'),
        ]);

        // Back
        return view("Yggdrasil::courses.edit")->with(compact('resource', 'contents'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(CourseRequest $request, $id)
    {
        // Find
        $course = Course::findOrFail($id);
        $course->title = $request->input('title');
        $course->slug = $request->input('slug');
        $course->code = $request->input('code');
        $course->img = $request->input('img');
        $course->description = $request->input('description');

        // Commit
        $course->save();

        // Suppliment
        # Contents
        $course->contents()->delete();
        foreach ($request->input('contents') as $contents) {
            // New
            $content = Content::findOrNew(isset($contents['id']) ? $contents['id'] : null);
            $content->package()->dissociate();
            $content->package()->associate(Package::find($contents['package_id']));
            $content->sort = $contents['sort'];

            // Commit
            $course->contents()->save($content);
        }

        # Categories
        $course->categories()->sync($request->input('categories') ? $request->input('categories') : []);

        // Back
        return back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        // Find
        $course = Course::findOrFail($id);

        // Commit
        $course->delete();

        // Back
        return back();
    }

    /**
     * Display a listing of the trashed resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function trash()
    {
        // Find
        $resources = Course::onlyTrashed()->paginate();
        $resources = Course::onlyTrashed()->paginate(config("settings.pagination)count", $this->pagination_count));

        // Load
        return view("Yggdrasil::courses.trash")->with(compact('resources'));
    }

    /**
     * Restore the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function restore($id)
    {
        // Find
        $course = Course::onlyTrashed()->findOrFail($id);

        // Commit
        $course->restore();

        // Back
        return back();
    }

    /**
     * Delete the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function delete($id)
    {
        // Find
        $course = Course::onlyTrashed()->findOrFail($id);

        // Commit
        $course->contents()->delete();
        $course->forceDelete();

        // Back
        return back();
    }
}
