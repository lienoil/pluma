<?php
namespace Yggdrasil\Controllers\Course;

use Pluma\Controllers\AdminController as Controller;
use Illuminate\Http\Request;
use Yggdrasil\Models\Course;

class ContentController extends Controller
{
    /**
     * Display the specified resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function show($code, $id = null)
    {
        $resource = Course::whereCode($code)->orWhere('slug', $code)->first();
        $resource = $resource->contents()->find($id);

        return view("Yggdrasil::courses.contents.show")->with(compact('resource', 'id'));
    }
}
