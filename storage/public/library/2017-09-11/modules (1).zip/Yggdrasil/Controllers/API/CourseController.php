<?php

namespace Yggdrasil\Controllers\API;

use Illuminate\Http\Request;
use Pluma\Controllers\APIController as Controller;
use Yggdrasil\Models\Content;
use Yggdrasil\Requests\ContentRequest;

class CourseController extends Controller
{
    /**
     * Initialize resource.
     *
     * @param  Request $request
     * @return Illuminate\Foundation\Http\Response
     */
    public function initialize(Request $request)
    {
        return response()->json($request);
    }

    /**
     * Save the resource.
     *
     * @param  Request $request
     * @return Illuminate\Foundation\Http\Response
     */
    public function save(Request $request)
    {
        return response()->json($request);
    }
}
