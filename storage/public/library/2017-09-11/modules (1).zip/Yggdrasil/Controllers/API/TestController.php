<?php

namespace Yggdrasil\Controllers\API;

class TestController
{
    public function initialize($string = "")
    {
        $results = [
            'status' => 200,
            'message' => 'Lorem ipsum dolor sit amet.',
            'title' => 'Lorem Ipsum Dolor',
        ];

        return response()->json($results);
    }

    public function mystery() {
        return [
            'success' => 'Test',
            'description' => 'Test description',
        ];
    }
}