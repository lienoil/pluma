<?php

namespace Yggdrasil\Controllers\Variable\API;

use Illuminate\Http\Request;
use Pluma\Controllers\APIController as Controller;
use Pluma\Models\User;
use Yggdrasil\Models\Content;
use Yggdrasil\Models\Course;
use Yggdrasil\Models\Courses\Variable;

class SCORMController extends Controller
{
    protected $scormCoreTotalTime = 'cmi.core.total_time';
    protected $scormCoreSessionTime = 'cmi.core.session_time';
    protected $scormCoreCredit = 'cmi.core.credit';
    protected $scormCoreLessonStatus = 'cmi.core.lesson_status';
    protected $scormCoreEntry = 'cmi.core.entry';
    protected $scormCoreExit = 'cmi.core.exit';
    protected $scormScoreRaw = 'cmi.score.raw';
    protected $scormScoreMin = 'cmi.score.min';
    protected $scormLaunchData = 'cmi.launch_data';
    protected $manifestMasteryScore = 'adlcp:masteryscore';
    protected $_lessonStatus;

    public function initialize(Request $request)
    {
        // $course = Course::find($request->input('course_id'));
        // return response()->json([$course]);

        # Total Time
        $totalTime = Variable::whereUserId($request->input('user'))
            ->whereCourseId($request->input('course'))
            ->whereContentId($request->input('content'))
            ->whereName($this->scormCoreTotalTime)
            ->get()
            ->first();

        // $totalTime->delete();
        if (null == $totalTime) {
            // New
            $variable = new Variable();
            $variable->name = $this->scormCoreTotalTime;
            $variable->value = '0000:00:00';
            $variable->user()->associate(User::find($request->input('user')));
            $variable->course()->associate(Course::find($request->input('course')));
            $variable->content()->associate(Content::find($request->input('content')));
            $variable->save();
        }

        // Session
        $sessionTime = Variable::whereUserId($request->input('user'))
            ->whereCourseId($request->input('course'))
            ->whereContentId($request->input('content'))
            ->whereName($this->scormCoreSessionTime)
            ->get()
            ->first();
        if (null == $sessionTime) {
            $sessionTime->delete();
            // New
            $variable = new Variable();
            $variable->name = $this->scormCoreSessionTime;
            $variable->value = '0000:00:00';
            $variable->user()->associate(User::find($request->input('user')));
            $variable->course()->associate(Course::find($request->input('course')));
            $variable->content()->associate(Content::find($request->input('content')));
            $variable->save();
        }

        # Credit
        $credit = Variable::whereUserId($request->input('user'))
            ->whereCourseId($request->input('course'))
            ->whereContentId($request->input('content'))
            ->whereName($this->scormCoreCredit)
            ->get()
            ->first();

        if (null == $credit) {
            // New
            $variable = new Variable();
            $variable->name = $this->scormCoreCredit;
            $variable->value = 'credit';
            $variable->user()->associate(User::find($request->input('user')));
            $variable->course()->associate(Course::find($request->input('course')));
            $variable->content()->associate(Content::find($request->input('content')));
            $variable->save();
        }

        # Lesson Status
        $lessonStatus = Variable::whereUserId($request->input('user'))
            ->whereCourseId($request->input('course'))
            ->whereContentId($request->input('content'))
            ->whereName($this->scormCoreLessonStatus)
            ->get()
            ->first();

        if (null == $lessonStatus) {
            // New
            $variable = new Variable();
            $variable->name = $this->scormCoreLessonStatus;
            $variable->value = 'not attempted';
            $variable->user()->associate(User::find($request->input('user')));
            $variable->course()->associate(Course::find($request->input('course')));
            $variable->content()->associate(Content::find($request->input('content')));
            $variable->save();
        }

        # Entry
        $entry = Variable::whereUserId($request->input('user'))
            ->whereCourseId($request->input('course'))
            ->whereContentId($request->input('content'))
            ->whereName($this->scormCoreEntry)
            ->first();

        if (null == $entry) {
            // New
            $variable = new Variable();
            $variable->name = $this->scormCoreEntry;
            $variable->value = 'ab initio';
            $variable->user()->associate(User::find($request->input('user')));
            $variable->course()->associate(Course::find($request->input('course')));
            $variable->content()->associate(Content::find($request->input('content')));
            $variable->save();
        }

        # adlcp:masteryscore
        $masteryScore = Variable::whereUserId($request->input('user'))
            ->whereCourseId($request->input('course'))
            ->whereContentId($request->input('content'))
            ->whereName($this->manifestMasteryScore)
            ->first();

        if (null == $masteryScore) {
            // New
            $variable = new Variable();
            $variable->name = $this->manifestMasteryScore;
            $variable->value = '70';
            $variable->user()->associate(User::find($request->input('user')));
            $variable->course()->associate(Course::find($request->input('course')));
            $variable->content()->associate(Content::find($request->input('content')));
            $variable->save();
        }

        # adlcp:datafromlms / Launch Data
        $launchData = Variable::whereUserId($request->input('user'))
            ->whereCourseId($request->input('course'))
            ->whereContentId($request->input('content'))
            ->whereName($this->scormLaunchData)
            ->first();
        if (null === $launchData) {
            // New
            $variable = new Variable();
            $variable->name = $this->scormLaunchData;
            $variable->value = ""; // empty string.
            $variable->user()->associate(User::find($request->input('user')));
            $variable->course()->associate(Course::find($request->input('course')));
            $variable->content()->associate(Content::find($request->input('content')));
            $variable->save();
        }


        return response()->json("true");
    }

    public function getValue(Request $request)
    {
        $cmiElement = $request->input('data');
        $cmiValue = "";

        switch ($cmiElement) {
            case 'cmi.core._children':
                $cmiValue = "student_id,student_name,lesson_location,credit,lesson_status,entry,score,total_time,exit,session_time";
                break;

            case 'cmi.core.student_id':
                $cmiValue = User::find($request->input('user'))->id;
                break;

            case 'cmi.core.student_name':
                $cmiValue = User::find($request->input('user'))->propername;
                break;
            case "cmi.core.score._children":
                $cmiValue = "raw";
                break;

            default:
                $variable = Variable::whereUserId($request->input('user'))
                    ->whereCourseId($request->input('course'))
                    ->whereContentId($request->input('content'))
                    ->whereName($cmiElement)
                    ->first();

                $cmiValue = isset($variable->value) ? $variable->value : "";
                break;
        }

        return response()->json($cmiValue);
    }

    public function setValue(Request $request)
    {
        $variable = Variable::whereUserId($request->input('user'))
            ->whereCourseId($request->input('course'))
            ->whereContentId($request->input('content'))
            ->whereName($request->input('name'))->get()->first();

        if ($variable) $variable->delete();

        // New
        $variable = new Variable();
        $variable->name = $request->input('name');
        $variable->value = $request->input('value');
        $variable->user()->associate(User::find($request->input('user')));
        $variable->course()->associate(Course::find($request->input('course')));
        $variable->content()->associate(Content::find($request->input('content')));
        $variable->save();

        // return response()->json([$variable]);
        return response()->json("true");
    }

    public function commit(Request $request)
    {
        $user = $request->input('user');
        $data = $request->input('data');
        dd($data);

        return response()->json($request->all());
    }

    public function finish()
    {
        # Save Total Time
        // Total Time
        $totalTime = Variable::whereUserId($request->input('user'))
            ->whereCourseId($request->input('course'))
            ->whereContentId($request->input('content'))
            ->whereName($this->scormCoreTotalTime)
            ->get()
            ->last();
        // convert total time to seconds
        $time = explode(':', (isset($totalTime->value) ? $totalTime->value : '0000:00:00') );
        $totalSeconds = $time[0]*60*60 + $time[1]*60 + $time[2];
        // Session Time
        $sessionTime = Variable::whereUserId($request->input('user'))
            ->whereCourseId($request->input('course'))
            ->whereContentId($request->input('content'))
            ->whereName($this->scormCoreSessionTime)->last();
        // convert session time to seconds
        $time = explode(':', $sessionTime->value);
        $sessionSeconds = $time[0]*60*60 + $time[1]*60 + $time[2];

        // New total Time is...
        $totalSeconds += $sessionSeconds;

        // Convert back to HH:mm:ss
        $totalHours = intval($totalSeconds/3600);
        $totalSeconds -= $totalHours * 3600;
        $totalMinutes = intval($totalSeconds/60);
        $totalSeconds -= $totalMinutes * 60;

        // reformat to comply with the SCORM data model
        $totalTime->delete();
        $totalTime = null;
        $totalTime = sprintf("%04d:%02d:%02d", $totalHours, $totalMinutes, $totalSeconds);
        // New
        $variable = new Variable();
        $variable->name = $this->scormCoreTotalTime;
        $variable->value = $totalTime;
        $variable->user()->associate(User::find($request->input('user')));
        $variable->course()->associate(Course::find($request->input('course')));
        $variable->content()->associate(Content::find($request->input('content')));
        $variable->save();

        # Entry
        $variable = Variable::whereUserId($request->input('user'))
            ->whereCourseId($request->input('course'))
            ->whereContentId($request->input('content'))
            ->whereName($this->scormCoreEntry)
            ->get()
            ->first();
        $variable ? $variable->delete() : null;

        // get the exit value
        $exit = Variable::whereUserId($request->input('user'))
            ->whereCourseId($request->input('course'))
            ->whereContentId($request->input('content'))
            ->whereName($this->scormCoreExit)
            ->get()
            ->first();

        // Then resume entry
        // New
        $variable = new Variable();
        $variable->name = $this->scormCoreEntry;
        $variable->value = null != $exit && $exit->value == 'suspend' ? 'resume' : "";
        $variable->user()->associate(User::find($request->input('user')));
        $variable->course()->associate(Course::find($request->input('course')));
        $variable->content()->associate(Content::find($request->input('content')));
        $variable->save();

        # Lesson Status
        $lessonStatus = Variable::whereUserId($request->input('user'))
            ->whereCourseId($request->input('course'))
            ->whereContentId($request->input('content'))
            ->whereName($this->scormCoreLessonStatus)
            ->get()
            ->first();

        if (null != $lessonStatus && "not attempted" == $lessonStatus->value) {
            $lessonStatus->value = 'completed';
            $lessonStatus->save();

            // Save percentage in pivot table `course_student`
            // sssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss
            // $student = $course->students()->whereStudentId($request->input('user'))->first();
            // $student->pivot->percentage = '100';
            // $student->pivot->save();
        }

        # adlcp:masteryscore
        $masteryScore = Variable::whereUserId($request->input('user'))
            ->whereCourseId($request->input('course'))
            ->whereContentId($request->input('content'))
            ->whereName($this->manifestMasteryScore)
            ->first();

        $scromScoreMin = Variable::whereUserId($request->input('user'))
            ->whereCourseId($request->input('course'))
            ->whereContentId($request->input('content'))
            ->whereName($this->scromScoreMin)
            ->first();

        if ($scromScoreMin) { // $masteryScore
            $scoreRaw = Variable::whereUserId($request->input('user'))
            ->whereCourseId($request->input('course'))
            ->whereContentId($request->input('content'))
            ->whereName($this->scormScoreRaw)
            ->get()
            ->first();

            if (null !== $scoreRaw && $scoreRaw->value >= $scromScoreMin->value) {
                $lessonStatus->value = 'completed';
            } else {
                $lessonStatus->value = 'failed';
            }
            $lessonStatus->save();
        }

        return response()->json("true");
    }
}
