<?php
namespace Yggdrasil\Controllers\Dashboard;

use Pluma\Controllers\Controller as Controller;
use Yggdrasil\Models\Course;
use Yggdrasil\Models\Enrollee;

class DashboardController extends Controller
{
    public function __construct()
    {
        $this->middleware(['web', 'auth.admin']);
    }

    public function index()
    {
        return view('Yggdrasil::dashboard.index');
    }
}