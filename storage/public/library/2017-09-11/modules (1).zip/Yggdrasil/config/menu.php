<?php

return [
	/**
	 * Courses
	 *
	 */
	'course' => [
		'name' => 'course',
		'slug' => 'courses',
		'parent' => true,
		// 'is_always_viewable' => true,
		'order' => 4,
		'icon' => [
			'class' => 'icon-books',
			'tag' => 'i',
			'content' => '&nbsp;',
		], // or can be a html string e.g. <span class="fa fa-edit">&nbsp;</span>
		'label' => [
			'singular_name' => 'Course',
			'plural_name' => 'Courses',
		],
	],
	'view-course' => [
		'is_child_of' => 'course',
		'name' => 'view-course',
		'slug' => '/',
		// 'is_always_viewable' => true,
		// 'order' => 1,
		'label' => [
			'singular_name' => 'All Course',
			'plural_name' => 'All Courses',
		],
	],
	'create-course' => [
		'is_child_of' => 'course',
		'name' => 'create-course',
		'slug' => 'create',
		// 'is_always_viewable' => true,
		// 'order' => 2,
		'label' => [
			'singular_name' => 'Create Course',
			'plural_name' => 'Create Course',
		],
	],
	'register-course' => [
		'is_child_of' => 'course',
		'name' => 'register-course',
		'slug' => 'register',
		// 'is_always_viewable' => true,
		// 'order' => 2,
		'label' => [
			'singular_name' => 'Register Course',
			'plural_name' => 'Register Course',
		],
	],
	'view-progress' => [
		'is_child_of' => 'course',
		'name' => 'view-progress',
		'slug' => 'progress',
		'label' => [
			'singular_name' => 'My Progress',
			'plural_name' => 'My Progress',
		],
	],
	'view-category' => [
		'is_child_of' => 'course',
		'name' => 'view-category',
		'slug' => 'categories',
		'icon' => [
			'class' => 'fa fa-tags',
			'tag' => 'i',
			'content' => '&nbsp;',
		],
		'label' => [
			'singular_name' => 'Category',
			'plural_name' => 'Categories',
		],
	],

	'trash-course' => [
		'is_child_of' => 'course',
		'name' => 'trash-course',
		'slug' => 'trash',
		// 'before' => '<hr>',
		// 'is_always_viewable' => true,
		// 'order' => 2,
		'icon' => [
			'class' => 'fa fa-trash',
			'tag' => 'i',
			'content' => '&nbsp;',
		],
		'label' => [
			'singular_name' => 'Trash',
			'plural_name' => 'Trash',
		],
	],

	/**
	 * Rank
	 *
	 */
	'ranking' => [
		'name' => 'ranking',
		'slug' => 'ranking',
		'parent' => true,
		// 'is_always_viewable' => true,
		'order' => 4,
		'icon' => [
			'class' => 'fa fa-tasks',
			'tag' => 'i',
			'content' => '&nbsp;',
		], // or can be a html string e.g. <span class="fa fa-edit">&nbsp;</span>
		'label' => [
			'singular_name' => 'Trainer&#39;s Performance',
			'plural_name' => 'Trainer&#39;s Performance',
		],
	],
	/**
	 * Package
	 *
	 */
	'package' => [
		'name' => 'package',
		'slug' => 'packages',
		'parent' => true,
		// 'is_always_viewable' => true,
		'order' => 10,
		'icon' => [
			'class' => 'fa fa-archive',
			'tag' => 'i',
			'content' => '&nbsp;',
		], // or can be a html string e.g. <span class="fa fa-edit">&nbsp;</span>
		'label' => [
			'singular_name' => 'Package',
			'plural_name' => 'Packages',
		],
	],
	'view-package' => [
		'is_child_of' => 'package',
		'name' => 'view-package',
		'slug' => '/',
		// 'is_always_viewable' => true,
		// 'order' => 1,
		'label' => [
			'singular_name' => 'All Package',
			'plural_name' => 'All Packages',
		],
	],
	'store-package' => [
		'is_child_of' => 'package',
		'name' => 'store-package',
		'slug' => 'upload',
		// 'is_always_viewable' => true,
		// 'order' => 2,
		'label' => [
			'singular_name' => 'Upload Package',
			'plural_name' => 'Upload Package',
		],
	],
	'trash-package' => [
		'is_child_of' => 'package',
		'name' => 'trash-package',
		'slug' => 'trash',
		// 'is_always_viewable' => true,
		// 'order' => 2,
		'label' => [
			'singular_name' => 'Trash Package',
			'plural_name' => 'Trash Package',
		],
	],

	/**
	 * Assignments
	 *
	 */
	'assignment' => [
		'name' => 'assignment',
		'slug' => 'assignments',
		'parent' => true,
		// 'is_always_viewable' => true,
		'order' => 4,
		'icon' => [
			'class' => 'fa fa-edit',
			'tag' => 'i',
			'content' => '&nbsp;',
		], // or can be a html string e.g. <span class="fa fa-edit">&nbsp;</span>
		'label' => [
			'singular_name' => 'Assignment',
			'plural_name' => 'Assignments',
		],
	],
	'view-assignment' => [
		'is_child_of' => 'assignment',
		'name' => 'view-assignment',
		'slug' => '/',
		// 'is_always_viewable' => true,
		// 'order' => 1,
		'label' => [
			'singular_name' => 'All Assignment',
			'plural_name' => 'All Assignments',
		],
	],
	'create-assignment' => [
		'is_child_of' => 'assignment',
		'name' => 'create-assignment',
		'slug' => 'create',
		// 'is_always_viewable' => true,
		// 'order' => 2,
		'label' => [
			'singular_name' => 'Create Assignment',
			'plural_name' => 'Create Assignment',
		],
	],
	'trash-assignment' => [
		'is_child_of' => 'assignment',
		'name' => 'trash-assignment',
		'slug' => 'trash',
		'icon' => [
			'class' => 'fa fa-trash',
			'tag' => 'i',
			'content' => '&nbsp;',
		],
		'label' => [
			'singular_name' => 'Trash',
			'plural_name' => 'Trash',
		],
	],
];