<?php


/*
 | --------------------------------------
 | Permissions Array
 | --------------------------------------
 |
 | Here we define our permissions that you can attach to roles.
 |
 | These permissions corresponds to a counterpart
 | route (found in <this module>/routes/<route-files>.php).
 | All permissionable routes should have a `name` (e.g. 'posts.store')
 | for the CheckRole to work.
 |
 | These routes must have the middleware 'roles' for this to work.
 */

return [
    /**
     * Course Permissions
     *
     */
    'view-course' => [
        'name' =>  'courses.index',
        'slug' => 'view-course',
        'description' => 'View courses',
    ],
    'show-course' => [
        'name' => 'courses.show',
        'slug' => 'show-course',
        'description' => 'Show a course',
    ],
    'create-course' => [
        'name' => 'courses.create',
        'slug' => 'create-course',
        'description' => 'Show course form',
    ],
    'store-course' => [
        'name' => 'courses.store',
        'slug' => 'store-course',
        'description' => 'Store the course',
    ],
    'edit-course' => [
        'name' => 'courses.edit',
        'slug' => 'edit-course',
        'description' => 'Edit the course',
    ],
    'update-course' => [
        'name' => 'courses.update',
        'slug' => 'update-course',
        'description' => 'Update the course',
    ],
    'destroy-course' => [
        'name' =>  'courses.destroy',
        'slug' => 'destroy-course',
        'description' => 'Destroy the course',
    ],
    'trash-course' => [
        'name' =>  'courses.trash',
        'slug' => 'trash-course',
        'description' => 'Trash the course',
    ],
    'restore-course' => [
        'name' => 'courses.restore',
        'slug' => 'restore-course',
        'description' => 'Restore the course',
    ],
    'current-course' => [
        'name' => 'courses.current',
        'slug' => 'current-course',
        'description' => 'Show current course',
    ],
    'previous-course' => [
        'name' => 'courses.previous',
        'slug' => 'previous-course',
        'description' => 'Show previous course',
    ],
    'recommended-course' => [
        'name' => 'courses.recommended',
        'slug' => 'recommended-course',
        'description' => 'Show recommended course',
    ],
    'bookmarked-course' => [
        'name' => 'courses.bookmarked',
        'slug' => 'bookmarked-course',
        'description' => 'Show bookmarked course',
    ],

    /**
     * Category Permissions
     *
     */
    'view-category' => [
        'name' =>  'categories.index',
        'slug' => 'view-category',
        'description' => 'View categories',
    ],
    'show-category' => [
        'name' => 'categories.show',
        'slug' => 'show-category',
        'description' => 'Show a category',
    ],
    'create-category' => [
        'name' => 'categories.create',
        'slug' => 'create-category',
        'description' => 'Show categorie form',
    ],
    'store-category' => [
        'name' => 'categories.store',
        'slug' => 'store-category',
        'description' => 'Store the category',
    ],
    'edit-category' => [
        'name' => 'categories.edit',
        'slug' => 'edit-category',
        'description' => 'Edit the category',
    ],
    'update-category' => [
        'name' => 'categories.update',
        'slug' => 'update-category',
        'description' => 'Update the category',
    ],
    'destroy-category' => [
        'name' =>  'categories.destroy',
        'slug' => 'destroy-category',
        'description' => 'Destroy the category',
    ],
    'trash-category' => [
        'name' =>  'categories.trash',
        'slug' => 'trash-category',
        'description' => 'Trash the category',
    ],
    'restore-category' => [
        'name' => 'categories.restore',
        'slug' => 'restore-category',
        'description' => 'Restore the category',
    ],

    /**
     * Content Permissions
     *
     */
    'view-content' => [
        'name' =>  'contents.index',
        'slug' => 'view-content',
        'description' => 'View contents',
    ],
    'show-content' => [
        'name' => 'contents.show',
        'slug' => 'show-content',
        'description' => 'Show a content',
    ],
    'create-content' => [
        'name' => 'contents.create',
        'slug' => 'create-content',
        'description' => 'Show content form',
    ],
    'store-content' => [
        'name' => 'contents.store',
        'slug' => 'store-content',
        'description' => 'Store the content',
    ],
    'edit-content' => [
        'name' => 'contents.edit',
        'slug' => 'edit-content',
        'description' => 'Edit the content',
    ],
    'update-content' => [
        'name' => 'contents.update',
        'slug' => 'update-content',
        'description' => 'Update the content',
    ],
    'destroy-content' => [
        'name' =>  'contents.destroy',
        'slug' => 'destroy-content',
        'description' => 'Destroy the content',
    ],
    'trash-content' => [
        'name' =>  'contents.trash',
        'slug' => 'trash-content',
        'description' => 'Trash the content',
    ],
    'restore-content' => [
        'name' => 'contents.restore',
        'slug' => 'restore-content',
        'description' => 'Restore the content',
    ],

    'view-profile' => [
        'name' => 'settings.profile',
        'slug' => 'view-profile',
        'description' => 'View the profile',
    ],

    /**
     * Student Permissions
     *
     */
    'view-student' => [
        'name' =>  'students.index',
        'slug' => 'view-student',
        'description' => 'View students',
    ],
    'show-student' => [
        'name' => 'students.show',
        'slug' => 'show-student',
        'description' => 'Show a student',
    ],
    'create-student' => [
        'name' => 'students.create',
        'slug' => 'create-student',
        'description' => 'Show student form',
    ],
    'store-student' => [
        'name' => 'students.store',
        'slug' => 'store-student',
        'description' => 'Store the student',
    ],
    'edit-student' => [
        'name' => 'students.edit',
        'slug' => 'edit-student',
        'description' => 'Edit the student',
    ],
    'update-student' => [
        'name' => 'students.update',
        'slug' => 'update-student',
        'description' => 'Update the student',
    ],
    'destroy-student' => [
        'name' =>  'students.destroy',
        'slug' => 'destroy-student',
        'description' => 'Destroy the student',
    ],
    'trash-student' => [
        'name' =>  'students.trash',
        'slug' => 'trash-student',
        'description' => 'Trash the student',
    ],
    'restore-student' => [
        'name' => 'students.restore',
        'slug' => 'restore-student',
        'description' => 'Restore the student',
    ],

    /**
     * Assignments
     *
     */
    'view-assignment' => [
        'name' =>  'assignments.index',
        'slug' => 'view-assignment',
        'description' => 'View assignments',
    ],
    'show-assignment' => [
        'name' => 'assignments.show',
        'slug' => 'show-assignment',
        'description' => 'Show a assignment',
    ],
    'create-assignment' => [
        'name' => 'assignments.create',
        'slug' => 'create-assignment',
        'description' => 'Show assignment form',
    ],
    'store-assignment' => [
        'name' => 'assignments.store',
        'slug' => 'store-assignment',
        'description' => 'Store the assignment',
    ],
    'edit-assignment' => [
        'name' => 'assignments.edit',
        'slug' => 'edit-assignment',
        'description' => 'Edit the assignment',
    ],
    'update-assignment' => [
        'name' => 'assignments.update',
        'slug' => 'update-assignment',
        'description' => 'Update the assignment',
    ],
    'destroy-assignment' => [
        'name' =>  'assignments.destroy',
        'slug' => 'destroy-assignment',
        'description' => 'Destroy the assignment',
    ],
    'trash-assignment' => [
        'name' =>  'assignments.trash',
        'slug' => 'trash-assignment',
        'description' => 'Trash the assignment',
    ],
    'restore-assignment' => [
        'name' => 'assignments.restore',
        'slug' => 'restore-assignment',
        'description' => 'Restore the assignment',
    ],

    /**
     * Packages
     *
     */
    'view-package' => [
        'name' =>  'packages.index',
        'slug' => 'view-package',
        'description' => 'View packages',
    ],
    'show-package' => [
        'name' => 'packages.show',
        'slug' => 'show-package',
        'description' => 'Show a package',
    ],
    'create-package' => [
        'name' => 'packages.create',
        'slug' => 'create-package',
        'description' => 'Show package form',
    ],
    'store-package' => [
        'name' => 'packages.store',
        'slug' => 'store-package',
        'description' => 'Store the package',
    ],
    'edit-package' => [
        'name' => 'packages.edit',
        'slug' => 'edit-package',
        'description' => 'Edit the package',
    ],
    'update-package' => [
        'name' => 'packages.update',
        'slug' => 'update-package',
        'description' => 'Update the package',
    ],
    'destroy-package' => [
        'name' =>  'packages.destroy',
        'slug' => 'destroy-package',
        'description' => 'Destroy the package',
    ],
    'trash-package' => [
        'name' =>  'packages.trash',
        'slug' => 'trash-package',
        'description' => 'Trash the package',
    ],
    'restore-package' => [
        'name' => 'packages.restore',
        'slug' => 'restore-package',
        'description' => 'Restore the package',
    ],
];