<?php

return [
    [
        'views' => ['Pluma::layouts.admin', 'Yggdrasil::dashboard.index', 'Yggdrasil::courses.*'],
        'class' => '\Yggdrasil\Composers\WidgetsViewComposer',
    ],
];