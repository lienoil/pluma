<?php

namespace Yggdrasil\Requests;

use Pluma\Requests\FormRequest;

class CourseRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        switch ( $this->method() ) {
            case 'POST':
                if ( $this->user()->can('store-course') ) return true;
                break;

            case 'PUT':
                if ( $this->user()->can('update-course') ) return true;
                break;

            case 'DELETE':
                if ( $this->user()->can('destroy-course') ) return true;
                break;

            default:
                return false;
                break;
        }
        return false;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $is_updating = $this->method() == "PUT" ? ",id,$this->id" : "";

        return [
            'title' => 'required',
            'slug' => 'required|unique:courses'.$is_updating,
            'code' => 'required|unique:courses'.$is_updating,
            'contents' => 'required',
        ];
    }
}
