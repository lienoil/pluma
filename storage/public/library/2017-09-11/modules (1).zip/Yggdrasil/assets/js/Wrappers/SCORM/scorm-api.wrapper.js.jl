/**
 * ----------------------------------------------
 * SCORM 1.2 / 2004 API WRAPPER
 * ----------------------------------------------
 * Wrapper for SCORM.
 *
 * @author John Lioneil P. Dionisio <john.dionisio1@gmail.com>
 */

(function (document, window) {

    'use strict';

    // Auto initialize
    window.API = new API();

    function API() {
        // Constants
        var SCORM_TRUE = 'true';
        var SCORM_FALSE = 'false';
        var STATE_NOT_INITIALIZED = 0;
        var STATE_INITIALIZED = 1;
        var STATE_COMPLETE = 2;

        var _self = this;

        _self.currentState = STATE_NOT_INITIALIZED;

        _self.LMSInitialize = function (string) {
            var returnValue = SCORM_FALSE;

            if (_self.currentState === STATE_INITIALIZED) {
                throwSCORMError(_self, 101, 'LMS was already initialized!');
            }
            else {
                _self.currentState = STATE_INITIALIZED;
                returnValue = SCORM_TRUE;
            }

            return returnValue;
        };

        _self.LMSGetValue = function (CMIElement) {
            var elementValue = getCMIValue(CMIElement);

            _self.apiLog('LMSGetValue', CMIElement, ': returned: ' + elementValue, LOG_LEVEL_INFO);

            processListeners('LMSGetValue', CMIElement);

            return elementValue;
        }
    }

    /**
     * ----------------------------------------------
     * Private Functions
     * ----------------------------------------------
     *
     */

    /**
     * Throws a scorm error
     *
     * @param API
     * @param errorNumber
     * @param message
     */
    function throwSCORMError(API, errorNumber, message) {
        if (!message) {
            message = getLmsErrorMessageDetails(errorNumber);
        }

        _self.apiLog('throwSCORMError', null, errorNumber + ': ' + message, LOG_LEVEL_ERROR);

        API.lastErrorCode = String(errorNumber);
    }
})(document, window);