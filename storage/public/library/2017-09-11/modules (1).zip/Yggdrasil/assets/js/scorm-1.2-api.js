var API = null;

function initAPI(_option) {
    API = {};

    var debug = _option.debug ? _option.debug : false;

    var initialized = false;

    API.LMSInitialize = function(string) {

        if (debug) { console.log('===| [Yggdrasil] LMSInitialize |==='); }

        $.ajax({
            url: _option.initialize.url,
            method: _option.initialize.method,
            data: { id: _option.initialize.id, cmiString: string },
            success: function (data) {
                API["cmi.core.student_id"] = _option.initialize.student_id;
            },
        });

        return "true";
    }

    API.LMSGetValue = function(cmiString) {
        return API[cmiString];
    }

    API.LMSSetValue = function(cmiString, value) {
        console.log("LMSSetValue", cmiString, value );
        var call = API["cmi.core.total_time"];
        console.log("--------------CALL", call);

        API[cmiString] = value;

        var c = API.LMSGetValue("cmi.core.lesson_status");

        $.ajax({
            url: _option.url,
            method: _option.method,
            data: { id: _option.id, cmiString: cmiString, value: value, "_token": _option._token},
            success: function (data) {
                var data = data;
                console.log(data);
                console.log("PS,", API);
            },
        });

        return "true";
    }

    API.LMSCommit = function(string) {
        API["cmi.core.student_id"] = _option.initialize.student_id;
        API.LMSSetValue("cmi.core.student_id", _option.initialize.student_id);

        // alert(API.LMSGetValue("cmi.core.score.raw"));
        return "true";
    }

    API.LMSFinish = function() {
        API.LMSGetValue('');

        alert('asd');

        return "true";
    }

    API.LMSGetLastError = function() {
        return 0;
    }

    API.LMSGetErrorString = function(errorCode) {
        if (debug) {
            console.log('*** LMSGetErrorString errorCode='+errorCode+' ***');
        }
        return "error string";
    }

    API.LMSGetDiagnostic = function(errorCode) {
        if (debug) {
            console.log('*** LMSGetDiagnostic errorCode='+errorCode+' ***');
        }
        return "diag string";
    }
}