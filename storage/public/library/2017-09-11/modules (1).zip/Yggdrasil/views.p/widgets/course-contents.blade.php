<div class="card">
    <div class="card-header box-header with-border">
        <spa class="card-title">Table of Contents</spa>
    </div>
    <div class="card-content">
        <ul class="collapsible popout" data-collapsible="expandable">
            @foreach ($contentable->contents as $content)
                @if (isset($content->package))
                    <li class="{{ isset($id) && $id == $content->id ? 'active' : '' }}">
                        <div class="collapsible-header {{ isset($id) && $id == $content->id ? 'active' : '' }}">
                            <img src="{{ $content->package->thumbnail }}" width="60" class="img-fluid m-1">
                            <span>
                                @notenrolled($contentable)
                                    <i class="fa fa-lock" aria-hidden="true"></i>
                                @endnotenrolled
                                {{ $content->package->name }}
                            </span>
                        </div>
                        @if (!isset($id) || (isset($id) && $id != $content->id))
                        <div class="collapsible-body">
                            {{ $content->package->description }}
                                <div class="m-t-2">
                                    <a href="{{ route('contents.show', [$contentable->code, $content->id]) }}" class="btn btn-primary btn-scorm waves-effect waves-light">Take</a>
                                </div>
                        </div>
                        @endif
                    </li>
                @endif
            @endforeach
        </ul>
    </div>
</div>

@push('js')
    <script>
        $('.btn-scorm').on('click', function (e) {
            e.preventDefault();
            var strWindowFeatures = "location=yes,height=570,width=520,scrollbars=yes,status=yes";
            var URL = $(this).attr('href');
            var win = window.open(URL, "_blank", strWindowFeatures);
        });
    </script>
@endpush