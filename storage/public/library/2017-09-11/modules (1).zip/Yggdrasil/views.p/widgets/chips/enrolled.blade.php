@enrolled($resource)
    <div class="chip bg-primary bg-green">
        {{-- <img src="{{ auth()->user()->avatar }}" width="10" height="10" alt="{{ auth()->user()->username }}"> --}}
        <i class="fa fa-check">&nbsp;</i>Enrolled
        <small><i class="fa fa-calendar-o">&nbsp;</i>{{ $resource->created }}</small>
    </div>
@endenrolled()