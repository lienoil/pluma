<div class="card horizontal">
    <div class="card-image card-box bg-psdm">
        <img src="{{ $resource->thumbnail }}" alt="{{ $resource->title }}" width="240">
    </div>
    <div class="card-stacked">
        <div class="card-content">
            <h3 class="card-title uppercase text-dark">
                <a href="{{ route('courses.show', $resource->code) }}" class="text-dark">
                    <strong>{{ $resource->code }}</strong>
                    <span class="card-subtitle">{{ $resource->title }}</span>
                </a>
            </h3>
            <div class="card-metadata m-b-1">
                @include("Yggdrasil::widgets.chips.enrolled")
                @include("Pluma::widgets.chips.categories")
            </div>

            <p>{!! $resource->excerpt !!}</p>
        </div>
        <div class="card-action">
            @allow('show-course')
                @enrolled($resource)
                    <a href="{{ route('courses.show', $resource->code) }}" class="m-b-1 waves-effect waves-light btn btn-yellow m-r-1"><i class="fa fa-play font-14">&nbsp;</i>Resume</a>
                @else
                    <a href="{{ route('courses.show', $resource->code) }}" class="m-b-1 waves-effect waves-yellow btn btn-default m-r-1">View</a>
                @endenrolled()
            @endallow

            @allow('show-enrollees')
                <a href="{{ route('students.create') }}" class="m-b-1 waves-effect waves-yellow btn btn-default m-r-1">Enroll a Student</a>
            @endallow

            @allow('edit-course')
                <a href="{{ route('courses.edit', $resource->id) }}" class="m-b-1 waves-effect waves-yellow btn btn-default m-r-1">Edit</a>
            @endallow

            @allow('trash-course')
                @include("Pluma::partials.form-destroy")
            @endallow
        </div>
    </div>
</div>