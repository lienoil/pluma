@include("Pluma::partials.header")
@include("Pluma::partials.footer")

<div class="container-fluid">
<button type="button" class="close pull-right m-t-2 m-r-2" data-clone-close><i class="fa fa-close"></i></button>
    <div class="row">
        <div class="s12">
            <ul id="package-tab" class="tabs tabs-main">
                <li class="tab col s2"><a class="active" href="#package-file">Packages</a></li>
                <li class="tab col s2"><a href="#form-file">Forms</a></li>
            </ul>
        </div>
        <div id="package-file" class="col s12 m-t-2">
            @foreach ( $packages->chunk(4) as $chunks )
                <div class="row p-2">
                    @foreach ( $chunks as $package )
                        <div class="col-sm-3">
                            <div class="box explorer-item card">
                                <div class="box-header with-border">
                                    <p class="m-0"><a class="text-dark m-0" href="#" data-explorer-title-value="{{ $package->name }}" data-explorer-text-value="{{ $package->description }}" data-explorer-preview-value="{{ $package->thumbnail }}" data-explorer-target-value="{{ $package->toJSON() }}" data-explorer-value-type="{{ $package->type }}">{{ $package->name }}</a></p>
                                </div>
                                <div class="box-body">
                                    <a class="package-card" href="#" data-explorer-title-value="{{ $package->name }}" data-explorer-text-value="{{ $package->description }}" data-explorer-preview-value="{{ $package->thumbnail }}" data-explorer-target-value="{{ $package->toJSON() }}" data-explorer-value-type="{{ $package->type }}"><img max-width="200" width="{{ $package->width }}" src="{{ $package->thumbnail }}" class="card-img-top responsive-img"></a>


                                    <p class="m-t-2">{{ $package->description }}</p>
                                </div>
                                {{-- <div class="card-footer center-align">
                                    <button data-explorer-title-value="{{ $package->name }}" data-explorer-text-value="{{ $package->description }}" data-explorer-preview-value="{{ $package->thumbnail }}" data-explorer-target-value="{{ $package->toJSON() }}" data-explorer-value-type="{{ $package->type }}" type="button" class="waves-effect waves-yellow btn btn-default">Select</button>
                                </div> --}}
                                <div class="card-action center-align">
                                    <a class="text-info m-r-0 pointer" data-explorer-title-value="{{ $package->name }}" data-explorer-text-value="{{ $package->description }}" data-explorer-preview-value="{{ $package->thumbnail }}" data-explorer-target-value="{{ $package->toJSON() }}" data-explorer-value-type="{{ $package->type }}" type="button">Select</a>
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>
            @endforeach
        </div>
        <div id="form-file" class="col s12 m-t-2">
            @foreach ( $forms->chunk(4) as $chunks )
                <div class="row">
                    @foreach ( $chunks as $package )
                        <div class="col-sm-3">
                            <div class="box no-border explorer-item">
                                <div class="box-body">
                                    <p class="card-title"><a href="#" data-explorer-title-value="{{ $package->name }}" data-explorer-text-value="{{ $package->description }}" data-explorer-preview-value="{{ $package->thumbnail }}" data-explorer-target-value="{{ $package->toJSON() }}" data-explorer-value-type="{{ $package->type }}"><strong>{{ $package->name }}</strong></a></p>
                                    <p>{{ $package->description }}</p>
                                </div>

                                {{-- <div class="card-footer center-align">
                                    <button data-explorer-title-value="{{ $package->name }}" data-explorer-text-value="{{ $package->description }}" data-explorer-preview-value="{{ $package->thumbnail }}" data-explorer-target-value="{{ $package->toJSON() }}" data-explorer-value-type="{{ $package->type }}" type="button" class="waves-effect waves-light btn m-t-2 btn-yellow">Select</button>
                                </div> --}}
                            </div>
                        </div>
                    @endforeach
                </div>
            @endforeach
        </div>
    </div>
</div>
{{-- <div class="card-footer center-align clone-item">
    <a class="btn waves-effect waves-light btn-yellow">Done</a>
    <a class="btn waves-effect waves-yellow btn-default">Cancel</a>
</div> --}}



<style>
    .card-title {
        word-wrap: break-word;
    }
</style>