@extends("Pluma::layouts.admin")
@section('content')
    @include("Pluma::partials.alert")

    <div class="container-fluid">
        <div class="no-border">
            <a href="{{ route('packages.upload') }}" class="btn waves-effect waves-light btn-yellow m-b-2">Upload Page</a>
            <div class="pull-right m-t-1">
                @include("Pluma::partials.trash", ['name' => 'packages'])
            </div>

            @if ( $resources->isEmpty() )
                <p class="m-t-3 text-muted text-xs-center"><i class="fa fa-archive">&nbsp;</i>No package to show</p>
            @endif

            @foreach ( $resources->chunk(4) as $chunk )
                <div class="row">
                    @foreach ( $chunk as $resource )
                        <div class="col-md-3">
                            <div class="card" style="margin: 0 0 1rem !important;">
                                <div class="card-image image-reveal waves-effect waves-block waves-light card-bg">
                                    <a class="valign-wrapper package-card" href="{{ route('packages.edit', $resource->id) }}">
                                    <img src="{{ $resource->thumbnail }}" alt="{{ $resource->displayname }}" class="valign img-responsive"></a>
                                </div>

                                <div class="card-action">
                                    <span class="card-title activator grey-text text-bolder">{{ $resource->displayname }}
                                    <i class="fa fa-ellipsis-v right" aria-hidden="true"></i></span>
                                    @if ( $resource->warning )
                                        <p class="text-danger"><i class="fa fa-wraning">&nbsp;</i>{{ $resource->warning }}</p>
                                    @endif
                                </div>

                                <div class="card-action">
                                    <a class="text-info" href="{{ route('packages.edit', $resource->id) }}">Edit</a>
                                    <form class="form-inline pull-right m-0" action="{{ route('pages.destroy', $resource->id) }}" method="POST">
                                        {{ csrf_field() }}
                                        {{ method_field('DELETE') }}
                                        <button class="no-bg no-border text-red" type="submit" data-swal='{"title":"Are you sure?","text":"{{ $resource->title }} page will be moved to Trash.","type":"warning","showCancelButton":"true","confirmButtonText":"Remove"}'>Delete</button>
                                    </form>
                                </div>

                                <div class="card-reveal">
                                    <span class="card-title"><strong>{{ $resource->displayname }}</strong>
                                        <i class="material-icons pull-right text-dark-gray">close</i>
                                    <div class="metadata m-t-2">
                                        <style scoped>
                                            small {
                                                display: block;
                                            }
                                        </style>
                                        <small class="m-b-3">{{ $resource->description }}</small>
                                        <small class="metadata-item text-muted m-b-2"><i class="fa fa-external-link">&nbsp;</i> <strong>File Name:</strong> <br> {{ $resource->url }}</small>
                                        <small class="metadata-item text-muted m-b-2"><i class="fa fa-calendar">&nbsp;</i> <strong>Created:</strong><br>
                                             {{ $resource->created }}</small>
                                        <small class="metadata-item text-muted"><i class="fa fa-calendar">&nbsp;</i> <strong>Modified:</strong><br>
                                            {{ $resource->modified or 'not modified' }}</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>
            @endforeach
        </div>
        <div class="card-footer no-bg no-border">
            <div class="pull-right">
                {{-- @include("Pluma::partials.pagination", compact('resources')) --}}
            </div>
        </div>
    </div>
@endsection

@push('css')
    <style>
        .metadata .metadata-item {
            display: block;
        }
    </style>
@endpush