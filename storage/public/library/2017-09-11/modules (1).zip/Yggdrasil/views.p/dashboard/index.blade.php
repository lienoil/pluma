@extends('Pluma::layouts.admin')

@section("content")
    <section class="content">
        <div class="row">
            <div class="col-md-9">
                {{-- Card: Current Course --}}
                @include("Yggdrasil::widgets.courses.current", ['resource' => $widgets['courses']['current']->first()])
                {{-- /Card --}}

                <div class="cards-masonry two-columns">
                    {{-- Card: Todo List --}}
                    {{-- @allow('create-tasks') --}}
                    @include("Pluma::widgets.notepad")
                    {{-- @endallow --}}
                    {{-- /Card --}}
                </div>

            </div>
            <div class="col-md-3">
                @allow('show-announcement')
                {{-- Card --}}
                @include("Announcement::widgets.announcements")
                {{-- /Card --}}
                @endallow

                {{-- @allow('view-activity') --}}
                {{-- Card --}}
                @include("Pluma::activities.widgets.activities")
                {{-- /Card --}}
                {{-- @endallow --}}

                {{-- @allow('view-news') --}}
                {{-- Card --}}
                {{-- @include("Pluma::widgets.placeholder-card", ['title' => 'News Feed', 'description' => '<i class="fa fa-newspaper-o fa-3x"></i><br>No news']) --}}
                {{-- /Card --}}
                {{-- @endallow --}}
            </div>
        </div>
    </section>

@endsection