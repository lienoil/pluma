@extends("Pluma::layouts.admin")

@section("content")
    @include("Pluma::partials.alert")

    <div class="container-fluid">
        <div class="row">
            <div class="col-md-4">
                <div class="box no-border">
                    <div class="box-header with-border">
                        <h3 class="box-title">Courses Enrolled</h3>
                    </div>

                    <div class="box-body p-0">
                        <ul class="collection no-border m-0">
                            <li class="collection-item avatar height-64">
                                <a href="#!">
                                    <img src="https://placeimg.com/640/480/any" alt="" class="circle">
                                    <span class="title text-dark"><strong>DPE</strong></span>
                                    <p class="text-dark">7 Modules</p>
                                </a>
                            </li>
                            <li class="collection-item avatar height-64">
                                <a href="#!">
                                    <img src="https://placeimg.com/640/480/any" alt="" class="circle">
                                    <span class="title text-dark"><strong>PSDM</strong></span>
                                    <p class="text-dark">7 Modules</p>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="col-md-8">
                <div class="card horizontal no-shadow">
                    <div class="card-image card-box bg-psdm">
                        <img width="240" src="http://localhost:8000/default/src/images/courses/1.svg">
                    </div>
                    <div class="card-stacked">
                        <div class="card-content">
                            <span class="card-title"><strong>PSDM</strong></span>
                            <small> Enrolled: <i class="fa fa-calendar-o" aria-hidden="true"></i> April 17, 2017</small> <br>
                            <small><i class="icon-books"></i> PS101</small>
                            <div class="row col-md-12">
                                <span class="pull-right text-red bolder">30% Complete</span>
                                <div class="progress progress-xs">
                                    <div class="progress-bar progress-bar-danger progress-bar-striped" role="progressbar" aria-valuenow="30" aria-valuemin="0" aria-valuemax="100" style="width: 30%">
                                    </div>
                                </div>
                            </div>
                            <div class="clear"></div>
                        </div>

                        <div class="card-action">
                            <a class="btn waves-effect waves-light btn-yellow m-r-2"><i class="fa fa-play font-14"></i> Resume</a>
                        </div>
                    </div>
                </div>

                <ul id="testDiv" class="tabs tabs-main tabs-fixed-width" style="overflow-x: hidden;">
                    <li class="tab col s2"><a href="#courses">Overview</a></li>
                    <li class="tab col s2"><a class="active" href="#current">Modules</a></li>
                </ul>

                <div class="box box-body no-border">
                    <div id="courses" class="col s12">
                        <div class="m-t-3">
                           <p><span class="m-b-3"><strong>This is a course description.</strong></span> <br>
                            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Alias accusantium atque quisquam praesentium, est autem voluptatibus quisquamo eveniet adipisci vel magnam repellendus id quidem reprehenderit, eligendi molestias deleniti non mollitia.</p>
                        </div>
                    </div>

                    <div id="current">
                        <ul class="collapsible popout" data-collapsible="expandable">
                            <li>
                                <div class="collapsible-header active"><i class="fa fa-unlock" style="color: #6d6d6d;" aria-hidden="true"></i>Intro</div>
                                <div class="collapsible-body">
                                    <ul class="collection">
                                        @foreach ( $resource->collected_contents as $contents )
                                            <li class="m-b-2 contentCollection p-t-1 p-l-1 p-r-1">
                                                <a class="showMe" href="{{ route('courses.contents.show',[$resource->slug, $contents->id]) }}">
                                                    <strong><span class="text-dark">{{ $contents->content->description }}</span>
                                                    <span class="pull-right text-green">
                                                        <small><em>100%</em></small>
                                                    </span></strong>
                                                <div class="hidden pull-right" style="display: none">Let's Go!</div>
                                                     <br>
                                                </a>
                                                <div class="secondary-content"></div>
                                                <div class="clear"></div>
                                                <div class="divider m-t-2"></div>
                                            </li>
                                        @endforeach
                                    </ul>
                                </div>
                            </li>
                            <li>
                                <div class="collapsible-header"><i class="fa fa-lock text-dark" style="color: #6d6d6d;" aria-hidden="true"></i>PS 1</div>
                                <div class="collapsible-body"><span>Lorem ipsum dolor sit amet.</span></div>
                            </li>
                            <li>
                                <div class="collapsible-header"><i class="fa fa-lock text-dark" style="color: #6d6d6d;" aria-hidden="true"></i>PS 2</div>
                                <div class="collapsible-body"><span>Lorem ipsum dolor sit amet.</span></div>
                            </li>
                            <li>
                                <div class="collapsible-header"><i class="fa fa-lock text-dark" style="color: #6d6d6d;" aria-hidden="true"></i>PS 3</div>
                                <div class="collapsible-body"><span>Lorem ipsum dolor sit amet.</span></div>
                            </li>
                        </ul>
                    </div>
                </div>

                <div class="box no-border">
                    <div class="box-header with-border">
                        <h3 class="box-title">Comments</h3>
                    </div>
                    <div class="box-body">
                        <p class="text-red">Leave a Reply</p>
                        <div class="well">
                            <form>
                                <div class="input-field">
                                    <textarea disabled name="body" placeholder="Write a comment.." style="
                                        border: 1px solid #d2d2d2; height: 5em; background: #fff; padding: 10px;"></textarea>
                                </div>
                                <div class="right-align m-t-1">
                                    <button type="submit" class="btn waves-effect waves-light btn-yellow">Post Comment</button>
                                </div>
                            </form>
                        </div>

                        <hr>
                        <p class="text-red m-b-3">3 Responses to [Course Title]</p>
                        <ul class="collection no-border" style="border-bottom: none !important;">
                            <li class="collection-item avatar no-bg no-border" style="border-bottom: none !important;">
                                <img src="https://placeimg.com/640/480/any" alt="" class="circle">
                                <span class="title"><strong>Jane Doe</strong></span> <br>
                                <small><i class="fa fa-clock-o" aria-hidden="true"></i> April 17, 2017 9:00am</small> <br>
                               <div class="m-t-1">
                                   Lorem ipsum dolor sit amet, consectetur adipisicing elit. Omnis, nostrum rerum sunt,
                               </div>
                               {{-- reply --}}
                                <ul class="collection no-border">
                                    <li class="collection-item avatar no-bg no-border border-comment" style="border-bottom: none !important;">
                                        <img src="https://placeimg.com/640/480/any" alt="" class="circle">
                                        <span class="title"><strong>Ken Smith</strong></span> <br>
                                        <small><i class="fa fa-clock-o" aria-hidden="true"></i> April 16, 2017 9:00am</small> <br>
                                       <div class="m-t-1"> cum ipsum dolorem, laudantium culpa reiciendis aliquid delectus eaque. Quisquam quia, impedit ab. Quidem illum vitae iure velit! </div>
                                    </li>
                                    <li class="collection-item avatar no-bg no-border border-comment" style="border-bottom: none !important;">
                                        <img src="{{ theme('src/images/user2-160x160.jpg') }}" alt="" class="circle">
                                        <span class="title"><strong>John Lioneil Dionisio</strong></span> <br>
                                        <small><i class="fa fa-clock-o" aria-hidden="true"></i> April 16, 2017 9:00am</small> <br>
                                       <div class="m-t-1">
                                           <textarea disabled class="input-reply-comment" name="" id="" style="padding: 10px;" placeholder="Write a comment.." cols="30" rows="10"></textarea>
                                       </div>
                                    </li>
                                </ul>
                                {{-- end reply --}}
                            </li>

                            <li class="collection-item avatar no-bg no-border" style="border-bottom: none !important;">
                                <img src="https://placeimg.com/640/480/any" alt="" class="circle">
                                <span class="title"><strong>Ken Smith</strong></span> <br>
                                <small><i class="fa fa-clock-o" aria-hidden="true"></i> April 17, 2017 9:00am</small> <br>
                               <div class="m-t-1"> Hello! </div>
                                <ul class="collection no-border">
                                    <li class="collection-item avatar no-bg no-border border-comment" style="border-bottom: none !important;">
                                        <img src="{{ theme('src/images/user2-160x160.jpg') }}" alt="" class="circle">
                                        <span class="title"><strong>John Lioneil Dionisio</strong></span> <br>
                                        <small><i class="fa fa-clock-o" aria-hidden="true"></i> April 16, 2017 9:00am</small> <br>
                                        <div class="m-t-1">
                                           <textarea class="input-reply-comment" name="" id="" style="padding: 10px;" placeholder="Write a comment.." cols="30" rows="10" disabled></textarea>
                                        </div>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@push('css')

    <style>
        .height-64 {
            min-height: 64px !important;
        }

        .showMe:hover + .hidden {
            display: block;
        }

        .hidden {
            display: none;
        }

        .contentCollection:hover {
            background: #ededed;
            transition: ease 0.5s;
        }
    </style>
@endpush

@push('js')
   <script>
        $(document).ready(function(){
            $('.collapsible').collapsible();
        });
   </script>
@endpush