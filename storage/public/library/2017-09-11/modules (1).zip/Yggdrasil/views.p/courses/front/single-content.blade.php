@extends("Yggdrasil::layouts.course")

@section("course-content")
    <div id="wrapper" class="toggled">
        <div class="container-fluid">
            <div id="mySidenav" class="sidenav">
                <a href="javascript:void(0)" class="closebtn" onclick="closeNav()"><i class="material-icons">close</i></a>
                <div class="clip-title">Table of Contents</div>
                <a class="toc" href="#">Far far away, behind the word mountains, far from the countries Vokalia and Consonantia
                    <span class="m-l-auto text-green"><i class="material-icons">check</i></span></a>
                <a class="toc" href="#">Sample Description
                    <span class="m-l-auto text-darker-gray"><i class="material-icons">lock_outline</i></span></a>
                    <a class="toc" href="#">Another Sample Description
                    <span class="m-l-auto text-darker-gray"><i class="material-icons">lock_outline</i></span></a>
            </div>

            {{-- content --}}
            <div id="main">
                <span class="btn waves-effect waves-light btn-yellow m-b-2 m-r-2" style="cursor:pointer" onclick="openNav()">Table of Contents</span>
                <a target="_blank" class="btn waves-effect waves-yellow btn-default m-b-2" href="{{ $resource->interactive }}">Click here to open New Tab</a>
                @if ( $resource->viewable )
                    <div class="box no-border">
                        <div class="box-header with-border">
                            <h3 class="box-title">{{ $resource->name }}</h3>
                        </div>
                        <div class="box-body">
                            @if ( $resource->type == get_class(new \Form\Models\Form) )
                                {!! $resource->form !!}
                            @else
                                <iframe allowfullscreen="allowfullscreen" mozallowfullscreen="mozallowfullscreen" msallowfullscreen="msallowfullscreen" oallowfullscreen="oallowfullscreen" webkitallowfullscreen="webkitallowfullscreen" src="{{ $resource->interactive }}" name="course" style="width:100%; height:670px;" frameborder="0"></iframe>
                            @endif
                        </div>
                    </div>
                @else
                    <div class="container-fluid">
                        <div class="card">
                            <div class="card-block min-height-200">
                                <h3 class="text-muted text-center p-t-3">This course is locked</h3>
                            </div>
                        </div>
                    </div>
                @endif
            </div>
        </div>
    </div>
@endsection

@push('css')
    <link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <style>
        .min-height-200 {
            min-height: 200px;
        }

        .sidenav {
            height: 100%;
            width: 0;
            position: absolute;
            z-index: 1;
            top: 0;
            left: 0;
            background-color: #222d32;
            overflow-x: hidden;
            transition: 0.5s;
            padding-top: 40px;
            counter-reset: section;
        }

        .sidenav a {
            padding: 18px 18px 18px 32px;
            text-decoration: none;
            font-size: 16px;
            color: #fff;
            display: block;
            transition: 0.3s;
            display: flex;
        }

        .sidenav a.toc:hover, .offcanvas a.toc:focus{
            color: #f1f1f1;
            background: #c6992d;
        }

        .sidenav a.toc::before {
            counter-increment: section;
            content: counter(section) ". ";
            font-weight: 600;
            padding-right: 20px;
            color: #c6992d;
        }

        .sidenav a.toc:hover::before {
            color: #222d32;
        }

        .sidenav a.toc span:hover::before {
            color: #fff;
        }

        .sidenav .closebtn {
            position: absolute;
            top: 0;
            z-index: 1000;
            padding: 6px;
            right: 5px;
            font-size: 36px;
            margin-left: 50px;
        }

        #main {
            transition: margin-left .5s;
            padding: 16px;
        }

        @media screen and (max-height: 450px) {
          .sidenav {padding-top: 65px;}
          .sidenav a {font-size: 18px;}
        }

        .clip-title {
            background: #1e282c;
            padding: 10px;
            color: #d0cfcf;
            text-transform: uppercase;
            text-overflow: clip;
            letter-spacing: 3px;
            position: absolute;
            width: 100%;
            top: 0;
        }

        .m-l-auto {
            margin-left: auto;
        }

        .p-l-05 {
            padding-left: 5px;
        }

        .footer-text:hover {
            color: #788084;
        }

        .text-darker-gray {
            color: #656565;
        }
    </style>

    <script src="{{ assets("Yggdrasil/js/scorm-1.2-api.js") }}"></script>
@endpush