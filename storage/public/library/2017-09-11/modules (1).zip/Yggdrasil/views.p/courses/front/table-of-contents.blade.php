@foreach ( $contents as $content )
    @if ( ! $content->viewable )
            <i class="fa fa-lock">&nbsp;</i>{{ $content->content->name }}
        </div>
    @else
        {{-- <a href="{{ route('courses.contents.show', [$course->slug, $content->id]) }}" class="list-group-item {{ $id == $content->id ? 'active' : '' }}">
            {{ $content->content->name }}
        </a> --}}

    @endif
@endforeach


{{-- fixed end note --}}
<div class="main-footer fixed m-l-0">
    <div class="container-fluid">
        <a class="text-dark p-l-1 footer-text" href="{{ route('courses.show', $course->id) }}"> <span class="caret-note"><i class="fa fa-angle-left" aria-hidden="true"></i></span><strong>Back to Course Page</strong></a>
    </div>
</div>

@push('css')
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
    <link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->
      {{-- <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/> --}}
    <style>
        #form1 {
            display : none;
        }
        button {
            margin-bottom: 10px;
        }

        .border-comment {
            border-left: 2px solid #d2d2d2 !important;
            border-bottom: transparent !important;
        }

        .fixed {
            position: fixed;
            width: 100%;
            bottom: 0;
        }

        .caret-note {
            background: #c6992d;
            padding: 5px 12px;
            border-radius: 50%;
            margin-right: 10px;
        }

        .caret-note i {
            color: #fff;
        }

        @media only screen and (max-width: 500px) {
            #mySidenav {
                /*width: 200px !important;*/
            }
        }
    </style>
@endpush

@push('css')
@endpush

@push('js')
    <script src="https://code.jquery.com/ui/1.11.4/jquery-ui.min.js"></script>
    {{-- <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script> --}}
    {{-- <script src="{{ theme('assets/vendor/admin-lte/dist/js/pages/dashboard.js') }}"></script> --}}

    {{-- <script src="{{ theme('assets/js/app.js') }}"></script> --}}
    <script>
        $(document).ready(function(){
            $('.modal').modal();
        });

        function openNav() {
            document.getElementById("mySidenav").style.width = "450px";
            document.getElementById("main").style.marginLeft = "450px";
            document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
        }

        function closeNav() {
            document.getElementById("mySidenav").style.width = "0";
            document.getElementById("main").style.marginLeft= "0";
            document.body.style.backgroundColor = "white";
        }
    </script>
@endpush