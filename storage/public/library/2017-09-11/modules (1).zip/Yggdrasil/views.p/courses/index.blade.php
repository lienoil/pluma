@extends("Pluma::layouts.admin")

@section("content")
	@include("Pluma::partials.alert")
	<div class="container-fluid" id="content-tab-courses">
		<div class="row s12">

			<div class="btn-group list-grid-view pull-right m-b-3" data-toggle="buttons">
				<label id="list" class="btn-flat waves-effect waves-yellow btn m-t-2 btn-default active btn-switcher">
					<input type="radio" name="options" id="option1" autocomplete="off" checked> <i class="fa fa-list info font-14" aria-hidden="true"></i> List</label>
				<label id="grid" class="btn-flat waves-effect waves-yellow btn m-t-2 btn-default btn-switcher">
					<input type="radio" name="options" id="option2" autocomplete="off"> <i class="fa fa-th info font-14" aria-hidden="true"></i> Grid </label>
			</div>

			<ul id="testDiv" class="tabs tabs-main">
				<li class="tab col s2"><a href="#courses">All Courses</a></li>
				<li class="tab col s2"><a class="active" href="#current">Current</a></li>
				<li class="tab col s2"><a href="#previous">Previous</a></li>
				<li class="tab col s2"><a href="#recommended">Recommended</a></li>
				<li class="tab col s2"><a href="#bookmarked">Bookmarked</a></li>
			</ul>
		</div>

		<div id="courses" class="col s12">
			<div class="row">
				@foreach ( $resources as $i => $resource )
					<div class="item m-t-2 col-md-12 col-md-3">
						<div class="box no-border">
							<div class="box-body p-0">
									<div class="card vertical horizontal no-shadow m-b-0">
									<div class="card-image card-box bg-psdm">
										<img src="{{ asset('default/src/images/courses/1.svg') }}">
									</div>
									<div class="card-stacked">
										<div class="card-content">
											<span class="card-title uppercase text-dark"><strong>{!! $resource->edit_link('courses', $resource->title) !!}</strong></span>
											<div class="chip bg-primary bg-green">
										        <i class="fa fa-check">&nbsp;</i>Enrolled
										    </div> <br>

										   	{{-- <small>	Enrolled: <i class="fa fa-calendar-o" aria-hidden="true"></i> April 17, 2017</small> <br> --}}
											{{-- <small><i class="icon-books"></i> PS101</small> --}}
											<div class="m-t-2">
												<p>[Course Description]</p>
											</div>
										</div>
										<div class="card-action">
											@allow('update-course')
												<a href="{{ route('courses.edit', $resource->id) }}" class="waves-effect waves-yellow btn btn-default m-r-1">Edit</a>
											@endallow

											<a href="{{ route('courses.show', $resource->id) }}" class="waves-effect waves-light btn btn-yellow">View Course</a>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				@endforeach
			</div>
		</div>
		<div id="current" class="col s12">
			<div class="row">
				@foreach ( $resources as $i => $resource )
					<div class="item m-t-2 col-md-12 col-md-3">
						<div class="box no-border">
							<div class="box-body p-0">
									<div class="card vertical horizontal no-shadow m-b-0">
									<div class="card-image card-box bg-psdm">
										<img src="{{ asset('default/src/images/courses/1.svg') }}">
									</div>
									<div class="card-stacked">
										<div class="card-content">
											<span class="pull-right course-bookmark"><i class="icon-bookmark"></i></span>
											<span class="card-title uppercase text-dark"><strong>{!! $resource->edit_link('courses', $resource->title) !!}</strong></span>
											<div class="card-metadata m-b-1">
								                <small class="categories-metdata grey-text m-r-2">
								        			<i class="fa fa-tags">&nbsp;</i>
								                    <span class="span-metadata grey-text">Supervisory Level</span>
								            	</small>

								            	<small class="categories-metdata grey-text">
								            		<i class="fa fa-tags">&nbsp;</i>
								            		<span class="span-metadata grey-text">Another Level</span>
								            	</small>
								            	<br>
								            	<div class="chip bg-primary bg-green m-t-2">
											        <i class="fa fa-check">&nbsp;</i>Enrolled
											    </div>

												<p>[Course Description]</p>
											</div>
										</div>
										<div class="card-action">
											<a class="bolder" href="{{ route('courses.show', $resource->id) }}">View</a>

											@allow('update-course')
											<a class="bolder" href="{{ route('courses.edit', $resource->id) }}">Edit</a>
											@endallow
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				@endforeach
			</div>
		</div>
		<div id="previous" class="col s12 text-center text-muted m-t-4">You have no previous course.</div>
		<div id="recommended" class="col s12 text-center text-muted m-t-4">You have no recommended courses.</div>
		<div id="bookmarked" class="col s12">
			<div class="row">
				@foreach ( $resources as $i => $resource )
					<div class="item m-t-2 col-md-12 col-md-3">
						<div class="box no-border">
							<div class="box-body p-0">
									<div class="card vertical horizontal no-shadow m-b-0">
									<div class="card-image card-box bg-psdm">
										<img src="{{ asset('default/src/images/courses/1.svg') }}">
									</div>
									<div class="card-stacked">
										<div class="card-content">
											<span class="pull-right course-bookmark"><i class="icon-bookmark"></i></span>
											<span class="card-title uppercase text-dark"><strong>{!! $resource->edit_link('courses', $resource->title) !!}</strong></span>
											<div class="chip bg-primary bg-green">
										        <i class="fa fa-check">&nbsp;</i>Enrolled
										    </div> <br>

										   	{{-- <small>	Enrolled: <i class="fa fa-calendar-o" aria-hidden="true"></i> April 17, 2017</small> <br> --}}
											{{-- <small><i class="icon-books"></i> PS101</small> --}}
											<div class="m-t-2">
												<p>[Course Description]</p>
											</div>
										</div>
										<div class="card-action text-left text-center">
											@allow('update-course')
												<a href="{{ route('courses.edit', $resource->id) }}" class="waves-effect waves-yellow btn btn-default m-r-1">Edit</a>
											@endallow

											<a href="{{ route('courses.show', $resource->id) }}" class="waves-effect waves-light btn btn-yellow">View Course</a>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				@endforeach
			</div>
		</div>
	</div>
@endsection

@push('css')
	<style>
	.courses-focus {
		{
			position: relative;
			border 1px solid #656566;
			top: 0;
			right: 0;
			bottom: 0;
			right: 0;
			white-space: nowrap;

		}

	}
	/**/
	.course-bookmark {
	  	position: absolute;
	  	top: 0;
	  	right: 30px;
	  	color: #dd4b39 !important;
	}

	.course-bookmark i {
	 	font-size: 40px;
	}

	.btn-switcher:focus {
		outline: none;
	}
</style>
@endpush

@push('js')
	<script src="{{ theme('assets/vendor/slimscroll/jquery.slimscroll.js') }}"></script>
	<script src="{{ theme('assets/vendor/slimscroll/examples/libs/prettify/prettify.js') }}"></script>
	<script>
		$( document ).ready(function() {
			prettyPrint();
	  		$('#testDiv').slimscroll({
				height: '100%;',
				width: '100%',
		    	axis: 'both'
			});
		});

		$(document).ready(function() {
			$('#list').on('click', function() {
		    	$('#content-tab-courses .item').removeClass('col-md-3').addClass('col-md-12');
		    	$('#content-tab-courses .item .box .box-body .card').removeClass('vertical').addClass('horizontal');
		    	$('#content-tab-courses .item .box .box-body .card .card-stacked .card-action').addClass('text-left').removeClass('text-center');
			});

		    $('#grid').on('click', function() {
		    	$('#content-tab-courses .item').removeClass('col-md-12').addClass('col-md-3');
		    	$('#content-tab-courses .item .box .box-body .card').removeClass('horizontal').addClass('vertical');
		    	$('#content-tab-courses .item .box .box-body .card .card-stacked .card-action').addClass('text-center').removeClass('text-left');
		    });
		});
	</script>
@endpush