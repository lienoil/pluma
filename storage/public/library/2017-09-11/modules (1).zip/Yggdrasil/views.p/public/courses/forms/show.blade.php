@extends("Pluma::layouts.page")

@section("content")

    <div class="container-fluid">

        <div class="col-md-12">
            <h1 class="card-title">{{ $resource->title }}</h1>
        </div>

        <div class="col-md-4">
            <div class="collection with-header">
                <div class="collection-header">
                    <p>Table of Contents</p>
                </div>

                @foreach ( $contents as $content )
                    <a href="{{ route('public.course.content.show', [$course->slug, $content->id]) }}" class="collection-item {{ $content->id == $id ? 'active' : '' }}">
                        <p class="collection-item-title"><img src="{{ $content->content->thumbnail }}" width="40"> {{ $content->content->name }}</p>
                    </a>
                @endforeach
            </div>
        </div>
        <div class="col-md-6">

            <div class="card">

                <div class="card-block">

                    {!! $form !!}

                </div>

            </div>

        </div>
    </div>
@endsection

@push('css')
    <style>
        body {
            background-color: #f2f2f2 !important;
        }
    </style>
@endpush