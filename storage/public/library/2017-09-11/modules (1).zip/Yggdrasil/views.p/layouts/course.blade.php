@extends("Pluma::layouts.courses")

@section("content")

<div class="container-fluid">
    @yield("course-content")


</div>
<div class="m-b-2">
        @include("Yggdrasil::courses.front.table-of-contents")
    </div>

@endsection