<?php

namespace Yggdrasil\Observers;

use Yggdrasil\Models\Assignment;
use Illuminate\Http\Request;

class AssignmentObserver
{

    /**
     * Listen to the Assignment creating event.
     *
     * @param  Assignment  $assignment
     * @return void
     */
    public function saving(Assignment $assignment)
    {
        session()->flash('title', $assignment->name);
        session()->flash('icon', "fa fa-check");
        session()->flash('message', "Assignment successfully saved");
        session()->flash('type', 'info');
    }

    /**
     * Listen to the Assignment created event.
     *
     * @param  Assignment  $assignment
     * @return void
     */
    public function created(Assignment $assignment)
    {
        session()->flash('title', $assignment->title ? $assignment->title : $assignment->name );
        session()->flash('icon', "fa fa-check");
        session()->flash('message', "Assignment successfully saved");
        session()->flash('type', 'info');
    }

    /**
     * Listen to the Assignment updated event.
     *
     * @param  Assignment  $assignment
     * @return void
     */
    public function updated(Assignment $assignment)
    {
        session()->flash('title', $assignment->name);
        session()->flash('icon', "fa fa-check");
        session()->flash('message', "Assignment successfully updated");
        session()->flash('type', 'info');
    }

    /**
     * Listen to the Assignment deleted event.
     *
     * @param  Assignment  $assignment
     * @return void
     */
    public function deleted(Assignment $assignment)
    {
        session()->flash('title', $assignment->name);
        session()->flash('icon', "fa fa-check");
        session()->flash('message', "Assignment successfully moved to trash");
        session()->flash('type', 'info');
    }

    /**
     * Listen to the Assignment restored event.
     *
     * @param  Assignment  $assignment
     * @return void
     */
    public function restored(Assignment $assignment)
    {
        session()->flash('title', $assignment->name);
        session()->flash('icon', "fa fa-check");
        session()->flash('message', "Assignment successfully restored");
        session()->flash('type', 'info');
    }
}