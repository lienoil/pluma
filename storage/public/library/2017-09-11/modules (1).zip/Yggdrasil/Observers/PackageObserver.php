<?php

namespace Yggdrasil\Observers;

use Yggdrasil\Models\Package;
use Illuminate\Http\Request;

class PackageObserver
{

    /**
     * Listen to the Package creating event.
     *
     * @param  Package  $package
     * @return void
     */
    public function saving(Package $package)
    {
        session()->flash('title', $package->title);
        session()->flash('icon', "fa fa-check");
        session()->flash('message', "Package successfully saved");
        session()->flash('type', 'info');
    }

    /**
     * Listen to the Package created event.
     *
     * @param  Package  $package
     * @return void
     */
    public function created(Package $package)
    {
        session()->flash('title', $package->title ? $package->title : $package->name );
        session()->flash('icon', "fa fa-check");
        session()->flash('message', "Package successfully saved");
        session()->flash('type', 'info');
    }

    /**
     * Listen to the Package updated event.
     *
     * @param  Package  $package
     * @return void
     */
    public function updated(Package $package)
    {
        session()->flash('title', $package->title);
        session()->flash('icon', "fa fa-check");
        session()->flash('message', "Package successfully updated");
        session()->flash('type', 'info');
    }

    /**
     * Listen to the Package deleted event.
     *
     * @param  Package  $package
     * @return void
     */
    public function deleted(Package $package)
    {
        session()->flash('title', $package->title);
        session()->flash('icon', "fa fa-check");
        session()->flash('message', "Package successfully moved to trash");
        session()->flash('type', 'info');
    }

    /**
     * Listen to the Package restored event.
     *
     * @param  Package  $package
     * @return void
     */
    public function restored(Package $package)
    {
        session()->flash('title', $package->title);
        session()->flash('icon', "fa fa-check");
        session()->flash('message', "Package successfully restored");
        session()->flash('type', 'info');
    }
}