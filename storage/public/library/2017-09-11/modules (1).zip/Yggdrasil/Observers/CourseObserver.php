<?php

namespace Yggdrasil\Observers;

use Yggdrasil\Models\Course;
use Pluma\Models\Ownership;

class CourseObserver
{
    /**
     * Listen to the Course created event.
     *
     * @param  Course  $course
     * @return void
     */
    public function created(Course $course)
    {
        $ownership = new Ownership();
        $ownership->created_by = auth()->user()->id;
        $ownership->updated_by = auth()->user()->id;
        $ownership->user()->associate( auth()->user() );
        $ownership->save();

        $course->ownerships()->save( $ownership );

        session()->flash('title', $course->title);
        session()->flash('icon', "fa fa-check");
        session()->flash('message', "Course successfully saved");
        session()->flash('type', 'info');
    }

    /**
     * Listen to the Course updated event.
     *
     * @param  Course  $course
     * @return void
     */
    public function updated(Course $course)
    {
        // TODO: sync associated ownerships
        $ownership = Ownership::findOrFail( $course->ownerships()->first()->id );
        $ownership->updated_by = auth()->user()->id;
        $ownership->save();

        $course->ownerships()->save( $ownership );

        session()->flash('title', $course->title);
        session()->flash('icon', "fa fa-check");
        session()->flash('message', "Course successfully updated");
        session()->flash('type', 'info');
    }

    /**
     * Listen to the Course deleted event.
     *
     * @param  Course  $course
     * @return void
     */
    public function deleted(Course $course)
    {
        // $course->ownerships()->delete();
        session()->flash('title', $course->title);
        session()->flash('icon', "fa fa-check");
        session()->flash('message', "Course successfully deleted");
        session()->flash('type', 'info');
    }

    /**
     * Listen to the Course restored event.
     *
     * @param  Course  $course
     * @return void
     */
    public function restored(Course $course)
    {
        $course->ownerships()->restore();

        session()->flash('title', $course->title);
        session()->flash('icon', "fa fa-check");
        session()->flash('message', "Course successfully restored");
        session()->flash('type', 'info');
    }
}