<?php

namespace Yggdrasil\Policies;

use Pluma\Models\User;
use Yggdrasil\Models\Course;
use Illuminate\Auth\Access\HandlesAuthorization;

class CoursePolicy
{
    public function before($user, $ability)
    {
        if ( $user->isRoot() ) return true;
    }

    /**
     * Determine if the given user can be updated by the user.
     *
     * @param  \Pluma\Models\User  $user
     * @param  \Yggdrasil\Models\Course  $course
     * @return bool
     */
    public function update(User $user, User $resource)
    {
        return $user->id === $resource->id;
    }

    /**
     * Determine if the given user can be deleted by the user.
     *
     * @param  \Pluma\Models\User  $user
     * @param  \Yggdrasil\Models\Course  $course
     * @return bool
     */
    public function delete(User $user, Course $course)
    {
        // Prevent user from deleting self
        return $user->id !== $resource->id;
    }
}
