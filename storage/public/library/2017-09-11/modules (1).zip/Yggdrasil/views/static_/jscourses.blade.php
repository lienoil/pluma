@extends("Pluma::layouts.page")

@section("content")

    <div class="container-fluid">
        <div class="col-md-12">

            <div class="card">
                <div class="card-block">

                    @foreach ( $resources as $resource )
                        <p>{{ $resource->name }}</p>
                    @endforeach

                </div>
            </div>

        </div>
    </div>

@endsection