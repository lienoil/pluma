@extends('Pluma::layouts.static')
@section("content")


	<div class="fh5co-loader"></div>
	
	<div id="page">
		<nav class="fh5co-nav" role="navigation">
			<div class="top">
				<div class="container">
					<div class="row">
						<div class="col-xs-12 text-right">
							<p class="num">Call: + 65 6632 9536</p>
							<ul class="fh5co-social">
								<li><a href="#"><i class="icon-twitter"></i></a></li>
								<li><a href="#"><i class="icon-dribbble"></i></a></li>
								<li><a href="#"><i class="icon-github"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
			<div class="top-menu">
				<div class="container">
					<div class="row">
						<div class="col-xs-1">
							<div id="fh5co-logo"><a href="index.html"><img width="170" src="images/main.png" alt=""></a></div>
						</div>
						<div class="col-xs-11 text-right menu-1">
							<ul>
								<li class="active"><a href="#">Home</a></li>
								<li><a href="#">About Us</a></li>
								<li><a href="#">Services</a></li>
								<li class="has-dropdown">
									<a href="#">Courses</a>
									<ul class="dropdown">
										<li><a href="#">Web Design</a></li>
										<li><a href="#">eCommerce</a></li>
										<li><a href="#">Branding</a></li>
										<li><a href="#">API</a></li>
									</ul>
								</li>
								<li><a href="contact.html">Contact</a></li>
								<li><a href="#"><span>Login</span></a></li>
								<li class="btn-cta"><a href="#"><span>Sign Up</span></a></li>
							</ul>
						</div>
					</div>

				</div>
			</div>
		</nav>
		<header id="fh5co-header" class="fh5co-cover" role="banner" style="background-image:url(images/bg2.jpg);" data-stellar-background-ratio="0.5">
		<div class="overlay"></div>
			<div class="container">
				<div class="row">
					<div class="col-md-8 col-md-offset-2 text-center">
						<div class="display-t">
							<div class="display-tc animate-box" data-animate-effect="fadeIn">
								<h1>Contact Us</h1>
								<h2>SSA Academy provides customised programmes and solutions to address your specific needs. Send us your inquiries and we'll get back to you shortly.</h2>
								<section id="section05" class="demo"> <a href="#fh5co-contact"><span></span></a></section>
							</div>
						</div>
					</div>
				</div>
			</div>
		</header>

		<div id="fh5co-counter" class="fh5co-counters bg-dark light-ph">
			<div class="container">
				<div class="row form-group m-b-0">
					<div class="col-sm-6">
						<input type="text" id="subject" class="form-control" placeholder="Email Address">
					</div>
					<div class="col-sm-4">
						<select class="form-control col-sm-4" name="" id="">
							<option value="">Whick area would you like to assist you with?</option>
						</select>
					</div>
					<div class="col-sm-2"><a href="#" class="btn btn-primary m-t-1">Let's start</a></div>
				</div>
			</div>
		</div>

		<div id="fh5co-contact">
			<div class="container">
				<div class="row">
					<div class="col-md-5 col-md-push-1 animate-box">
						
						<div class="fh5co-contact-info">
							<h3>Contact Information</h3>
							
							<ul>
								<li>For corporate enquiries, <br> you may reach out to us via:</li>
								<li class="phone">+ 65 6632 9536</li>
								<li class="email"><a href="mailto:info@yoursite.com">info@yoursite.com</a></li>
								<li class="url">zaid@ssa.academy</li>
							</ul>
						</div>

					</div>
					<div class="col-md-6 animate-box">
						<h3>Get In Touch</h3>
						<form action="#">
							<div class="row form-group">
								<div class="col-md-6">
									<!-- <label for="fname">First Name</label> -->
									<input type="text" id="fname" class="form-control" placeholder="Your firstname">
								</div>
								<div class="col-md-6">
									<!-- <label for="lname">Last Name</label> -->
									<input type="text" id="lname" class="form-control" placeholder="Your lastname">
								</div>
							</div>

							<div class="row form-group">
								<div class="col-md-12">
									<!-- <label for="email">Email</label> -->
									<input type="text" id="email" class="form-control" placeholder="Your email address">
								</div>
							</div>

							<div class="row form-group">
								<div class="col-md-12">
									<!-- <label for="subject">Subject</label> -->
									<input type="text" id="subject" class="form-control" placeholder="Your subject of this message">
								</div>
							</div>

							<div class="row form-group">
								<div class="col-md-12">
									<!-- <label for="message">Message</label> -->
									<textarea name="message" id="message" cols="30" rows="10" class="form-control" placeholder="Say something about us"></textarea>
								</div>
							</div>
							<div class="form-group">
								<input type="submit" value="Send Message" class="btn btn-primary">
							</div>

						</form>		
					</div>
				</div>
				
			</div>
		</div>
		<div id="fh5co-started" style="background-image:url(images/bg.jpg);">
			<div class="overlay"></div>
			<div class="container">
				<div class="row animate-box">
					<div class="col-md-8 col-md-offset-2 text-center fh5co-heading">
						<h2>Lets Get Started</h2>
						<p>Dignissimos asperiores vitae velit veniam totam fuga molestias accusamus alias autem provident. Odit ab aliquam dolor eius.</p>
					</div>
				</div>
				<div class="row animate-box text-center">
					<p><a href="#" class="btn btn-primary">Sign up now!</a></p>
				</div>
			</div>
		</div>
		<footer id="fh5co-footer" role="contentinfo">
			<div class="container">
				<div class="row row-pb-md">
					<div class="col-md-3 fh5co-widget">
						<h4><img width="180" src="images/main.png" alt=""></h4>
						<p>Facilis ipsum reprehenderit nemo molestias. Aut cum mollitia reprehenderit. Eos cumque dicta adipisci architecto culpa amet.</p>
					</div>
					<div class="col-md-2 col-sm-4 col-xs-6 col-md-push-1">
						<h4>Pages</h4>
						<ul class="fh5co-footer-links">
							<li><a href="#">About Us</a></li>
							<li><a href="#">Courses</a></li>
							<li><a href="#">Services</a></li>
							<li><a href="#">Contact</a></li>
						</ul>
					</div>

					<div class="col-md-2 col-sm-4 col-xs-6 col-md-push-1">
						<h4>Learn &amp; Grow</h4>
						<ul class="fh5co-footer-links">
							<li><a href="#">Blog</a></li>
							<li><a href="#">Privacy</a></li>
							<li><a href="#">Testimonials</a></li>
							<li><a href="#">Handbook</a></li>
							<li><a href="#">Held Desk</a></li>
						</ul>
					</div>

					<div class="col-md-2 col-sm-4 col-xs-6 col-md-push-1">
						<h4>Engage us</h4>
						<ul class="fh5co-footer-links">
							<li><a href="#">Marketing</a></li>
							<li><a href="#">Visual Assistant</a></li>
							<li><a href="#">System Analysis</a></li>
							<li><a href="#">Advertise</a></li>
						</ul>
					</div>

					<div class="col-md-2 col-sm-4 col-xs-6 col-md-push-1">
						<h4>Legal</h4>
						<ul class="fh5co-footer-links">
							<li><a href="#">Find Designers</a></li>
							<li><a href="#">Find Developers</a></li>
							<li><a href="#">Teams</a></li>
							<li><a href="#">Advertise</a></li>
							<li><a href="#">API</a></li>
						</ul>
					</div>
				</div>

				<div class="row copyright">
					<div class="col-md-12 text-center">
						<p>
							<small class="block">&copy; 2017 SSA Consulting Group Pte. Ltd. All right reserved.</small>
						</p>
						<p>
							<ul class="fh5co-social-icons">
								<li><a href="#"><i class="icon-twitter"></i></a></li>
								<li><a href="#"><i class="icon-facebook"></i></a></li>
								<li><a href="#"><i class="icon-linkedin"></i></a></li>
								<li><a href="#"><i class="icon-dribbble"></i></a></li>
							</ul>
						</p>
					</div>
				</div>

			</div>
		</footer>
	</div>

	<div class="gototop js-top">
		<a href="#" class="js-gotop"><i class="icon-arrow-up"></i></a>
	</div>
@stop

@push('css')
	<style>
		.demo a {
		    position: absolute;
		    bottom: 20px;
		    left: 50%;
		    z-index: 2;
		    display: inline-block;
		    -webkit-transform: translate(0, -50%);
		    transform: translate(0, -50%);
		    color: #fff;
		    font : normal 400 20px/1 'Josefin Sans', sans-serif;
		    letter-spacing: .1em;
		    text-decoration: none;
		    transition: opacity .3s;
		}
		.demo a:hover {
		    opacity: .5;
		}

		#section05 a {
		    padding-top: 70px;
		  }
		  #section05 a span {
		    position: absolute;
		    top: 0;
		    left: 50%;
		    width: 24px;
		    height: 24px;
		    margin-left: -12px;
		    border-left: 2px solid #fff;
		    border-bottom: 2px solid #fff;
		    -webkit-transform: rotate(-45deg);
		    transform: rotate(-45deg);
		    -webkit-animation: sdb05 1.5s infinite;
		    animation: sdb05 1.5s infinite;
		    box-sizing: border-box;
		  }
		  @-webkit-keyframes sdb05 {
		    0% {
		      -webkit-transform: rotate(-45deg) translate(0, 0);
		      opacity: 0;
		    }
		    50% {
		      opacity: 1;
		    }
		    100% {
		      -webkit-transform: rotate(-45deg) translate(-20px, 20px);
		      opacity: 0;
		    }
		  }
		  @keyframes sdb05 {
		    0% {
		      transform: rotate(-45deg) translate(0, 0);
		      opacity: 0;
		    }
		    50% {
		      opacity: 1;
		    }
		    100% {
		      transform: rotate(-45deg) translate(-20px, 20px);
		      opacity: 0;
		    }
		}
	</style>
@endpush

@push('js')
	<script>
		$(function() {
			$('a[href*=#]').on('click', function(e) {
				e.preventDefault();
				$('html, body').animate({ scrollTop: $($(this).attr('href')).offset().top}, 500, 'linear');
			});
		});
	</script>
@endpush