@extends("Pluma::layouts.admin")

@section("content")
	@include("Pluma::partials.alert")
	<div class="container-fluid" id="content-tab-courses">
		<div class="row s12">
			{{-- <div class="pull-right m-b-3">
	            <a href="#" id="list" class="text-muted"><i class="fa fa-list info" aria-hidden="true"></i> List</a>
	            <span class="p-l-2 p-r-2"> | </span>
	            <a href="#" id="grid" class="text-muted p-r-2"><i class="fa fa-th info" aria-hidden="true"></i> Grid</a>
	        </div> --}}

			<div class="btn-group pull-right m-b-3" data-toggle="buttons">
				<label id="list" class="btn-flat waves-effect waves-yellow btn m-t-2 btn-default active">
					<input type="radio" name="options" id="option1" autocomplete="off" checked> <i class="fa fa-list info font-14" aria-hidden="true"></i></label>
				<label id="grid" class="btn-flat waves-effect waves-yellow btn m-t-2 btn-default">
					<input type="radio" name="options" id="option2" autocomplete="off"> <i class="fa fa-th info font-14" aria-hidden="true"></i></label>
			</div>

			<ul id="testDiv" class="tabs tabs-main">
				<li class="tab col s2"><a class="active" href="#courses">Courses</a></li>
				<li class="tab col s2"><a href="#current">Current</a></li>
				<li class="tab col s2"><a href="#previous">Previous</a></li>
				<li class="tab col s2"><a href="#recommended">Recommended</a></li>
				<li class="tab col s2"><a href="#bookmarked">Bookmarked</a></li>
			</ul>
		</div>

		<div id="courses" class="col s12">
			<div class="row">
				@foreach ( $resources as $i => $resource )
					<div class="item m-t-2 col-sm-4 col-sm-12">
						<div class="box no-border">
							<div class="box-body p-0">
									<div class="card horizontal no-shadow m-b-0">
									<div class="card-image card-box bg-psdm">
										<img src="{{ asset('default/src/images/courses/1.svg') }}">
									</div>
									<div class="card-stacked">
										<div class="card-content">
											<span class="card-title uppercase text-dark"><strong>{!! $resource->edit_link('courses', $resource->title) !!}</strong></span>
											<p>Course Overview Description</p>
										</div>
										<div class="card-action">
											@allow('update-course')
												<a href="{{ route('courses.edit', $resource->id) }}" class="waves-effect waves-yellow btn btn-default m-r-1">Edit</a>
											@endallow

											<a href="{{ route('courses.show', $resource->id) }}" class="waves-effect waves-light btn btn-yellow">View Course</a>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				@endforeach
			</div>
		</div>
		<div id="current" class="col s12">current</div>
		<div id="previous" class="col s12">previous</div>
		<div id="recommended" class="col s12">Recommended</div>
		<div id="bookmarked" class="col s12">Bookmarked</div>
	</div>
@endsection

@push('css')
@endpush

@push('js')
	<script src="{{ asset('default/assets/vendor/slimscroll/jquery.slimscroll.js') }}"></script>
	<script src="{{ asset('default/assets/vendor/slimscroll/examples/libs/prettify/prettify.js') }}"></script>
	<script>
		$( document ).ready(function() {
			prettyPrint();
	  		$('#testDiv').slimscroll({
				height: '100%;',
				width: '100%',
		    	axis: 'both'
			});
		});

		$(document).ready(function() {
			$('#list').click(function(event) {
		    	event.preventDefault();
		    	$('#content-tab-courses .item').removeClass('col-sm-4').addClass('col-sm-12');
			});

		    $('#grid').click(function(event) {
		    	event.preventDefault();
		    	$('#content-tab-courses .item').addClass('col-sm-4').removeClass('col-sm-12');
		    });
		});
	</script>
@endpush