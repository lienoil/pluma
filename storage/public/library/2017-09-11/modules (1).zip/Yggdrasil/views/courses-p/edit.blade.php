@extends("Pluma::layouts.admin")

@section("content")
    @include("Pluma::partials.alert")

    <div class="container-fluid">
        <form action="{{ route('courses.update', $resource->id) }}" method="POST">
            {{ csrf_field() }}
            {{ method_field('PUT') }}

            <div class="row">
                <div class="col-md-9">
                    <div class="box no-border">
                        <div class="box-header with-border">
                            <h3 class="box-title">Edit Course</h3>
                        </div>
                        <div class="box-body">
                            <div class="input-field">
                                <input type="text" name="title" class="validate inputfield m-b-0" value="{{ $resource->title }}" data-slugger>
                                <label class="inputtext" for="title">Title</label>
                                @include("Pluma::errors.span", ['field' => 'title'])
                            </div>

                            <div class="input-field">
                                <span class="slug inline">{{ route('public.show', 'courses') }}/</span>
                                <input name="slug" type="text" class="validate slug-form" readonly name="slug" value="{{ $resource->slug }}" placeholder="url-slug">
                                @include("Pluma::errors.span", ['field' => 'slug'])
                            </div>

                            <div class="input-field">
                                <input name="code" type="text" value="{{ $resource->code }}" class="validate inputfield">
                                <label class="inputtext" for="code">Course Code</label>
                                @include("Pluma::errors.span", ['field' => 'code'])
                            </div>

                            <div class="input-field m-0">
                                <textarea name="description" class="materialize-textarea inputfield textarea-rows">{{ $resource->description }}</textarea>
                                <label for="textarea1"  class="inputtext">Description</label>
                                @include("Pluma::errors.span", ['field' => 'description'])
                            </div>
                        </div>
                    </div>

                    <div class="box no-border clonable-block" data-toggle="cloner">
                        <div class="box-header with-border">
                            <h3 class="box-title">Content</h3>
                        </div>

                       <div data-explorer='{"view":"{{ route('content.explorer') }}","_token":"{{ csrf_token() }}","clonable":"true","sort":"true"}'>
                            <div class="box-body p-0">
                                <ul class="todo-list ui-sortable no-bg" data-clonable-template>
                                    {{-- <li class="blue-l-border clone-item" data-clone-source>
                                        <div class="well handle ui-sortable-handle block">
                                            <button type="button" class="close pull-right" data-clone-close><i class="fa fa-close"></i></button>
                                            <img src="" class="img-responsive" width="80" data-explorer-preview="">
                                            <h5 class="card-title text-muted" data-explorer-title>No Content</h5>

                                            <input type="hidden" data-clone-sort-name name="contents[0][id]" value="">
                                            <input type="hidden" data-clone-sort-name name="contents[0][content]" data-explorer-target>
                                            <input type="hidden" data-clone-sort-name name="contents[0][sort]" data-clone-sort-value value="1">
                                        </div>
                                    </li> --}}

                                    @foreach ( $resource->collected_contents as $contents )
                                        <li class="clone-item p-0 m-0" style="border-left: none !important;">
                                            <div class="card horizontal move border-bottom ui-sortable-handle z-depth-0 m-0">
                                                <div class="card-image" style="max-width: 20% !important;">
                                                    <img src="{{ $contents->content->thumbnail }}" class="img-responsive p-1" width="80" data-explorer-preview="">
                                                </div>
                                                <div class="card-stacked">
                                                    <div class="card-content">
                                                        <p data-explorer-title>{{ $contents->content->name }}</p>
                                                    </div>
                                                    <div class="card-action p-1 pointer">
                                                        <a class="text-red text-right pointer pull-right" type="button" data-clone-close>Remove</a>
                                                    </div>
                                                </div>


                                                <input type="hidden" data-clone-sort-name name="contents[0][id]" value="{{ $contents->id }}">
                                                <input type="hidden" data-clone-sort-name name="contents[0][content]" value='{{ json_encode( $contents->content ) }}' data-explorer-target>
                                                <input type="hidden" data-clone-sort-name name="contents[0][sort]" value="{{ $contents->sort }}" data-clone-sort-value>
                                            </div>
                                        </li>
                                    @endforeach
                                </ul>
                            </div>
                            <div class="card-footer">
                                <div class="form-group m-0 p-0">
                                    @include("Pluma::errors.span", ['field' => 'contents'])
                                </div>
                                <button data-explorer-trigger class="btn waves-effect waves-yellow btn-default pull-right" type="button">Add Content</button>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-3">
                    @include("Pluma::partials.widget-saving", ['label' => 'Update'])
                    @include("Pluma::partials.widget-featured-image", ['editing' => 1, 'resource' => $resource])
                    {{-- @include("Pluma::categories.widget") --}}
                </div>
            </div>
        </form>
    </div>
@endsection

@push('css')
<link rel="stylesheet" href="{{ assets('Pluma/vendor/jquery-file-explorer/dist/css/jquery.file-explorer.min.css') }}">
@endpush

@push("js")
    <script src="{{ assets('Pluma/vendor/jquery-slugger/dist/jquery.slugger.min.js') }}"></script>
    <script src="{{ assets('Pluma/vendor/jquery-file-explorer/jquery-custom/jquery-ui-1.12.1.custom/jquery-ui.min.js') }}"></script>
    <script src="{{ assets('Pluma/vendor/jquery-file-explorer/dist/js/jquery.file-explorer.js') }}"></script>
@endpush