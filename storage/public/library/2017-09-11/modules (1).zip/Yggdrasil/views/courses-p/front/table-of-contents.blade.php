@foreach ( $contents as $content )
    @if ( ! $content->viewable )
        {{-- <div class="list-group-item"> --}}
            <i class="fa fa-lock">&nbsp;</i>{{ $content->content->name }}
            {{-- {{ $content->id }} --}}
        </div>
    @else
        {{-- <a href="{{ route('courses.contents.show', [$course->slug, $content->id]) }}" class="list-group-item {{ $id == $content->id ? 'active' : '' }}">
            {{ $content->content->name }}
        </a> --}}

    @endif
@endforeach

<div class="box no-border">
    <div class="box-header with-border">
        <h3 class="box-title">Table of Contents</h3>
    </div>
    <div class="box-body">
        <ul class="collapsible popout" data-collapsible="expandable">
            <li>
                <div class="collapsible-header {{ $id == $content->id ? 'active' : '' }}"><i class="fa fa-unlock" style="color: #6d6d6d;" aria-hidden="true"></i>Intro</div>
                <div class="collapsible-body bg-light">
                    <ul class="collection">
                        <li>
                            <a class="collection-item avatar" href="{{ route('courses.contents.show', [$course->slug, $content->id]) }}" class="list-group-item {{ $id == $content->id ? 'active' : '' }}">
                                <span class="circle"><i class="fa fa-check-circle" style="font-size: 42px; color: #00a65a;"aria-hidden="true"></i></span>
                                <p class="title text-dark">{{ $content->content->name }}</p>
                                <p class="text-dark">{{ $content->content->description }}</p>
                                <div class="secondary-content"><i class="material-icons">100%</i></div>
                            </a>
                        </li>
                        <li>
                            <a class="collection-item avatar" href="#!" class="list-group-item">
                                <span class="circle"><i class="fa fa-check-circle" style="font-size: 42px; color: #00a65a;"aria-hidden="true"></i></span>
                                <p class="title text-dark">Title</p>
                                <p class="text-dark">Description</p>
                                <div class="secondary-content"><i class="material-icons">100%</i></div>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li>
                <div class="collapsible-header"><i class="fa fa-lock" style="color: #6d6d6d;" aria-hidden="true"></i>PS 1</div>
                <div class="collapsible-body"><span>Lorem ipsum dolor sit amet.</span></div>
            </li>
            <li>
                <div class="collapsible-header"><i class="fa fa-lock" style="color: #6d6d6d;" aria-hidden="true"></i>PS 2</div>
                <div class="collapsible-body"><span>Lorem ipsum dolor sit amet.</span></div>
            </li>
            <li>
                <div class="collapsible-header"><i class="fa fa-lock" style="color: #6d6d6d;" aria-hidden="true"></i>PS 3</div>
                <div class="collapsible-body"><span>Lorem ipsum dolor sit amet.</span></div>
            </li>
        </ul>
    </div>
</div>

@push('js')
    <script>
        $(document).ready(function(){
            $('.modal').modal();
        });
    </script>
@endpush