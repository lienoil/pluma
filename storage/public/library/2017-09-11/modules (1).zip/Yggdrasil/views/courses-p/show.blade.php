@extends("Pluma::layouts.admin")

@section("content")
    @include("Pluma::partials.alert")

    <div class="container-fluid">
        <div class="box no-border">
            <div class="box-header with-border">
                <h3 class="box-title">Preview Course</h3>
            </div>
            <div class="box-body p-0">
                <div class="card horizontal no-shadow m-b-0">
                    <div class="card-image card-box bg-psdm">
                        <img src="{{ asset('default/src/images/courses/1.svg') }}">
                    </div>
                    <div class="card-stacked card-box">
                        <div class="card-content">
                            <span class="card-title uppercase"><strong>{{ $resource->title }}</strong></span>
                            <p>Course Overview Description</p>
                            <a href="{{ route('courses.edit', $resource->id) }}" class="waves-effect waves-yellow btn btn-default m-t-2 m-r-1">Edit</a>
                            <a href="#!" class="waves-effect waves-default btn btn-yellow m-t-2">Resume</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="box no-border">
            <div class="box-header with-border">
                <h3 class="box-title">Sub modules</h3>
            </div>
            <div class="box-body">
                <ul class="collapsible popout" data-collapsible="expandable">
                    <li>
                        <div class="collapsible-header"><i class="fa fa-unlock" style="color: #6d6d6d;" aria-hidden="true"></i>Intro</div>
                        <div class="collapsible-body">
                            <ul class="collection">
                                @foreach ( $resource->collected_contents as $contents )
                                    <li>
                                        <a class="collection-item avatar" href="{{ route('courses.contents.show', [$resource->slug, $contents->id]) }}">
                                            <span class="circle"><i class="fa fa-check-circle" style="font-size: 42px; color: #00a65a;"aria-hidden="true"></i></span>
                                            <p class="title text-dark">{{ $contents->content->name }}</p>
                                            <span class="text-dark">{{ $contents->content->description }}</span>
                                            <p class="text-dark">Some text here.</p>
                                            <div class="secondary-content"><i class="material-icons">100%</i></div>
                                        </a>
                                    </li>
                                @endforeach
                            </ul>
                        </div>
                    </li>
                    <li>
                        <div class="collapsible-header"><i class="fa fa-lock" style="color: #6d6d6d;" aria-hidden="true"></i>PS 1</div>
                        <div class="collapsible-body"><span>Lorem ipsum dolor sit amet.</span></div>
                    </li>
                    <li>
                        <div class="collapsible-header"><i class="fa fa-lock" style="color: #6d6d6d;" aria-hidden="true"></i>PS 2</div>
                        <div class="collapsible-body"><span>Lorem ipsum dolor sit amet.</span></div>
                    </li>
                    <li>
                        <div class="collapsible-header"><i class="fa fa-lock" style="color: #6d6d6d;" aria-hidden="true"></i>PS 3</div>
                        <div class="collapsible-body"><span>Lorem ipsum dolor sit amet.</span></div>
                    </li>
                </ul>
            </div>
        </div>
    </div>
@endsection

@push('css')
@endpush

@push('js')
@endpush