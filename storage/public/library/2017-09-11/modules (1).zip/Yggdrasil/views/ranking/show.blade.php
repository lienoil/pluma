@extends("Pluma::layouts.admin")
@section('content')
<div class="container-fluid">
	<div class="box no-border">
        <div class="box-header with-border bg-info">
            <span class="card-title text-light">[Trainer's Name] Evaluation Details</span>
        </div>
        <div class="box-body table-responsive">
			<table class="bordered">
				<thead>
				<tr>
					<td colspan="4">Course Title</td>
					<td colspan="4">[Title]</td>
				</tr>
				<tr>
		        	<td colspan="4">No of Participants Attended the Course</td>
		        	<td colspan="4">13</td>
				</tr>
				<tr>
		        	<td colspan="4">No of Participants Responded the Course</td>
		        	<td colspan="4">13</td>
				</tr>
				</thead>

				<tbody>
					<tr>
						<td>#</td>
						<th>Question</th>
						<td class="text-center"><strong>SD</strong></td>
						<td class="text-center"><strong>Disagree</strong></td>
						<td class="text-center"><strong>Neutral</strong></td>
						<td class="text-center"><strong>Agree</strong></td>
						<td class="text-center"><strong>SA</strong></td>
						<td class="text-center"><strong>Total</strong></td>
					</tr>
					<tr>
						<td></td>
						<td colspan="6" class="text-green text-uppercase"><strong>Course Objectives / Facilities / Environment</strong></td>
						<td class="text-center"><strong>95%</strong></td>
					</tr>
					<tr>
						<td>1</td>
						<td>Course has met my objectives and expectations.</td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center">95%</td>
					</tr>
					<tr>
						<td>2</td>
						<td>Course content is covered in adequate depth.</td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center">95%</td>
					</tr>
					<tr>
						<td>3</td>
						<td>Course materials (eg notes) are of high quality and useful for future reference.</td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center">95%</td>
					</tr>
					<tr>
						<td>4</td>
						<td>Classroom environment & facilities are conducive for learning.</td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center">95%</td>
					</tr>
					<tr>
						<td>5</td>
						<td>Concepts and skills presented will be useful and relevant to my work.</td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center">95%</td>
					</tr>
					<tr>
						<td>6</td>
						<td>Duration of the course is adequate.</td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center">95%</td>
					</tr>
					<tr>
						<td>7</td>
						<td>Customer service provided by SSA is professional and of high quality.</td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center">95%</td>
					</tr>

					<tr>
						<td></td>
						<td colspan="6" class="text-green text-uppercase"><strong>Trainer's Performance</strong></td>
						<td class="text-center"><strong>95%</strong></td>
					</tr>
					<tr>
						<td></td>
						<td colspan="7">The trainer(s) is(are) able to:</td>
					</tr>
					<tr>
						<td>8</td>
						<td>Demonstrate expertise in the content field being trained.</td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center">95%</td>
					</tr>
					<tr>
						<td>9</td>
						<td>Provide well-paced, appropriately sequenced lessons that flow effectively from one activity to another.</td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center">95%</td>
					</tr>
					<tr>
						<td>10</td>
						<td>Establish rapport with the participants with confidence, enthusiasm and humour.</td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center">95%</td>
					</tr>
					<tr>
						<td>11</td>
						<td>Motivate learners to become engaged and stay on task during lessons.</td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center">95%</td>
					</tr>
					<tr>
						<td>12</td>
						<td>Provide clear explanations and adequate time for learners to ask and answer questions.</td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center">95%</td>
					</tr>
					<tr>
						<td>13</td>
						<td>Encourage participants to participate actively and use their own experiences to illustrate and clarify learning.</td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center">95%</td>
					</tr>
					<tr>
						<td>14</td>
						<td>Provide individual and group opportunities to learn and practise skills.</td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center">95%</td>
					</tr>
					<tr>
						<td>15</td>
						<td>Provide opportunities for participants to develop communication skills.</td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center">95%</td>
					</tr>

					<tr>
						<td></td>
						<td colspan="6" class="text-green text-uppercase"><strong>Overall Performance</strong></td>
						<td class="text-center"><strong>95%</strong></td>
					</tr>

					<tr>
						<td>16</td>
						<td>SSA  is a great and enjoyable place for participants to learn new competency skills.</td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center">95%</td>
					</tr>
					<tr>
						<td>17</td>
						<td>SSA's trainer is sincere and warm.</td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center">95%</td>
					</tr>
					<tr>
						<td>18</td>
						<td>I have learnt and acquired new skills and attained the relevant competencies that I can immediately apply in any environment. I feel GREAT after attending this programme.</td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center"></td>
						<td class="text-center">95%</td>
					</tr>
					<tr>
						<td></td>
						<td colspan="6" class="text-green text-uppercase"><strong>Course Evaluation</strong></td>
					</tr>

					<tr>
						<td>19</td>
						<td colspan="7">What I like most about this course?
						<p class="p-t-2"><strong>Answer:</strong> </p>
						<p class="p-l-2 p-r-2">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sint quos officia ipsa nobis voluptas eaque voluptates quibusdam distinctio. Vero, ea esse provident deleniti. Explicabo veritatis dolorum nihil? Omnis, nulla, pariatur.</p>
						</td>
					</tr>
					<tr>
						<td>20</td>
						<td colspan="7">What I DISLIKE most about this course?
						<p class="p-t-2"><strong>Answer:</strong> </p>
						<p class="p-l-2 p-r-2">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sint quos officia ipsa nobis voluptas eaque voluptates quibusdam distinctio. Vero, ea esse provident deleniti. Explicabo veritatis dolorum nihil? Omnis, nulla, pariatur.</p>
						</td>
					</tr>
					<tr>
						<td>21</td>
						<td colspan="7">Any other comments?
						<p class="p-t-2"><strong>Answer:</strong> </p>
						<p class="p-l-2 p-r-2">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sint quos officia ipsa nobis voluptas eaque voluptates quibusdam distinctio. Vero, ea esse provident deleniti. Explicabo veritatis dolorum nihil? Omnis, nulla, pariatur.</p>
						</td>
					</tr>
				</tbody>
				<tfoot>
					<tr>
						<td colspan="7"><strong>Total Score</strong></td>
						<td><strong>95%</strong></td>
					</tr>
				</tfoot>
			</table>
		</div>
	</div>
</div>
@endsection

@push('css')
	<style>
		.progress-img {
			min-width: 100% !important;
		}

		.bg-success {
			background: #009688 !important;
		}

		.text-success {
			color: #009688;
		}

		.bg-warning {
			background: #F58720 !important;
		}

		.text-warning {
			color: #F58720;
		}

		.bg-danger {
			background: #D8462A !important;
		}

		.text-danger {
			color: #D8462A;
		}

		.text-light {
			color: #fff !important;
		}

		.bg-light-gray {
			background: #d8d8d8;
		}
	</style>
@endpush