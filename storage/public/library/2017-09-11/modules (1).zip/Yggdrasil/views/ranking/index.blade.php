@extends("Pluma::layouts.admin")
@section('content')
<div class="container-fluid">
	<div class="box no-border">
        <div class="box-header with-border">
            <h3 class="box-title">Rankings of Trainers</h3>
        </div>
        <div class="box-body p-0">
			<div class="table-responsive">
				<table class="bordered">
					<thead>
						<tr>
							<th>Trainer's Name</th>
							<th>Courses</th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td><a href="ranking/show">Anne Hathaway</a></td>
							<td>
								<ul class="collapsible no-shadow" data-collapsible="accordion">
									<li>
										<div class="collapsible-header"><span class="new badge">3</span><i class="icon-books">&nbsp;</i>Click to view Courses</div>
										<div class="collapsible-body">
											<ul class="collection">
											    <li class="collection-item no-border avatar">
											      	<img src="https://placeimg.com/640/480/nature" alt="" class="circle">
											      	<span class="title">Course Title</span>
											      	<p>Description</p>
											      	<a href="ranking/show" class="secondary-content">View Grades</a>
											    </li>
											    <li class="collection-item no-border avatar">
											      	<img src="https://placeimg.com/640/480/nature" alt="" class="circle">
											      	<span class="title">Course Title</span>
											      	<p>Description</p>
											      	<a href="ranking/show" class="secondary-content">View Grades</a>
											    </li>
											    <li class="collection-item no-border avatar">
											      	<img src="https://placeimg.com/640/480/nature" alt="" class="circle">
											      	<span class="title">Course Title</span>
											      	<p>Description</p>
											      	<a href="ranking/show" class="secondary-content">View Grades</a>
											    </li>
											  </ul>
										</div>
									</li>
								</ul>
							</td>
						</tr>
						<tr>
							<td><a href="ranking/show">Sam Smith</a></td>
							<td>
								<ul class="collapsible no-shadow" data-collapsible="accordion">
									<li>
										<div class="collapsible-header"><span class="new badge">2</span><i class="icon-books">&nbsp;</i>Click to view Courses</div>
										<div class="collapsible-body">
											<ul class="collection">
											    <li class="collection-item no-border avatar">
											      	<img src="https://placeimg.com/640/480/nature" alt="" class="circle">
											      	<span class="title">Course Title</span>
											      	<p>Description</p>
											      	<a href="ranking/show" class="secondary-content">View Grades</a>
											    </li>
											    <li class="collection-item no-border avatar">
											      	<img src="https://placeimg.com/640/480/nature" alt="" class="circle">
											      	<span class="title">Course Title</span>
											      	<p>Description</p>
											      	<a href="ranking/show" class="secondary-content">View Grades</a>
											    </li>
											  </ul>
										</div>
									</li>
								</ul>
							</td>
						</tr>
						<tr>
							<td><a href="ranking/show">Jane Doe</a></td>
							<td>
								<ul class="collapsible no-shadow" data-collapsible="accordion">
									<li>
										<div class="collapsible-header"><span class="new badge">2</span><i class="icon-books">&nbsp;</i>Click to view Courses</div>
										<div class="collapsible-body">
											<ul class="collection">
											    <li class="collection-item no-border avatar">
											      	<img src="https://placeimg.com/640/480/nature" alt="" class="circle">
											      	<span class="title">Course Title</span>
											      	<p>Description</p>
											      	<a href="ranking/show" class="secondary-content">View Grades</a>
											    </li>
											    <li class="collection-item no-border avatar">
											      	<img src="https://placeimg.com/640/480/nature" alt="" class="circle">
											      	<span class="title">Course Title</span>
											      	<p>Description</p>
											      	<a href="ranking/show" class="secondary-content">View Grades</a>
											    </li>
											  </ul>
										</div>
									</li>
								</ul>
							</td>
						</tr>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
@endsection


@push('css')
	<style>
		span.badge.new {
		    /*content: " courses" !important;*/
		    background: #fdbe3c !important;
		    color: #000 !important;
		}
		span.badge.new:after {
		    content: " courses" !important;
		    /*background: #fdbe3c !important;*/
		}
		.no-border {
			border-bottom: none !important;
		}
		.collection .collection-item {
			border: none !important;
		}
	</style>
@endpush

@push('js')

@endpush