@extends("Pluma::layouts.admin")

@section('content')
	<div class="container-fluid">
		<div class="box no-border">
			<div class="box-header with-border">
				<h3 class="box-title">Create Evaluation Form</h3>
			</div>
			<div class="box-body">
				Test Evaluation Form (table)
			</div>
		</div>
	</div>
@endsection