@extends('Pluma::layouts.static')
@section("content")

	<div class="fh5co-loader"></div>
	<div id="page">
		<nav class="fh5co-nav" role="navigation">
			<div class="top">
				<div class="container">
					<div class="row">
						<div class="col-xs-12 text-right">
							<p class="num">Call: + 65 6632 9536</p>
							<ul class="fh5co-social">
								<li><a href="https://twitter.com/training_ssa"><i class="icon-twitter"></i></a></li>
								<li><a href="https://www.facebook.com/ssatraining"><i class="icon-facebook"></i></a></li>
								<li><a href="http://www.linkedin.com/company/ssa-consulting-group"><i class="icon-linkedin"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
			<div class="top-menu">
				<div class="container">
					<div class="row">
						<div class="col-xs-3">
							<div id="fh5co-logo"><a href="../"><img width="170" src="{{ asset('default/assets/img/main.png')}}" alt=""></a></div>
						</div>
						<div class="col-xs-9 text-right menu-1">
							<ul>
								<li><a href="../">Home</a></li>
								<li class="active"><a href="about">About Us</a></li>
								<li><a href="solutions">Our Solutions</a></li>
								<li class="has-dropdown">
									<a href="courses-x">Courses</a>
									<ul class="dropdown">
										<li><a href="csuite">C-Suite</a></li>
										<li><a href="emerging">Emerging C-Suite and Middle Management</a></li>
										<li><a href="wps">Workplace Skills</a></li>
									</ul>
								</li>
								<li><a href="contact">Contact</a></li>
								<li><a href="admin/login"><span>Login</span></a></li>
								<li class="btn-cta"><a href="admin/register"><span>Sign Up</span></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</nav>
		<header id="fh5co-header" class="fh5co-cover" role="banner" style="background-image:url({{ asset('default/assets/vendor/learn/images/bg2.jpg')}});"
		data-stellar-background-ratio="0.5">
		<div class="overlay"></div>
			<div class="container">
				<div class="row">
					<div class="col-md-8 col-md-offset-2 text-center">
						<div class="display-t">
							<div class="display-tc animate-box" data-animate-effect="fadeIn">
								<h1>About Us</h1>
								<h2>We are the learning partner of enterprises, organizations and governments.</h2>
								<section id="section05" class="demo"> <a href="#fh5co-project"><span></span></a></section>
							</div>
						</div>
					</div>
				</div>
			</div>
		</header>

		<div id="fh5co-counter" class="fh5co-counters bg-dark light-ph">
			<div class="container">
				<div class="row form-group m-b-0">
					<div class="col-sm-6">
						<input type="text" id="subject" class="form-control m-b-05" placeholder="Email Address">
					</div>
					<div class="col-sm-4 custom-dropdown m-b-05">
						<select class="customSelect form-control col-sm-4" name="" id="">
							<option value="">Which area would you like us to assist you with?</option>
						</select>
					</div>
					<div class="col-sm-2"><a href="#" class="btn btn-primary btn-started">Let's start</a></div>
				</div>
			</div>
		</div>


		<div id="fh5co-project">
			<div class="container">
				<div class="row">
					<div class="col-md-6 m-b-2">
						<h2 class="text-dark-primary">SSA Academy</h2>
						<p class="animate-box">SSA Academy is a member of the SSA Group of companies anchored by SSA Consulting Group Pte Ltd (SSA CG). SSA C G is an umbrella corporation providing professional services, for nearly three decades, in the areas of training, management consulting, public accounting, estate planning.  SSA CG has been consistently ranked among the top 1,000 SMEs in Singapore (2011-2014). To date, we have consulted for more than 200 companies, business enterprises and non-profit organisations and trained more than 100,000 members of Singapore's workforce.</p>

						<p class="animate-box">SSA Academy serves the learning and development needs of both C-Suite as well as middle management executives with a deep focus on building capabilities to drive higher corporate performance and to enable executives to be more nimble and agile in the future economy.</p>
					</div>
					<div class="col-md-5 col-md-offset-1 text-center m-t-2">
						<img class="img-responsive" src="http://placehold.it/350x150">
					</div>
				</div>
			</div>
		</div>

		<div id="fh5co-explore" class="fh5co-bg-section">
			<div class="container">
				<div class="row animate-box">
					<div class="col-md-6 col-md-offset-3 text-center fh5co-heading">
						<h2 class="text-dark-primary">Key Executives</h2>
					</div>
				</div>
			</div>
			<div class="fh5co-explore fh5co-explore1">
				<div class="container">
					<div class="row">
						<div class="col-md-5 col-md-offset-1 animate-box">
							<img class="img-responsive border-dark" src="{{ asset('default/assets/vendor/learn/images/suhaimi.png') }}" alt="work">
						</div>
						<div class="col-md-6 animate-box">
							<div class="mt">
								<h3>SUHAIMI SALLEH, <em>Chief Executive Officer</em></h3>
								<p>As the founder and Chief Executive Officer of SSA Consulting Group, Suhaimi Salleh has more than 30 years of experience in management consultancy in human resource development, organizational development, productivity management, audit, finance, and strategic planning in a broad array of industries in Singapore, Malaysia, Indonesia, Brunei, and the Philippines.</p>
							</div>
						</div>
					</div>
				</div>
			</div>

			<div class="fh5co-explore">
				<div class="container">
					<div class="row">
						<div class="col-md-6 animate-box">
							<div class="mt">
								<h3>AFFANDI SALLEH, <em>Chief Operating Officer</em></h3>
								<p>With over a quarter century of diverse experience in management consultancy, Affandi is the Chief Operating Officer of SSA Consulting Group. His consultancy work has spanned corporate and strategic planning, industrial management, organizational development, acquisition, project management, computerization and standardization, procurement and negotiation, marketing, public relations, finance, accounting, ISO 9000, and human resource management.</p>
							</div>
						</div>
						<div class="col-md-5 col-md-offset-1 animate-box">
							<img class="img-responsive border-dark" src="{{ asset('default/assets/vendor/learn/images/affandi.png') }}" alt="work">
						</div>
					</div>
				</div>
			</div>
		</div>

		<div id="fh5co-explore">
			<div class="container">
				<div class="animate-box">
					<div class="col-md-8 col-md-offset-2 text-center fh5co-heading">
						<h2 class="text-dark-primary">Our Mission</h2>
						<p>To build the capabilities of enterprises, organizations and government agencies through our performance-based experiential, adaptive and agile learning (“PEbAAL”) pedagogy and to help our customers become more adaptive and agile in this increasingly complex business environment.</p>
					</div>

					<div class="col-md-8 col-md-offset-2 text-center fh5co-heading">
						<h2 class="text-dark-primary">Our Vision</h2>
						<p>To be the leading integrated lifelong service provider nurturing talents for the future economy through the provision of innovative and tailored learning contents delivered through agile technology platforms.</p>
					</div>
				</div>
			</div>
		</div>

		<div id="fh5co-started" style="background-image:url({{ asset('default/assets/vendor/learn/images/bg.jpg') }});">
			<div class="overlay"></div>
			<div class="container">
				<div class="row animate-box">
					<div class="col-md-8 col-md-offset-2 text-center fh5co-heading">
						<h2>Let's Get Started</h2>
						<p>SSA Academy provides customised programmes and solutions to address your specific needs. Send us your inquiries and we'll get back to you shortly.</p>
					</div>
				</div>
				<div class="row animate-box text-center">
					<p><a href="admin/register" class="btn btn-primary">Sign up now!</a></p>
				</div>
			</div>
		</div>

		<footer id="fh5co-footer" role="contentinfo">
			<div class="container">
				<div class="row copyright">
					<div class="col-md-12 text-center m-t-3">
						<p>
							<small class="block">&copy; 2017 SSA Consulting Group Pte. Ltd. All rights reserved.</small>
						</p>
						<p>
							<ul class="fh5co-social-icons">
								<li><a href="https://twitter.com/training_ssa"><i class="icon-twitter"></i></a></li>
								<li><a href="https://www.facebook.com/ssatraining"><i class="icon-facebook"></i></a></li>
								<li><a href="http://www.linkedin.com/company/ssa-consulting-group"><i class="icon-linkedin"></i></a></li>
							</ul>
						</p>
					</div>
				</div>

			</div>
		</footer>
	</div>

	<div class="gototop js-top">
		<a href="#" class="js-gotop"><i class="icon-arrow-up"></i></a>
	</div>
@stop

@push('js')
	<script>
		$(function() {
			$('a[href*=#]').on('click', function(e) {
				e.preventDefault();
				$('html, body').animate({ scrollTop: $($(this).attr('href')).offset().top}, 500, 'linear');
			});
		});
	</script>
@endpush
