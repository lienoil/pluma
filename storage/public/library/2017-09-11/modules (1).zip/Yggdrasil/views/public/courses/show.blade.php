@extends("Pluma::layouts.page")

@section("content")

    <div class="container-fluid">
        <div class="col-md-3">
            @include("Yggdrasil::public.partials.table-of-contents", ['course' => $resource, 'id' => $resource->id, 'contents' => $resource->collected_contents])
        </div>

        <div class="col-md-9">

            <div class="card">
                {!! $resource->thumbnail !!}

                <div class="card-block">
                    <h3><a href="{{ route('public.course.show', $resource->slug) }}">{{ $resource->title }}</a></h3>
                    {{ $resource->description }}
                </div>

                @foreach ( $resource->collected_contents as $content )
                    <div class="card-block">
                        <h5><a href="{{ route('public.course.content.show', [$resource->slug, $content->id]) }}">{{ $content->content->name }}</a></h5>
                    </div>
                @endforeach
            </div>

        </div>
    </div>

@endsection


@push('css')
    <style>
        body {
            background-color: #f2f2f2 !important;
        }
    </style>
@endpush