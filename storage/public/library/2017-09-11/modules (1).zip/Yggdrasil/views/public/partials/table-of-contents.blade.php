<div class="collection with-header">
    <div class="collection-header">
        <p>Table of Contents</p>
    </div>

    @foreach ( $contents as $content )
        <a href="{{ route('public.course.content.show', [$course->slug, $content->id]) }}" class="collection-item {{ $content->id == $id ? 'active' : '' }}">
            <p class="collection-item-title"><img src="{{ $content->content->thumbnail }}" width="40"> {{ $content->content->name }}</p>
        </a>
    @endforeach
</div>