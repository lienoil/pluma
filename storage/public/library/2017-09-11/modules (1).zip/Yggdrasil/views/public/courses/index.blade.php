@extends("Pluma::layouts.page")

@section("content")

    <div class="container-fluid">
        <div class="col-md-12">
            @foreach ( $resources as $resource )
                <div class="card">
                    {!! $resource->thumbnail !!}
                    <div class="card-block">
                        <h3><a href="{{ route('public.course.show', $resource->slug) }}">{{ $resource->title }}</a></h3>
                        {{ $resource->description }}
                    </div>

                    <div class="card-footer">
                        <a href="{{ route('courses.show', $resource->id) }}" class="btn btn-secondary">Show</a>
                    </div>

                </div>
            @endforeach
        </div>
    </div>

@endsection


@push('css')
    <style>
        body {
            background-color: #f2f2f2 !important;
        }
    </style>
@endpush