@extends("Pluma::layouts.admin")

@section("title", 'Edit Lesson')

@section("content")

    <div class="container-fluid">
        <div class="col-sm-12">
            <h3 class="page-title">Edit Lesson</h3>
        </div>
    </div>

    @include("Pluma::partials.alert")

    <form action="{{ route('lessons.update', $resource->id) }}" method="POST" enctype="multipart/form-data">
        {{ csrf_field() }}
        {{ method_field('PUT') }}
        <div class="container-fluid">
            <div class="col-lg-9">
                <div class="card">
                    <div class="card-block">
                        <div class="form-group">
                            <input type="text" name="title" class="form-control form-control-dashed post-title" value="{{ $resource->title }}" placeholder="Title" data-slugger>
                            @include("Pluma::errors.span", ['field' => 'title'])
                        </div>
                        <div class="form-group">
                            <div class="input-group text-sm">
                                <span class="input-group-addon text-muted input-group-addon-dotted">{{ route('public.show', 'lessons') }}/</span>
                                <input type="text" readonly class="form-control form-control-dashed post-slug" name="slug" value="{{ $resource->slug }}" placeholder="url-slug">
                            </div>
                            @include("Pluma::errors.span", ['field' => 'slug'])
                        </div>
                        <div class="form-group">
                            <input type="text" name="code" class="form-control form-control-dashed" value="{{ $resource->code }}" placeholder="Lesson Code">
                        </div>
                    </div>
                    <div class="card-block card-item">
                        <div class="form-group">fac

                            <label for="description" class="text-muted">
                            <strong>Content</strong>
                                <br>
                                <span class="text-muted">The video/interactive content</span>
                            </label>
                            <div class="drop">
                                <div class="drop-block">
                                    {{-- <input type="hidden" name="content"> --}}
                                </div>
                            </div>
                            @include("Pluma::errors.span", ['field' => 'content'])
                        </div>
                        <div class="btn-group">
                            <input class="btn btn-secondary" type="file" name="content" value="{{ $resource->content }}">Add Media</input>
                        </div>
                    </div>
                    <div class="card-block card-item">
                        <div class="form-group">
                            <label for="description" class="text-muted">
                                <strong>Description</strong>
                                <br>
                                <span class="text-muted">A brief overview about the video/interactive content</span>
                            </label>
                            <textarea id="description" name="description" cols="30" rows="10" class="form-control form-control-dashed post-description">{{ $resource->description }}</textarea>
                            @include("Pluma::errors.span", ['field' => 'description'])
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-3">
                @include("Pluma::partials.widget-saving")
            </div>
        </div>
    </form>

@endsection

@push("js")
    <script src="{{ assets('Pluma/vendor/jquery-slugger/dist/jquery.slugger.min.js') }}"></script>
    <script src="{{ assets('Pluma/vendor/jquery-cloner/dist/jquery.cloner.min.js') }}"></script>
    <script src="//cdn.tinymce.com/4/tinymce.min.js"></script>
    <script>
  var editor_config = {
    path_absolute : "/",
    selector: "textarea#description",
    plugins: [
      "advlist autolink lists link image charmap print preview hr anchor pagebreak",
      "searchreplace wordcount visualblocks visualchars code fullscreen",
      "insertdatetime media nonbreaking save table contextmenu directionality",
      "emoticons template paste textcolor colorpicker textpattern"
    ],
    toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image media",
    relative_urls: false,
    file_browser_callback : function(field_name, url, type, win) {
      var x = window.innerWidth || document.documentElement.clientWidth || document.getElementsByTagName('body')[0].clientWidth;
      var y = window.innerHeight|| document.documentElement.clientHeight|| document.getElementsByTagName('body')[0].clientHeight;

      var cmsURL = editor_config.path_absolute + 'admin/courses/create?field_name=' + field_name;
      if (type == 'image') {
        cmsURL = cmsURL + "&type=Images";
      } else {
        cmsURL = cmsURL + "&type=Files";
      }

      tinyMCE.activeEditor.windowManager.open({
        file : cmsURL,
        title : 'File manager',
        width : x * 0.8,
        height : y * 0.8,
        resizable : "yes",
        close_previous : "no"
      });
    }
  };

  tinymce.init(editor_config);
</script>
@endpush