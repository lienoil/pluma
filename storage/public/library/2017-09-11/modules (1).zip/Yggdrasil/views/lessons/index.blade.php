@extends("Pluma::layouts.admin")

@section("title", "Course Lessons")

@section("content")

    @include("Pluma::partials.alert")

    <div class="container-fluid">
        <header class="header">
            <div class="header-item">
                <h3 class="page-title">All Lessons</h3>
            </div>
            <div class="header-item">
                <a href="{{ route('lessons.create') }}" class="btn pull-xs-right btn-primary">Create Lesson</a>
            </div>
        </header>
    </div>

    @include("Pluma::partials.trash", ['name'=>'lessons'])

    <div class="table-wrapper">
        <table class="table table-card">
            <thead>
                <tr>
                    <th><input type="checkbox"></th>
                    <th>Title</th>
                    <th><a href="{{ route('lessons.index') }}">Trainer</a></th>
                    <th>Created</th>
                    <th>Modified</th>
                </tr>
            </thead>
            <tbody>
                @if ( $resources->isEmpty() )
                    <tr>
                        <td colspan="5" class="text-muted text-xs-center">No resource found.</td>
                    </tr>
                @endif
                @foreach ( $resources as $i => $resource )
                    <tr>
                        <td><input type="checkbox"></td>
                        <td>
                            <strong>{!! $resource->edit_link('lessons', $resource->title) !!}</strong>
                            <div class="options-block btn-group">
                                <a class="btn btn-link btn-sm" href="{{ route('lessons.edit', $resource->id) }}"><i class="fa fa-edit">&nbsp;</i>Edit</a>
                                <a class="btn btn-link btn-sm" href="{{ route('lessons.show', $resource->id) }}"><i class="fa fa-eye">&nbsp;</i>Show</a>
                                <form class="form-inline" action="{{ route('lessons.destroy', $resource->id) }}" method="POST">
                                    {{ csrf_field() }}
                                    {{ method_field('DELETE') }}
                                    <button type="submit" class="btn btn-link btn-sm btn-confirm" data-swal='{"title":"Are you sure?","text":"{{ $resource->title }} lesson will be moved to Trash.","type":"warning","showCancelButton":"true","confirmButtonText":"Remove"}'><i class="fa fa-trash">&nbsp;</i>Trash</button>
                                </form>
                            </div>
                        </td>
                        <td>{{ $resource->created }}</td>
                        <td>{{ $resource->modified }}</td>
                    </tr>
                @endforeach
            </tbody>
            <tfoot class="thead">
                <tr>
                    <th><input type="checkbox"></th>
                    <th>Title</th>
                    <th><a href="{{ route('lessons.index') }}">Trainer</a></th>
                    <th>Created</th>
                    <th>Modified</th>
                </tr>
            </tfoot>
        </table>
    </div>

    <div class="container-fluid">
        <footer class="footer text-xs-right">
            @include("Pluma::partials.pagination", compact("resources"))
        </footer>
    </div>

@endsection