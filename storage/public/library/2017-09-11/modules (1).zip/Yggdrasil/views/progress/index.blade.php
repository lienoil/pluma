@extends("Pluma::layouts.admin")

@section('content')
<div class="container-fluid">
	<div class="row">
		<div class="col-md-4">
			<div class="card">
				<div class="card-image mh-250 waves-effect waves-block waves-light">
					<img class="progress-img" src="https://placeimg.com/640/480/any">
				</div>
				<div class="card-content">
					<span class="card-title">Course Title</span>
					<div class="progress">
					    	<div class="determinate bg-danger" style="width: 20%"></div>
						</div>
					<div class="text-right"><span class="text-danger"><strong>20%</strong></span></div>
					{{-- <p class="text-muted">80%</p> --}}
				</div>
				<div class="card-action text-center">
					<a href="#">Resume</a>

				</div>
			</div>
		</div>

		<div class="col-md-4">
			<div class="card">
				<div class="card-image mh-250 waves-effect waves-block waves-light">
					<img class="progress-img" src="https://placeimg.com/640/480/any">
				</div>
				<div class="card-content">
					<span class="card-title">Course Title</span>
					<div class="progress">
					    	<div class="determinate bg-success" style="width: 70%"></div>
						</div>
					<p class="text-muted text-right"><span class="text-success"><strong>70%</strong></span></p>
					{{-- <p class="text-muted">80%</p> --}}
				</div>
				<div class="card-action text-center">
					<a href="#">Resume</a>

				</div>
			</div>
		</div>

		<div class="col-md-4">
			<div class="card">
				<div class="card-image mh-250 waves-effect waves-block waves-light">
					<img class="progress-img" src="https://placeimg.com/640/480/any">
				</div>
				<div class="card-content">
					<span class="card-title">Course Title</span>
					<div class="progress">
					    	<div class="determinate bg-warning" style="width: 40%"></div>
						</div>
					<div class="text-right"><span class="text-warning"><strong>40%</strong></span></div>
					{{-- <p class="text-muted">80%</p> --}}
				</div>
				<div class="card-action text-center">
					<a href="#">Resume</a>

				</div>
			</div>
		</div>
	</div>
</div>
@endsection

@push('css')
	<style>
	.mh-250 {
		max-height: 250px !important;
	}

	.progress-img {
		min-width: 100% !important;
	}

	.bg-success {
		background: #009688 !important;
	}

	.text-success {
		color: #009688;
	}

	.bg-warning {
		background: #F58720 !important;
	}

	.text-warning {
		color: #F58720;
	}

	.bg-danger {
		background: #D8462A !important;
	}

	.text-danger {
		color: #D8462A;
	}
	</style>
@endpush