@extends('Pluma::layouts.static')
@section("content")

	<div class="fh5co-loader"></div>
	<div id="page">
		<nav class="fh5co-nav" role="navigation">
			<div class="top">
				<div class="container">
					<div class="row">
						<div class="col-xs-12 text-right">
							<p class="num">Call: + 65 6632 9536</p>
							<ul class="fh5co-social">
								<li><a href="https://twitter.com/training_ssa"><i class="icon-twitter"></i></a></li>
								<li><a href="https://www.facebook.com/ssatraining"><i class="icon-facebook"></i></a></li>
								<li><a href="http://www.linkedin.com/company/ssa-consulting-group"><i class="icon-linkedin"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
			<div class="top-menu">
				<div class="container">
					<div class="row">
						<div class="col-xs-3">
							<div id="fh5co-logo"><a href="../"><img width="170" src="{{ theme('assets/img/main.png')}}" alt=""></a></div>
						</div>
						<div class="col-xs-9 text-right menu-1">
							<ul>
								<li><a href="../">Home</a></li>
								<li><a href="about">About Us</a></li>
								<li><a href="solutions">Our Solutions</a></li>
								<li class="active has-dropdown">
									<a href="courses-x">Courses</a>
									<ul class="dropdown">
										<li><a href="csuite">C-Suite</a></li>
										<li><a href="emerging">Emerging C-Suite and Middle Management</a></li>
										<li><a href="wps">Workplace Skills</a></li>
									</ul>
								</li>
								<li><a href="contact">Contact</a></li>
								<li><a href="admin/login"><span>Login</span></a></li>
								<li class="btn-cta"><a href="admin/register"><span>Sign Up</span></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</nav>
		<header id="fh5co-header" class="fh5co-cover" role="banner" style="background-image:url({{ theme('assets/vendor/learn/images/bg2.jpg')}});"
		data-stellar-background-ratio="0.5">
		<div class="overlay"></div>
			<div class="container">
				<div class="row">
					<div class="col-md-8 col-md-offset-2 text-center">
						<div class="display-t">
							<div class="display-tc animate-box" data-animate-effect="fadeIn">
								<h1>Emerging C-Suite and Middle Management</h1>
								<h2>Courses developed for emerging executives to increase awareness on leadership finesse, critical public sector competencies, and productivity improvement opportunities.</h2>
								<section id="section05" class="demo"> <a href="#fh5co-resume"><span></span></a></section>
							</div>
						</div>
					</div>
				</div>
			</div>
		</header>

		<div id="fh5co-counter" class="fh5co-counters bg-dark light-ph">
			<div class="container">
				<div class="row form-group m-b-0">
					<div class="col-sm-6">
						<input type="text" id="subject" class="form-control m-b-05" placeholder="Email Address">
					</div>
					<div class="col-sm-4 custom-dropdown m-b-05">
						<select class="customSelect form-control col-sm-4" name="" id="">
							<option value="">Which area would you like us to assist you with?</option>
						</select>
					</div>
					<div class="col-sm-2"><a href="#" class="btn btn-primary btn-started">Let's start</a></div>
				</div>
			</div>
		</div>

		<div id="fh5co-resume" class="fh5co-bg-color">
			<div class="container">
				<div class="row animate-box">
					<div class="col-md-8 col-md-offset-2 text-center fh5co-heading">
						<h2>Emerging C-Suite and Middle Management</h2>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12 col-md-offset-0">
						<ul class="timeline">
							<li class="animate-box timeline-unverted">
								<div class="timeline-badge"><i class="icon-check"></i></div>
								<div class="timeline-panel">
									<div class="timeline-heading">
										<h3 class="timeline-title">Emerging Leadership (E-LEAD) Programme</h3>
									</div>
									<div class="timeline-body">
										<p>Increase self-awareness by understanding one’s leadership style and its impact on others, developing personal mastery, leading a team to a shared purpose, and managing change in a dynamic environment.</p>
									</div>
								</div>
							</li>
							<li class="timeline-inverted animate-box">
								<div class="timeline-badge"><i class="icon-check"></i></div>
								<div class="timeline-panel">
									<div class="timeline-heading">
										<h3 class="timeline-title">Intermediate Leadership Programme</h3>
									</div>
									<div class="timeline-body">
										<p>Apply processes and tools for tactical planning and achieving strategic innovation, identify the differences in thinking preferences and behavioural attributes, and apply techniques and leadership skills to better lead and work as a team.</p>
									</div>
								</div>
							</li>
							<li class="animate-box timeline-unverted">
								<div class="timeline-badge"><i class="icon-check"></i></div>
								<div class="timeline-panel">
									<div class="timeline-heading">
										<h3 class="timeline-title">Basic Leadership Programme</h3>
									</div>
									<div class="timeline-body">
										<p>Demonstrate team leadership through planning and allocating resources within the team, set clear team goals to focus team efforts, and create a flexible and supportive work environment to enhance performance management.</p>
									</div>
								</div>
							</li>
							<li class="timeline-inverted animate-box">
								<div class="timeline-badge"><i class="icon-check"></i></div>
								<div class="timeline-panel">
									<div class="timeline-heading">
										<h3 class="timeline-title">Strategic Planning Retreat</h3>
									</div>
									<div class="timeline-body">
										<p>Develop organisational and departmental work plans and chart initial roles and strategies to be more sustainable.</p>
									</div>
								</div>
							</li>
							<li class="animate-box timeline-unverted">
								<div class="timeline-badge"><i class="icon-check"></i></div>
								<div class="timeline-panel">
									<div class="timeline-heading">
										<h3 class="timeline-title">Relationship Managers Programme</h3>
									</div>
									<div class="timeline-body">
										<p>Address obligations to customers and identify key relationship building skills and attributes required from a competent relationship manager.</p>
									</div>
								</div>
							</li>
							<li class="timeline-inverted animate-box">
								<div class="timeline-badge"><i class="icon-check"></i></div>
								<div class="timeline-panel">
									<div class="timeline-heading">
										<h3 class="timeline-title">Certified Productivity Practitioners (CPP) Course</h3>
									</div>
									<div class="timeline-body">
										<p>Develop good knowledge of productivity concepts, principles, and tools, adopt an integrated productivity framework to diagnose productivity problems and develop solutions, and provide training, consulting, and promotional services to organisations.</p>
									</div>
								</div>
							</li>
							<li class="animate-box timeline-unverted">
								<div class="timeline-badge"><i class="icon-check"></i></div>
								<div class="timeline-panel">
									<div class="timeline-heading">
										<h3 class="timeline-title">Job Redesign Productivity Clinic</h3>
									</div>
									<div class="timeline-body">
										<p>Appreciate productivity improvement opportunities associated with the concepts of job redesign, differentiate between value and non-value adding activities, and understand different government assistance schemes.</p>
									</div>
								</div>
							</li>
							<li class="timeline-inverted animate-box">
								<div class="timeline-badge"><i class="icon-check"></i></div>
								<div class="timeline-panel">
									<div class="timeline-heading">
										<h3 class="timeline-title">Mentorship/Mentoring Workshop</h3>
									</div>
									<div class="timeline-body">
										<p>Familiarise with mentors’ and mentees’ roles and responsibilities, set learning goals and priorities, and utilise tools, guidelines, and frameworks developed to facilitate the mentorship process.</p>
									</div>
								</div>
							</li>
							<li class="animate-box timeline-unverted">
								<div class="timeline-badge"><i class="icon-check"></i></div>
								<div class="timeline-panel">
									<div class="timeline-heading">
										<h3 class="timeline-title">Environmental, Occupational Safety and Health (EHS) Inspection Training</h3>
									</div>
									<div class="timeline-body">
										<p>Plan and conduct EHS inspections to determine conformity with acceptable EHS conditions and behaviours, compile reports on non-conformity and ESH performance, and recommend and monitor corrective and preventive actions.</p>
									</div>
								</div>
							</li>
				    	</ul>
					</div>
				</div>
			</div>
		</div>

		<div id="fh5co-started" style="background-image:url({{ theme('assets/vendor/learn/images/bg.jpg')}});">
			<div class="overlay"></div>
			<div class="container">
				<div class="row animate-box">
					<div class="col-md-8 col-md-offset-2 text-center fh5co-heading">
						<h2>Let's Get Started</h2>
						<p>SSA Academy provides customised programmes and solutions to address your specific needs. Send us your inquiries and we'll get back to you shortly.</p>
					</div>
				</div>
				<div class="row animate-box text-center">
					<p><a href="admin/register" class="btn btn-primary">Sign up now!</a></p>
				</div>
			</div>
		</div>

		<footer id="fh5co-footer" role="contentinfo">
			<div class="container">
				<div class="row copyright">
					<div class="col-md-12 text-center m-t-3">
						<p>
							<small class="block">&copy; 2017 SSA Consulting Group Pte. Ltd. All rights reserved.</small>
						</p>
						<p>
							<ul class="fh5co-social-icons">
								<li><a href="https://twitter.com/training_ssa"><i class="icon-twitter"></i></a></li>
								<li><a href="https://www.facebook.com/ssatraining"><i class="icon-facebook"></i></a></li>
								<li><a href="http://www.linkedin.com/company/ssa-consulting-group"><i class="icon-linkedin"></i></a></li>
							</ul>
						</p>
					</div>
				</div>
			</div>
		</footer>
	</div>

	<div class="gototop js-top">
		<a href="#" class="js-gotop"><i class="icon-arrow-up"></i></a>
	</div>
@stop

@push('css')
	<link rel="stylesheet" href="{{ theme('assets/vendor/law/css/flexslider.css')}}">
	<link rel="stylesheet" href="{{ theme('assets/vendor/law/css/style.css')}}">

	<link rel="stylesheet" href="{{ theme('assets/vendor/profile/css/style.css')}}">
@endpush

@push('js')
	<script>
		$(function() {
			$('a[href*=#]').on('click', function(e) {
				e.preventDefault();
				$('html, body').animate({ scrollTop: $($(this).attr('href')).offset().top}, 500, 'linear');
			});
		});
	</script>
	<script src="{{ theme('assets/vendor/law/js/main.js')}}"></script>
	<script src="{{ theme('assets/vendor/profile/js/jquery.easypiechart.min.js')}}"></script>
@endpush
