@extends('Pluma::layouts.static')
@section("content")


	<div class="fh5co-loader"></div>
	<div id="page">
		<nav class="fh5co-nav" role="navigation">
			<div class="top">
				<div class="container">
					<div class="row">
						<div class="col-xs-12 text-right">
							<p class="num">Call: + 65 6632 9536</p>
							<ul class="fh5co-social">
								<li><a href="https://twitter.com/training_ssa"><i class="icon-twitter"></i></a></li>
								<li><a href="https://www.facebook.com/ssatraining"><i class="icon-facebook"></i></a></li>
								<li><a href="http://www.linkedin.com/company/ssa-consulting-group"><i class="icon-linkedin"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
			<div class="top-menu">
				<div class="container">
					<div class="row">
						<div class="col-xs-3">
							<div id="fh5co-logo"><a href="../"><img width="170" src="{{ asset('default/assets/img/main.png')}}" alt=""></a></div>
						</div>
						<div class="col-xs-9 text-right menu-1">
							<ul>
								<li><a href="../">Home</a></li>
								<li><a href="about">About Us</a></li>
								<li><a href="solutions">Our Solutions</a></li>
								<li class="active has-dropdown">
									<a href="courses-x">Courses</a>
									<ul class="dropdown">
										<li><a href="csuite">C-Suite</a></li>
										<li><a href="emerging">Emerging C-Suite and Middle Management</a></li>
										<li><a href="wps">Workplace Skills</a></li>
									</ul>
								</li>
								<li><a href="contact">Contact</a></li>
								<li><a href="admin/login"><span>Login</span></a></li>
								<li class="btn-cta"><a href="admin/register"><span>Sign Up</span></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</nav>
		<header id="fh5co-header" class="fh5co-cover" role="banner" style="background-image:url({{ asset('default/assets/vendor/learn/images/bg.jpg') }});"
		data-stellar-background-ratio="0.5">
		<div class="overlay"></div>
			<div class="container">
				<div class="row">
					<div class="col-md-8 col-md-offset-2 text-center">
						<div class="display-t">
							<div class="display-tc animate-box" data-animate-effect="fadeIn">
								<h1>Workplace Skills</h1>
								<h2>Courses constructed to equip workers with the necessary workplace skills to optimise productivity and effectiveness at the supervisory or operations level.</h2>
								<section id="section05" class="demo"> <a href="#fh5co-resume"><span></span></a></section>
							</div>
						</div>
					</div>
				</div>
			</div>
		</header>

		<div id="fh5co-counter" class="fh5co-counters bg-dark light-ph">
			<div class="container">
				<div class="row form-group m-b-0">
					<div class="col-sm-6">
						<input type="text" id="subject" class="form-control m-b-05" placeholder="Email Address">
					</div>
					<div class="col-sm-4 custom-dropdown m-b-05">
						<select class="customSelect form-control col-sm-4" name="" id="">
							<option value="">Which area would you like us to assist you with?</option>
						</select>
					</div>
					<div class="col-sm-2"><a href="#" class="btn btn-primary btn-started">Let's start</a></div>
				</div>
			</div>
		</div>

		<div id="fh5co-resume" class="fh5co-bg-color">
			<div class="container">
				<div class="row animate-box">
					<div class="col-md-8 col-md-offset-2 text-center fh5co-heading">
						<h2>Workplace Skills</h2>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12 col-md-offset-0">
						<ul class="timeline">
							<li class="timeline-heading text-center animate-box">
								<div><h3>Operational</h3></div>
							</li>
							<li class="animate-box timeline-unverted">
								<div class="timeline-badge"><i class="icon-check"></i></div>
								<div class="timeline-panel">
									<div class="timeline-heading">
										<h3 class="timeline-title">Develop Personal Effectiveness</h3>
									</div>
									<div class="timeline-body">
										<p>Apply knowledge and skills such as establishing personal goals and relating them to workplace goals, managing time effectively, maintaining work-life balance, and managing stress, as well as personal finances so as to optimise effectiveness at work.</p>
									</div>
								</div>
							</li>
							<li class="timeline-inverted animate-box">
								<div class="timeline-badge"><i class="icon-check"></i></div>
								<div class="timeline-panel">
									<div class="timeline-heading">
										<h3 class="timeline-title">Maintain Personal Presentation and Employability</h3>
									</div>
									<div class="timeline-body">
										<p>Identify personal career goals after determining individual competencies and take steps to realise career goals by sourcing for job opportunities, preparing for interviews and internalising basic social etiquette that will boost employability.</p>
									</div>
								</div>
							</li>
							<li class="animate-box timeline-unverted">
								<div class="timeline-badge"><i class="icon-check"></i></div>
								<div class="timeline-panel">
									<div class="timeline-heading">
										<h3 class="timeline-title">Solve Problems and Make Decisions</h3>
									</div>
									<div class="timeline-body">
										<p>Acquire the techniques in problem solving and decision making, including proactively identifying root causes to a problem, generating and evaluating alternative solutions, making appropriate decisions and taking responsibility for the decisions within own circle of influence.</p>
									</div>
								</div>
							</li>
							<li class="timeline-inverted animate-box">
								<div class="timeline-badge"><i class="icon-check"></i></div>
								<div class="timeline-panel">
									<div class="timeline-heading">
										<h3 class="timeline-title">Communicate and Relate Effectively at the Workplace</h3>
									</div>
									<div class="timeline-body">
										<p>Use effective communication techniques to interpret, clarify, analyse, and respond to information received; and use effective negotiation skills to resolve conflicts for win-win outcomes, taking into consideration social and cultural differences.</p>
									</div>
								</div>
							</li>
							<li class="animate-box timeline-unverted">
								<div class="timeline-badge"><i class="icon-check"></i></div>
								<div class="timeline-panel">
									<div class="timeline-heading">
										<h3 class="timeline-title">Work in a Team</h3>
									</div>
									<div class="timeline-body">
										<p>Apply effective communication techniques to maintain open communication, resolve issues and concerns, and provide support to team members to achieve individual and team goals.</p>
									</div>
								</div>
							</li>
							<br>
							<li class="timeline-heading text-center animate-box">
								<div><h3>Supervisory</h3></div>
							</li>
							<li class="timeline-inverted animate-box">
								<div class="timeline-badge"><i class="icon-check"></i></div>
								<div class="timeline-panel">
									<div class="timeline-heading">
										<h3 class="timeline-title">Develop Personal Effectiveness</h3>
									</div>
									<div class="timeline-body">
										<p>Apply knowledge and life skills such as establishing personal goals and evaluating them to justify roles and responsibilities in achieving organisational goals. Manage time effectively, maintain organisational work-life balance, and manage stress and personal finances to be an effective manager at the workplace.</p>
									</div>
								</div>
							</li>
				    	</ul>
					</div>
				</div>
			</div>
		</div>



		<div id="fh5co-started" style="background-image:url({{ asset('default/assets/vendor/learn/images/bg.jpg') }});">
			<div class="overlay"></div>
			<div class="container">
				<div class="row animate-box">
					<div class="col-md-8 col-md-offset-2 text-center fh5co-heading">
						<h2>Let's Get Started</h2>
						<p>SSA Academy provides customised programmes and solutions to address your specific needs. Send us your inquiries and we'll get back to you shortly.</p>
					</div>
				</div>
				<div class="row animate-box text-center">
					<p><a href="admin/register" class="btn btn-primary">Sign up now!</a></p>
				</div>
			</div>
		</div>

		<footer id="fh5co-footer" role="contentinfo">
			<div class="container">
				<div class="row copyright">
					<div class="col-md-12 text-center m-t-3">
						<p>
							<small class="block">&copy; 2017 SSA Consulting Group Pte. Ltd. All rights reserved.</small>
						</p>
						<p>
							<ul class="fh5co-social-icons">
								<li><a href="https://twitter.com/training_ssa"><i class="icon-twitter"></i></a></li>
								<li><a href="https://www.facebook.com/ssatraining"><i class="icon-facebook"></i></a></li>
								<li><a href="http://www.linkedin.com/company/ssa-consulting-group"><i class="icon-linkedin"></i></a></li>
							</ul>
						</p>
					</div>
				</div>

			</div>
		</footer>
	</div>

	<div class="gototop js-top">
		<a href="#" class="js-gotop"><i class="icon-arrow-up"></i></a>
	</div>
@stop

@push('css')
	<link rel="stylesheet" href="{{ asset('default/assets/vendor/law/css/flexslider.css') }}">
	<link rel="stylesheet" href="{{ asset('default/assets/vendor/law/css/style.css') }}">

	<link rel="stylesheet" href="{{ asset('default/assets/vendor/profile/css/style.css') }}">
@endpush

@push('js')
	<script>
		$(function() {
			$('a[href*=#]').on('click', function(e) {
				e.preventDefault();
				$('html, body').animate({ scrollTop: $($(this).attr('href')).offset().top}, 500, 'linear');
			});
		});
	</script>
	<script src="{{ asset('default/assets/vendor/law/js/main.js') }}"></script>
	<script src="{{ asset('default/assets/vendor/profile/js/jquery.easypiechart.min.js') }}"></script>
@endpush