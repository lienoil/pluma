@extends('Pluma::layouts.static')
@section("content")

	<div class="fh5co-loader"></div>
	<div id="page">
		<nav class="fh5co-nav" role="navigation">
			<div class="top">
				<div class="container">
					<div class="row">
						<div class="col-xs-12 text-right">
							<p class="num">Call: + 65 6632 9536</p>
							<ul class="fh5co-social">
								<li><a href="https://twitter.com/training_ssa"><i class="icon-twitter"></i></a></li>
								<li><a href="https://www.facebook.com/ssatraining"><i class="icon-facebook"></i></a></li>
								<li><a href="http://www.linkedin.com/company/ssa-consulting-group"><i class="icon-linkedin"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
			<div class="top-menu">
				<div class="container">
					<div class="row">
						<div class="col-xs-3">
							<div id="fh5co-logo"><a href="../"><img width="170" src="{{ theme('assets/img/main.png') }}" alt=""></a></div>
						</div>
						<div class="col-xs-9 text-right menu-1">
							<ul>
								<li><a href="../">Home</a></li>
								<li><a href="about">About Us</a></li>
								<li class="active"><a href="solutions">Our Solutions</a></li>
								<li class="has-dropdown">
									<a href="courses-x">Courses</a>
									<ul class="dropdown">
										<li><a href="csuite">C-Suite</a></li>
										<li><a href="emerging">Emerging C-Suite and Middle Management</a></li>
										<li><a href="wps">Workplace Skills</a></li>
									</ul>
								</li>
								<li><a href="contact">Contact</a></li>
								<li><a href="admin/login"><span>Login</span></a></li>
								<li class="btn-cta"><a href="#"><span>Sign Up</span></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</nav>
		<header id="fh5co-header" class="fh5co-cover" role="banner" style="background-image:url({{ theme('assets/vendor/learn/images/bg2.jpg')}}
		);"
		data-stellar-background-ratio="0.5">
		<div class="overlay"></div>
			<div class="container">
				<div class="row">
					<div class="col-md-8 col-md-offset-2 text-center">
						<div class="display-t">
							<div class="display-tc animate-box" data-animate-effect="fadeIn">
								<h1>Our Solutions</h1>
								<h2>Learn at your own pace through our innovative pedagogy and technology solutions.</h2>
								<section id="section05" class="demo"> <a href="#fh5co-project"><span></span></a></section>
							</div>
						</div>
					</div>
				</div>
			</div>
		</header>

		<div id="fh5co-counter" class="fh5co-counters bg-dark light-ph">
			<div class="container">
				<div class="row form-group m-b-0">
					<div class="col-sm-6">
						<input type="text" id="subject" class="form-control m-b-05" placeholder="Email Address">
					</div>
					<div class="col-sm-4 custom-dropdown m-b-05">
						<select class="customSelect form-control col-sm-4" name="" id="">
							<option value="">Which area would you like us to assist you with?</option>
						</select>
					</div>
					<div class="col-sm-2"><a href="admin/register" class="btn btn-primary btn-started">Let's start</a></div>
				</div>
			</div>
		</div>

		<div id="fh5co-project">
			<div class="container">
				<div class="row animate-box">
					<div class="col-md-6 col-md-offset-3 text-center fh5co-heading">
						<h2 class="text-dark-primary">PEbAAL Pedagogy</h2>
					</div>
				</div>
			</div>
			<div class="container">
				<div class="row">
					<div class="col-md-6 m-b-2 animate-box">
						<div class="mt m-t-0">
							<div>
								<h4><i class="icon-suitcase"></i>Delivering tangible skills with real business outcomes</h4>
								<p>Depending on the readiness of the institutions or organizations supporting the professional development of course participants, our learning programs can be implemented by using the <strong class="text-dark-primary">PEbAAL</strong> methodology.  This methodology seeks to enhance performance at the workplace</p>
							</div>
							<div>
								<h4><i class="icon-laptop"></i>PEbAAL is an instructional design process at the workplace</h4>
								<p>It is targeted to fix a performance problem or gap when workers lack the essential skills and knowledge for a specific job responsibility, competency, or task. The <strong class="text-dark-primary">PEbAAL</strong> process combines experience in two key areas, performance improvement and instructional design.</p>
							</div>
							<div>
								<h4><i class="icon-light-bulb"></i>The ultimate aim of our program is to boost the overall performance of the organization.  </h4>
								<p>Under the <strong class="text-dark-primary">PEbAAL</strong> approach, participants will initially undergo a pre-test to evaluate their existing knowledge and skills.  During the course (both face to face or e-Learning or hybrid), each learner will be evaluated individually and post course follow up can be developed to suit the needs of learners with different capacities and levels of readiness to move to the next level.</p>
							</div>
						</div>
					</div>
					<div class="col-md-5 col-md-offset-1 text-center animate-box">
						<div class="mt">
							<img class="img-responsive" src="{{ theme('assets/vendor/learn/images/img_devices.png') }}" alt="">
						</div>
					</div>
				</div>
			</div>
		</div>

		<section id="FEATURES" class="features page m-b-0">
	        <div class="container">
	            <div class="row animate-box">
					<div class="col-md-6 col-md-offset-3 text-center fh5co-heading">
						<h2 class="text-dark-primary">Rippl3s</h2>
					</div>
				</div>
	        </div>

	        <div class="feature_inner">
	            <div class="container">
	                <div class="row">
	                    <div class="col-md-4 right_no_padding wow fadeInLeft" data-wow-duration="1s">

	                        <div class="left_single_feature">
	                            <div><span class="pe-7s-study"></span></div>

	                            <h4>An engaging learning experience right at your fingertips</h4>
	                            <p>Using innovative technology suited to the needs of our customers, we provide a dynamic, learner-centric platform with a range of assets for collaborative and social learning. Through our focused responsive portal where technology and curriculum work seamlessly together, we deliver convenience in accessing courses on different devices.</p>
	                        </div>
	                        <div class="left_single_feature">
	                            <div><span class="pe-7s-notebook"></span></div>

	                            <h4>Organised course content and analytics tools</h4>
	                            <p>Easily keep track of your progress and milestones with just a click of a button</p>
	                        </div>

	                    </div>
	                    <div class="col-md-4">
	                        <div class="feature_iphone">
	                            <img class="wow bounceIn img-responsive" data-wow-duration="1s" src="{{ theme('assets/vendor/learn/images/img_devices.png') }}" alt="">
	                        </div>
	                    </div>
	                    <div class="col-md-4 left_no_padding wow fadeInRight" data-wow-duration="1s">
	                        <div class="right_single_feature">
	                            <div><span class="pe-7s-paperclip"></span></div>

	                            <h4>Collaborative and social learning</h4>
	                            <p>Share videos and links, and even chat with classmates and trainers</p>
	                        </div>

	                        <div class="right_single_feature">
	                            <div><span class="pe-7s-monitor"></span></div>

	                            <h4>Learner-centric platform</h4>
	                            <p>Assess understanding with interactive online exams, quizzes, and simulations</p>
	                        </div>


	                        <div class="right_single_feature">
	                            <div><span class="pe-7s-phone"></span></div>

	                            <h4>Portable and convenient</h4>
	                            <p>Learn at your own pace on any electronic device of your choice</p>
	                        </div>
	                    </div>
	                </div>
	            </div>
	        </div>
	    </section>

		{{-- <div id="fh5co-explore" class="fh5co-bg-section">
			<div class="container">
				<div class="row animate-box">
					<div class="col-md-6 col-md-offset-3 text-center fh5co-heading">
						<h2 class="text-dark-primary">Solutions</h2>
					</div>
				</div>
			</div>
			<div class="fh5co-explore fh5co-explore1">
				<div class="container">
					<div class="row">
						<div class="col-md-5 col-md-offset-1 animate-box">
							<img class="img-responsive border-dark" src="http://placehold.it/350x150" alt="work">
						</div>
						<div class="col-md-6 animate-box">
							<div class="mt">
								<h3>Title</h3>
								<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsam voluptatem iusto, dolor quo quasi qui architecto aut id adipisci, nulla tempore officia recusandae sint sequi, explicabo est ipsum. Delectus, quia?</p>
							</div>
						</div>
					</div>
				</div>
			</div>

			<div class="fh5co-explore">
				<div class="container">
					<div class="row">
						<div class="col-md-6 animate-box">
							<div class="mt">
								<h3>Title</h3>
								<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Assumenda officia architecto eveniet ratione voluptates perspiciatis atque necessitatibus accusantium totam cumque, cupiditate aperiam dignissimos! Fugiat illum, vitae, consequuntur expedita architecto praesentium.</p>
							</div>
						</div>
						<div class="col-md-5 col-md-offset-1 animate-box">
							<img class="img-responsive border-dark" src="http://placehold.it/350x150" alt="work">
						</div>
					</div>
				</div>
			</div>
		</div> --}}

		<div id="fh5co-started" style="background-image:url({{ theme('assets/vendor/learn/images/bg.jpg') }});">
			<div class="overlay"></div>
			<div class="container">
				<div class="row animate-box">
					<div class="col-md-8 col-md-offset-2 text-center fh5co-heading">
						<h2>Let's Get Started</h2>
						<p>SSA Academy provides customised programmes and solutions to address your specific needs. Send us your inquiries and we'll get back to you shortly.</p>
					</div>
				</div>
				<div class="row animate-box text-center">
					<p><a href="#" class="btn btn-primary">Sign up now!</a></p>
				</div>
			</div>
		</div>

		<footer id="fh5co-footer" role="contentinfo">
			<div class="container">
				<div class="row copyright">
					<div class="col-md-12 text-center m-t-3">
						<p>
							<small class="block">&copy; 2017 SSA Consulting Group Pte. Ltd. All rights reserved.</small>
						</p>
						<p>
							<ul class="fh5co-social-icons">
								<li><a href="https://twitter.com/training_ssa"><i class="icon-twitter"></i></a></li>
								<li><a href="https://www.facebook.com/ssatraining"><i class="icon-facebook"></i></a></li>
								<li><a href="http://www.linkedin.com/company/ssa-consulting-group"><i class="icon-linkedin"></i></a></li>
							</ul>
						</p>
					</div>
				</div>

			</div>
		</footer>
	</div>

	<div class="gototop js-top">
		<a href="#" class="js-gotop"><i class="icon-arrow-up"></i></a>
	</div>
@stop

@push('css')
	<link rel="stylesheet" href="{{ theme('assets/vendor/bent/css/style.css') }}">
	<link rel="stylesheet" href="{{ theme('assets/vendor/bent/css/responsive.css') }}">
	<link rel="stylesheet" href="{{ theme('assets/vendor/bent/css/Pe-icon-7-stroke.css') }}">

	<style>
		#section05 a span {
			width: 15px !important;
			height: 15px !important;
			border-left: 3px solid #fff !important;
			border-bottom: 3px solid #fff !important;
		}
	</style>
@endpush

@push('js')
	<script>
		$(function() {
			$('a[href*=#]').on('click', function(e) {
				e.preventDefault();
				$('html, body').animate({ scrollTop: $($(this).attr('href')).offset().top}, 500, 'linear');
			});
		});
	</script>

	{{-- <script src="{{ asset('default/assets/vendor/bent/js/wow.min.js') }}"></script> --}}
	<script src="{{ theme('assets/vendor/bent/js/wow.min.js') }}"></script>
	<script src="{{ theme('assets/vendor/bent/js/script.js') }}"></script>
@endpush
