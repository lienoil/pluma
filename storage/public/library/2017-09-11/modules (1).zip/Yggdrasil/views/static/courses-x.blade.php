@extends('Pluma::layouts.static')
@section("content")

	<div class="fh5co-loader"></div>
	<div id="page">
		<nav class="fh5co-nav" role="navigation">
			<div class="top">
				<div class="container">
					<div class="row">
						<div class="col-xs-12 text-right">
							<p class="num">Call: + 65 6632 9536</p>
							<ul class="fh5co-social">
								<li><a href="https://twitter.com/training_ssa"><i class="icon-twitter"></i></a></li>
								<li><a href="https://www.facebook.com/ssatraining"><i class="icon-facebook"></i></a></li>
								<li><a href="http://www.linkedin.com/company/ssa-consulting-group"><i class="icon-linkedin"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
			<div class="top-menu">
				<div class="container">
					<div class="row">
						<div class="col-xs-3">
							<div id="fh5co-logo"><a href="../"><img width="170" src="{{ theme('assets/img/main.png') }}" alt=""></a></div>
						</div>
						<div class="col-xs-9 text-right menu-1">
							<ul>
								<li><a href="../">Home</a></li>
								<li><a href="about">About Us</a></li>
								<li><a href="solutions">Our Solutions</a></li>
								<li class="active has-dropdown">
									<a href="courses-x">Courses</a>
									<ul class="dropdown">
										<li><a href="csuite">C-Suite</a></li>
										<li><a href="emerging">Emerging C-Suite and Middle Management</a></li>
										<li><a href="wps">Workplace Skills</a></li>
									</ul>
								</li>
								<li><a href="contact">Contact</a></li>
								<li><a href="admin/login"><span>Login</span></a></li>
								<li class="btn-cta"><a href="admin/register"><span>Sign Up</span></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</nav>
		<header id="fh5co-header" class="fh5co-cover" role="banner" style="background-image:url({{ theme('assets/vendor/learn/images/bg.jpg') }});"
		data-stellar-background-ratio="0.5">
		<div class="overlay"></div>
			<div class="container">
				<div class="row">
					<div class="col-md-8 col-md-offset-2 text-center">
						<div class="display-t">
							<div class="display-tc animate-box" data-animate-effect="fadeIn">
								<h1>Our Courses</h1>
								<h2>All our courses are designed by SSA Academy’s league of well-renowned trainers and subject matter experts (SMEs).</h2>
								<section id="section05" class="demo"> <a href="#fh5co-blog"><span></span></a></section>
							</div>
						</div>
					</div>
				</div>
			</div>
		</header>

		<div id="fh5co-counter" class="fh5co-counters bg-dark light-ph">
			<div class="container">
				<div class="row form-group m-b-0">
					<div class="col-sm-6">
						<input type="text" id="subject" class="form-control m-b-05" placeholder="Email Address">
					</div>
					<div class="col-sm-4 custom-dropdown m-b-05">
						<select class="customSelect form-control col-sm-4" name="" id="">
							<option value="">Which area would you like us to assist you with?</option>
						</select>
					</div>
					<div class="col-sm-2"><a href="#" class="btn btn-primary btn-started">Let's start</a></div>
				</div>
			</div>
		</div>

		<div id="fh5co-blog">
			<div class="container relative m-b-7em">
				<div class="row animate-box">
					<div class="col-md-8 col-md-offset-2 text-center fh5co-heading">
						<h2 class="text-dark-primary">Our Courses</h2>
						{{-- <p>All our courses are designed by SSA Academy’s league of well-renowned trainers and subject matter experts (SMEs).</p> --}}
					</div>
				</div>
				<div class="row">
					<div class="col-lg-4 col-md-4">
						<div class="fh5co-blog animate-box">
							<a href="#"><img class="img-responsive" src="{{ theme('assets/vendor/learn/images/bg.jpg') }}" alt=""></a>
							<div class="blog-text">
								<div class="blog-body">
									<h3><a href="#">C-Suite</a></h3>
								<!-- {{-- <span class="posted_on">Nov. 15th</span> --}} -->
								<!-- {{-- <span class="comment"><a href="">21<i class="icon-speech-bubble"></i></a></span> --}} -->
								<p>Courses with a deep focus on building capabilities to drive higher corporate performance and to enable executives to be more nimble and agile in the future economy.</p>
								</div>
								<div class="blog-footer text-center">
								<a href="csuite" class="btn btn-primary">Read More</a>
								</div>
							</div>

						</div>
					</div>
					<div class="col-lg-4 col-md-4">
						<div class="fh5co-blog animate-box">
							<a href="#"><img class="img-responsive" src="{{ theme('assets/vendor/learn/images/bg.jpg') }}" alt=""></a>
							<div class="blog-text">
								<div class="blog-body">
									<h3><a href="#">Emerging C-Suite and Middle Management</a></h3>
									<!-- {{-- <span class="posted_on">Nov. 15th</span> --}} -->
									<!-- {{-- <span class="comment"><a href="">21<i class="icon-speech-bubble"></i></a></span> --}} -->
									<p>Courses developed for emerging executives to increase awareness on leadership finesse, critical public sector competencies, and productivity improvement opportunities.</p>
								</div>
								<div class="blog-footer text-center">
									<a href="emerging" class="btn btn-primary">Read More</a>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-4 col-md-4">
						<div class="fh5co-blog animate-box">
							<a href="#"><img class="img-responsive" src="{{ theme('assets/vendor/learn/images/bg.jpg') }}" alt=""></a>
							<div class="blog-text">
								<div class="blog-body">
									<h3><a href="#">Workplace Skills</a></h3>
									<!-- {{-- <span class="posted_on">Nov. 15th</span> --}} -->
									<!-- {{-- <span class="comment"><a href="">21<i class="icon-speech-bubble"></i></a></span> --}} -->
									<p>Courses constructed to equip workers with the necessary workplace skills to optimise productivity and effectiveness at the supervisory or operations level.</p>
								</div>
								<div class="blog-footer text-center">
									<a href="wps" class="btn btn-primary">Read More</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

		<div id="fh5co-started" style="background-image:url({{ theme('assets/vendor/learn/images/bg.jpg') }});">
			<div class="overlay"></div>
			<div class="container">
				<div class="row animate-box">
					<div class="col-md-8 col-md-offset-2 text-center fh5co-heading">
						<h2>Let's Get Started</h2>
						<p>SSA Academy provides customised programmes and solutions to address your specific needs. Send us your inquiries and we'll get back to you shortly.</p>
					</div>
				</div>
				<div class="row animate-box text-center">
					<p><a href="admin/register" class="btn btn-primary">Sign up now!</a></p>
				</div>
			</div>
		</div>

		<footer id="fh5co-footer" role="contentinfo">
			<div class="container">
				<div class="row copyright">
					<div class="col-md-12 text-center m-t-3">
						<p>
							<small class="block">&copy; 2017 SSA Consulting Group Pte. Ltd. All rights reserved.</small>
						</p>
						<p>
							<ul class="fh5co-social-icons">
								<li><a href="https://twitter.com/training_ssa"><i class="icon-twitter"></i></a></li>
								<li><a href="https://www.facebook.com/ssatraining"><i class="icon-facebook"></i></a></li>
								<li><a href="http://www.linkedin.com/company/ssa-consulting-group"><i class="icon-linkedin"></i></a></li>
							</ul>
						</p>
					</div>
				</div>

			</div>
		</footer>
	</div>

	<div class="gototop js-top">
		<a href="#" class="js-gotop"><i class="icon-arrow-up"></i></a>
	</div>
@stop

@push('css')
	<style>
		#section05 a span {
			width: 15px !important;
			height: 15px !important;
			border-left: 3px solid #fff !important;
			border-bottom: 3px solid #fff !important;
		}
	</style>
@endpush

@push('js')
	<script>
		$(function() {
			$('a[href*=#]').on('click', function(e) {
				e.preventDefault();
				$('html, body').animate({ scrollTop: $($(this).attr('href')).offset().top}, 500, 'linear');
			});
		});
	</script>
@endpush
