@extends('Pluma::layouts.admin')

@section("content")
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-9">
                @include("Yggdrasil::widgets.courses.current", ['resource' => $widgets['courses']['current']->first()])

                <div class="row">
                    <div class="col-md-9">
                        @include("Pluma::widgets.notepad")
                    </div>
                </div>

            </div>
            <div class="col-md-3">
                @allow('show-announcement')
                @include("Announcement::widgets.announcements")
                @endallow

                @include("Pluma::activities.widgets.activities")
            </div>
        </div>
    </div>
@endsection