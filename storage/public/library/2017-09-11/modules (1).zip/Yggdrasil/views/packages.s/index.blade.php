@extends("Pluma::layouts.admin")

@section('content')
    @include("Pluma::partials.alert")
    {{-- @include("Pluma::partials.trash", ['name' => 'packages']) --}}

    <div class="container-fluid">
        <div class="box no-border">
            <div class="box-header with-border">
                <h3 class="box-title">All Packages</h3>
            </div>
            <div class="box-body">
                <a href="{{ route('packages.upload') }}" class="btn waves-effect waves-light btn-yellow m-b-2">Upload Page</a>
                <div class="pull-right m-t-1">
                    @include("Pluma::partials.trash", ['name' => 'packages'])
                </div>
                <div class="clear"></div>


                @if ( $resources->isEmpty() )
                    <h1 class="m-t-3 text-muted text-xs-center"><i class="fa fa-archive">&nbsp;</i>No package to show</h1>
                @endif

                @foreach ( $resources->chunk(4) as $chunk )
                    <div class="row">
                        @foreach ( $chunk as $resource )
                            <div class="col-md-3">
                                <div class="box no-border">
                                    <div class="box-header with-border">
                                        <p class="m-0 p-0"><a class="text-dark" href="{{ route('packages.edit', $resource->id) }}">{{ $resource->displayname }}</a></p>
                                    </div>
                                    <div class="box-body">
                                        <a class="package-card" href="{{ route('packages.edit', $resource->id) }}"><img max-width="200" src="{{ $resource->thumbnail }}" alt="{{ $resource->displayname }}" class="img-card-top responsive-img"></a>

                                        @if ( $resource->warning )
                                            <p class="text-danger"><i class="fa fa-wraning">&nbsp;</i>{{ $resource->warning }}</p>
                                        @endif

                                        <p class="m-t-1">{{ $resource->description }}</p>

                                       <a class="text-info" href="{{ route('packages.edit', $resource->id) }}">Edit</a>

                                       <div class="pull-right">
                                          <form class="form-inline" action="{{ route('pages.destroy', $resource->id) }}" method="POST">
                                            {{ csrf_field() }}
                                            {{ method_field('DELETE') }}
                                            <button class="no-bg no-border text-red" type="submit" data-swal='{"title":"Are you sure?","text":"{{ $resource->title }} page will be moved to Trash.","type":"warning","showCancelButton":"true","confirmButtonText":"Remove"}'>Delete</button>
                                        </form>
                                       </div>
                                    </div>
                                    <div class="card-footer">
                                        <style scoped>
                                            small {
                                                display: block;
                                            }
                                        </style>
                                        <small class="metadata-item text-muted"><i class="fa fa-external-link">&nbsp;</i>{{ $resource->url }}</small>
                                        <small class="metadata-item text-muted"><i class="fa fa-calendar">&nbsp;</i>Created {{ $resource->created }}</small>
                                        <small class="metadata-item text-muted"><i class="fa fa-calendar">&nbsp;</i>Modified {{ $resource->modified or 'not modified' }}</small>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    </div>
                @endforeach
            </div>
            <div class="card-footer">
                <div class="pull-right">
                    {{-- @include("Pluma::partials.pagination", compact('resources')) --}}
                </div>
            </div>
        </div>
    </div>
@endsection

@push('css')
    <style>
        .metadata .metadata-item {
            display: block;
        }
    </style>
@endpush