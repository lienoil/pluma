@extends("Pluma::layouts.admin")

@section("title", 'Enroll to a Course')

@section("content")

    <div class="container-fluid">

        <form action="{{ route('students.store') }}" method="POST">

            {{ csrf_field() }}

            <div class="row">
                <div class="col-md-9">
                    <div class="box no-border">

                        <div class="box-header with-border">
                            <h3 class="box-title">New Enrollee</h3>
                        </div>

                        <div class="box-body">

                            {{-- <div class="input-field col s12">
                                <label for="user_id">User</label>
                                <select name="user_id" id="user_id">
                                    @foreach ( $users as $user )
                                        <option value="{{ $user->id }}" {{ old('user_id') == $user->id ? 'selected="selected"' : '' }}>{{ $user->fullname }}</option>
                                    @endforeach
                                </select>
                                @include("Pluma::errors.span", ['field' => 'user_id'])
                            </div> --}}

                            <div class="input-field col s12">
                                <select name="user_id" id="user_id">
                                    <option value="" disabled selected>Choose Student</option>
                                    @foreach ( $users as $user )
                                        <option value="{{ $user->id }}" {{ old('user_id') == $user->id ? 'selected="selected"' : '' }}>{{ $user->fullname }}</option>
                                    @endforeach
                                </select>
                                {{-- <label class="inputtext" for="user_id">User</label> --}}
                                @include("Pluma::errors.span", ['field' => 'roles'])
                            </div>

                            <div class="input-field col s12">
                                {{-- <label for="course_id">Course</label> --}}
                                <select name="course_id" id="course_id">
                                    @foreach ( $courses as $course )
                                        <option value="{{ $course->id }}" {{ old('course_id') == $course->id ? 'selected="selected"' : '' }}>{{ $course->title }}</option>
                                    @endforeach
                                </select>
                                @include("Pluma::errors.span", ['field' => 'course_id'])

                            </div>


                        </div>

                    </div>

                </div>

                <div class="col-md-3">

                    @include("Pluma::partials.widget-saving", ['label' => 'Save'])

                </div>
            </div>

        </form>
    </div>

@endsection

@push('post-footer')
    @include("Pluma::partials.alert")
@endpush

@push('js')
    <script>
        $(document).ready(function() {
            $('select').material_select();
        });
    </script>
@endpush
