<div class="box no-border m-b-0">
    <div class="with-border">
        <ul class="tabs tabs-main">
            <li class="tab"><a class="active" href="#packages-section">Packages</a></li>
            <li class="tab"><a href="#forms-section">Forms</a></li>
            <li class="tab"><a href="#surveys-section">Survey</a></li>
        </ul>
    </div>
    <div class="box-body">
        <div id="packages-section">
            <div class="cards-masonry">
                @foreach ($packages as $package)
                    <div class="card sticky-action explorer-item">
                       <div class="card-image waves-effect waves-block waves-light">
                            <a href="#"
                                data-explorer-title-value="{{ $package->name }}"
                                data-explorer-text-value="{{ $package->description }}"
                                data-explorer-preview-value="{{ $package->thumbnail }}"
                                data-explorer-target-value="{{ $package->id }}"
                                data-explorer-value-type="{{ $package->type }}">
                                <img max-width="200" width="{{ $package->width }}" src="{{ $package->thumbnail }}" class="card-img-top responsive-img">
                            </a>
                        </div>
                        <div class="card-content">
                            <a class="card-title" href="#"
                                data-explorer-title-value="{{ $package->name }}"
                                data-explorer-text-value="{{ $package->description }}"
                                data-explorer-preview-value="{{ $package->thumbnail }}"
                                data-explorer-target-value="{{ $package->id }}"
                                data-explorer-value-type="{{ $package->type }}">{{ $package->name }}</a>

                            <p>{{ $package->description }}</p>
                        </div>
                        <div class="card-action right-align">
                            <a href="#"
                                data-explorer-title-value="{{ $package->name }}"
                                data-explorer-text-value="{{ $package->description }}"
                                data-explorer-preview-value="{{ $package->thumbnail }}"
                                data-explorer-target-value="{{ $package->id }}"
                                data-explorer-value-type="{{ $package->type }}">Select
                            </a>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>

        <div id="forms-section">
            Forms
        </div>

        <div id="surveys-section">
            Survey
        </div>
    </div>
</div>

<script>
    $('.tabs').tabs();
</script>