@extends("Pluma::layouts.admin")

@section("content")
    @include("Pluma::partials.alert")

    <div class="container-fluid">
        <form action="{{ route('contents.store') }}" method="POST">
            <div class="row">
                <div class="col-md-9">
                    {{ csrf_field() }}
                    <div class="box no-border clonable-block" data-toggle="cloner">
                        <div class="box-header with-border">
                            <h3 class="box-title">New Course</h3>
                        </div>
                        <div class="box-body">
                            <div class="input-field col s12">
                                <input name="title" type="text" class="validate inputfield m-b-0" value="{{ old('title') }}" data-slugger>
                                <label class="inputtext slug-form" for="title">Title</label>
                                @include("Pluma::errors.span", ['field' => 'title'])
                            </div>

                            <div class="input-field col s12">
                                <span class="slug inline">{{ route('public.show', 'courses/contents') }}/</span>
                                <input name="slug" type="text" class="validate slug-form" readonly name="slug" value="{{ old('slug') }}" placeholder="url-slug">
                                @include("Pluma::errors.span", ['field' => 'slug'])
                            </div>

                            <div class="input-field col s12 center-align">
                                <div class="text-muted" data-file-explorer-only data-explorer='{"view":"{{ route('packages.explorer') }}","method":"POST", "_token":"{{ csrf_token() }}"}'>
                                    <img src="{{ old('thumbnail') }}" data-explorer-preview class="explorer-preview-thumbnail">
                                    <div class="text-xs-center">
                                        <span class="text-muted" data-explorer-text>The video/interactive content</span>
                                        <input data-explorer-target type="hidden" name="interactive" value="{{ old('interactive') }}">
                                        <div class="form-group m-t-2">
                                            <button data-explorer-trigger class="btn waves-effect waves-yellow btn-default" type="button">Browse</button>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="input-field col s12 m-b-2">
                                <textarea name="body" class="materialize-textarea inputfield textarea-rows m-b-0">{{ old('body') }}</textarea>
                                <label for="textarea1"  class="inputtext">Description</label> <br>
                                <span class="text-muted">A brief overview about the video/interactive content</span>
                                @include("Pluma::errors.span", ['field' => 'description'])
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-3">
                    @include("Pluma::partials.widget-saving")
                </div>
            </div>
        </form>
    </div>

@endsection

@push('css')
    <link rel="stylesheet" href="{{ assets('Pluma/vendor/jquery-file-explorer/dist/css/jquery.file-explorer.min.css') }}">
@endpush

@push("js")
    <script src="{{ assets('Pluma/vendor/jquery-slugger/dist/jquery.slugger.min.js') }}"></script>
    <script src="{{ assets('Pluma/vendor/jquery-cloner/dist/jquery.cloner.min.js') }}"></script>
    <script src="{{ assets('Pluma/vendor/jquery-file-explorer/dist/js/jquery.file-explorer.min.js') }}"></script>
@endpush