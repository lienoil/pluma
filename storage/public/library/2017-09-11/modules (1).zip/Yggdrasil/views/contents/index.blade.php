@extends("Pluma::layouts.admin")

@section("content")
    @include("Pluma::partials.alert")
    <div class="container-fluid">

        <div class="box no-border">
            <div class="box-header with-border">
                <h3 class="box-title">All Contents</h3>
            </div>
            <div class="box-body p-0">
                <a href="{{ route('contents.create') }}" class="btn waves-effect waves-light btn-yellow m-l-2 m-t-2 m-b-2">Create</a>
                <div class="pull-right m-r-2 m-t-3">
                    @include("Pluma::partials.trash", ['name' => 'contents'])
                </div>
                <div class="clear"></div>

                <div class="table-responsive p-0">
                    <table class="bordered">
                        <thead>
                            <tr>
                                <th class="p-l-2"><input type="checkbox" id="test1"/><label class="m-t-1" for="test1"></label></th>
                                <th>Title</th>
                                <th><a href="{{ route('contents.index') }}">Trainer</a></th>
                                <th>Created</th>
                                <th>Modified</th>
                            </tr>
                        </thead>

                        <tbody>
                            @if ( $resources->isEmpty() )
                                <tr>
                                    <td colspan="5" class="text-muted text-xs-center p-l-2">No resource found.</td>
                                </tr>
                            @endif
                            @foreach ( $resources as $i => $resource )
                                <tr class="tline">
                                    <td width="10" class="mailbox-name p-l-2"><input type="checkbox" id="test2"/><label class="m-t-1" for="test2"></label></td>
                                    <td><strong>{!! $resource->edit_link('contents', $resource->title) !!}</strong></td>
                                    <td><a href="{{ route('contents.index', ['author' => $resource->owner->id]) }}">{{ $resource->owner->displayname }}</a></td>
                                    <td>{{ $resource->created }}</td>
                                    <td>{{ $resource->modified }}</td>
                                    {{-- btn --}}
                                    <td width="20" class="mailbox-name reveal-btn">
                                        <a class="delete-btn" data-toggle="tooltip" data-placement="top" title="show" href="{{ route('contents.show', $resource->id) }}"><i class="fa fa-eye"></i></a>
                                    </td>
                                    <td width="20" class="mailbox-name reveal-btn">
                                        <a class="delete-btn" data-toggle="tooltip" data-placement="top" title="edit" href="{{ route('contents.edit', $resource->id) }}"><i class="fa fa-edit"></i></a>
                                    </td>
                                    <td width="20" class="mailbox-name reveal-btn">
                                        <form class="form-inline" action="{{ route('contents.destroy', $resource->id) }}" method="POST">
                                            {{ csrf_field() }}
                                            {{ method_field('DELETE') }}
                                            <button type="submit" class="delete-btn" data-toggle="tooltip" data-placement="top" title="delete" data-swal='{"title":"Are you sure?","text":"{{ $resource->title }} page will be moved to Trash.","type":"warning","showCancelButton":"true","confirmButtonText":"Remove"}'><i class="fa fa-trash-o"></i></button>
                                        </form>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                        <tfoot>
                            <tr>
                                <th class="p-l-2"><input type="checkbox" id="test2"/><label class="m-t-1" for="test2"></label></th>
                                <th>Title</th>
                                <th><a href="{{ route('contents.index') }}">Trainer</a></th>
                                <th>Created</th>
                                <th>Modified</th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
            <div class="card-footer">
                <div class="pull-right">
                    @include("Pluma::partials.pagination", compact('resources'))
                </div>
            </div>
        </div>
    </div>
@endsection