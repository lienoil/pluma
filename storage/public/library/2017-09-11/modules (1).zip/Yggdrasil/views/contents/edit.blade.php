@extends("Pluma::layouts.admin")

@section("title", 'Edit Content')

@section("content")

    <div class="container-fluid">
        <div class="col-sm-12">
            <h3 class="page-title">Edit Content</h3>
        </div>
    </div>

    @include("Pluma::partials.alert")

    <form action="{{ route('contents.update', $resource->id) }}" method="POST">
        {{ csrf_field() }}
        {{ method_field('PUT') }}
        <div class="container-fluid">
            <div class="col-lg-9">
                <div class="card">
                    <div class="card-block">

                        <div class="form-group">
                            <input type="text" name="title" class="form-control form-control-dashed post-title" value="{{ $resource->title }}" placeholder="Title" data-slugger>
                            @include("Pluma::errors.span", ['field' => 'title'])
                        </div>

                        <div class="form-group">
                            <div class="input-group text-sm">
                                <span class="input-group-addon text-muted input-group-addon-dotted">{{ route('public.show', 'courses/contents') }}/</span>
                                <input type="text" readonly class="form-control form-control-dashed post-slug" name="slug" value="{{ $resource->slug }}" placeholder="url-slug">
                            </div>
                            @include("Pluma::errors.span", ['field' => 'slug'])
                        </div>

                        {{-- <div class="form-group">
                            <input type="text" name="code" class="form-control form-control-dashed" value="{{ $resource->code }}" placeholder="Content Code">
                            @include("Pluma::errors.span", ['field' => 'code'])
                        </div> --}}

                    </div>
                    <div class="card-block card-item">
                        <div class="form-group">
                            <div class="text-muted" data-file-explorer-only data-explorer='{"view":"{{ route('packages.explorer') }}","method":"POST", "_token":"{{ csrf_token() }}", "thumbnail": "false"}'>
                                {{-- <img src="#" data-explorer-preview class="explorer-preview-thumbnail"> --}}
                                <span class="text-muted" data-explorer-text>The video/interactive content</span>
                                <div class="form-group">
                                    <input data-explorer-target type="hidden" class="form-control form-control-dashed" name="interactive" value="{{ $resource->interactive }}">
                                </div>
                                <div class="form-group">
                                    <button data-explorer-trigger class="btn btn-secondary" type="button">Browse</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-block card-item">
                        <div class="form-group">
                            <label for="description" class="text-muted">
                                <strong>Description</strong>
                                <br>
                                <span class="text-muted">A brief overview about the video/interactive content</span>
                            </label>
                            <textarea id="description" name="description" cols="30" rows="10" class="form-control form-control-dashed post-description">{{ $resource->description }}</textarea>
                            @include("Pluma::errors.span", ['field' => 'description'])
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-3">
                @include("Pluma::partials.widget-saving")
            </div>
        </div>
    </form>

@endsection

@push('css')
    <link rel="stylesheet" href="{{ assets('Pluma/vendor/jquery-file-explorer/dist/css/jquery.file-explorer.css') }}">
@endpush

@push("js")
    <script src="{{ assets('Pluma/vendor/jquery-slugger/dist/jquery.slugger.min.js') }}"></script>
    <script src="{{ assets('Pluma/vendor/jquery-cloner/dist/jquery.cloner.min.js') }}"></script>
    <script src="{{ assets('Pluma/vendor/jquery-file-explorer/dist/js/jquery.file-explorer.min.js') }}"></script>
@endpush