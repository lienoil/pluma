@extends("Pluma::layouts.admin")

@section("content")

    <div class="container-fluid">
        <div class="row">
        	<div class="col-md-3 m-b-2">
	            {{-- @include("Yggdrasil::courses.front.table-of-contents") --}}
	        </div>
            <div class="col-md-12">
                @yield("course-content")
            </div>
        </div>
    </div>

@endsection