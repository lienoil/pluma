<div class="card">
    <div class="card-header box-header with-border">
        <spa class="card-title">Comments</spa>
    </div>
    <div class="card-content">
        <div id="comments-container"></div>

        <div class="text-muted text-center"><small><em>No comments available for this course</em></small></div>
    </div>
</div>

@push('css')
    <link rel="stylesheet" type="text/css" href="{{ assets('Pluma/vendor/jquery-comments/css/jquery-comments.css') }}">

    <style>
        .wrapper {
            background: #fff !important;
        }

        .content {
            min-height: 0 !important;
        }

        .spinner {
            display: none !important;
        }

        .jquery-comments ul.navigation li.active:after {
            background: red !important;
        }
    </style>
@endpush

@push('js')
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery.textcomplete/1.8.0/jquery.textcomplete.js"></script>
    <script type="text/javascript" src="{{ assets('Pluma/vendor/jquery-comments/js/jquery-comments.js') }}"></script>

    <script>
        (function($) {
            $(document).ready(function (e) {
                //
            }) ;
        })(jQuery);

        $(function() {
            var saveComment = function(data) {
                $(data.pings).each(function(index, id) {
                    var user = usersArray.filter(function(user){return user.id == id})[0];
                    data.content = data.content.replace('@' + id, '@' + user.fullname);
                });

                return data;
            }

            $('#comments-container').comments({
                profilePictureURL: '{{ auth()->user()->avatar }}',
                currentUserId: '{{ auth()->user()->id }}',
                roundProfilePictures: true,
                textareaRows: 1,
                enableAttachments: true,
                enableHashtags: true,
                enablePinging: true,
                getUsers: function(success, error) {
                    setTimeout(function() {
                        success(usersArray);
                    }, 500);
                },
                getComments: function(success, error) {
                    setTimeout(function() {
                        $.ajax({
                            url: "{{ route('api.comments.lists') }}",
                            type: 'POST',
                            success: function (data) {
                                success(data);
                            }
                         });
                    }, 500);
                },
                postComment: function(data, success, error) {
                    setTimeout(function() {
                        $.ajax({
                            url: "{{ route('api.comments.store') }}",
                            type: 'POST',
                            success: function (qq) {
                                // success(data);
                                console.log(qq);
                                 // console.log();
                            },
                            error:function(ww) {
                                console.log(ww);
                                log();
                            }
                         });
                        success(saveComment(data));
                        console.log(data);
                    }, 500);
                },
                putComment: function(data, success, error) {
                    setTimeout(function() {
                        success(saveComment(data));
                    }, 500);
                },
                deleteComment: function(data, success, error) {
                    setTimeout(function() {
                        success();
                    }, 500);
                },
                upvoteComment: function(data, success, error) {
                    setTimeout(function() {
                        success(data);
                    }, 500);
                },
                uploadAttachments: function(dataArray, success, error) {
                    setTimeout(function() {
                        success(dataArray);
                    }, 500);
                },
            });

            console.log(saveComment, "save");
            console.log(getComment, "get");
        });
    </script>
@endpush