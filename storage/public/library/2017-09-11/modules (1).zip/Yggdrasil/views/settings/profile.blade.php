@extends('Pluma::layouts.admin')

@section("content")
    <section class="content">
        <div class="row">
            <div class="col-md-4">

                @include("Pluma::partials.widget-avatar")

                <div class="box no-border">
                    <div class="box-header with-border">
                        <h3 class="box-title">Badges and Achievements</h3>
                    </div>
                    <div class="box-body">
                        <ul class="collection">
                            <li class="collection-item avatar">
                                <i class="material-icons circle">badge</i>
                                <span class="title">Title</span>
                                </p>
                            </li>
                            <li class="collection-item avatar">
                                <i class="material-icons circle">badge</i>
                                <span class="title">Title</span>
                                </p>
                            </li>
                            <li class="collection-item avatar">
                                <i class="material-icons circle green">badge</i>
                                <span class="title">Title</span>
                                </p>
                            </li>
                            <li class="collection-item avatar">
                                <i class="material-icons circle red">badge</i>
                                <span class="title">Title</span>
                                </p>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-8">
                <div class="box no-border">
                    <div class="box-header with-border">
                        <h3 class="box-title">Basic Information</h3>
                    </div>
                    <div class="box-body">
                        <form action="">
                            <div class="input-field col s12">
                                <input id="title" type="text" class="validate inputfield">
                                <label class="inputtext" for="title">Full Name</label>
                            </div>

                            <div class="input-field col s12">
                                <input id="title" type="text" class="validate inputfield">
                                <label class="inputtext" for="title">Address</label>
                            </div>

                            <div class="input-field col s12">
                                <input id="title" type="text" class="validate inputfield">
                                <label class="inputtext" for="title">E-mail</label>
                            </div>

                            <div class="input-field col s12">
                                <input id="title" type="text" class="validate inputfield">
                                <label class="inputtext" for="title">Contact Number</label>
                            </div>

                            <div class="input-field col s12">
                                <input id="title" type="text" class="validate inputfield">
                                <label class="inputtext" for="title">Emergency Information</label>
                            </div>

                            <div class="input-field col s12">
                                <textarea id="textarea1" class="materialize-textarea inputfield"></textarea>
                                <label for="textarea1"  class="inputtext">Description</label>
                            </div>
                        </form>
                    </div>
                    <div class="card-footer">
                        <a class="btn waves-effect waves-light btn-yellow pull-right">Save</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

@stop

@push('css')

@endpush

@push('js')

@endpush