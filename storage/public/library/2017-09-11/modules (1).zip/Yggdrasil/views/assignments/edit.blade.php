@extends("Pluma::layouts.admin")

@section("title", 'Edit Assignment')

@section("content")
    <div class="container-fluid">
        <form action="{{ route('assignments.update', $resource->id) }}" method="POST" enctype="multipart/form-data">
            {{ csrf_field() }}
            {{ method_field('PUT') }}
            <div class="row">
                <div class="col-lg-9">

                    <div class="card">
                        <div class="card-header box-header with-border">
                            <h3 class="box-title">Edit Assignment</h3>
                        </div>
                        <div class="card-content">

                            <div class="input-field">
                                <input type="text" name="name" class="validate inputfield m-b-0" value="{{ $resource->name }}" data-slugger>
                                <label class="inputtext" for="name">Name</label>
                                @include("Pluma::errors.span", ['field' => 'name'])
                            </div>

                            <div class="input-field m-t-3">
                                <textarea name="description" class="materialize-textarea inputfield textarea-rows">{{ $resource->description }}</textarea>
                                <label for="textarea1"  class="inputtext">Description</label>
                                @include("Pluma::errors.span", ['field' => 'description'])
                            </div>

                            <p class="text-muted grey-text"><em>Current Material is <strong>{{ $resource->upload }}</strong>. Upload another to overwrite.</em></p>
                            <div class="file-field input-field">
                                <div class="btn waves-effect waves-yellow btn-default">
                                    <span>Material</span>
                                    <input id="upload" type="file" name="upload" value="{{ old('upload') }}" accept="application/x-rar-compressed, application/zip, application/octet-stream">
                                </div>
                                <div class="file-path-wrapper">
                                    <input class="file-path inputfield validate p-r-1" type="text" value="{{ $resource->upload }}">
                                </div>
                                @include("Pluma::errors.span", ['field' => 'upload'])
                            </div>

                            <div class="input-field">
                                <select name="content_id" class="select inputfield">
                                    <option class="inputfield" value="" disabled selected multiple>Assign to...</option>
                                    @foreach ($contents as $key => $value)
                                        <option value="{{ $key }}" {{ $resource->content_id == $key ? 'selected="selected"' : "" }}>{{ $value }}</option>
                                    @endforeach
                                </select>
                                {{-- <label class="inputtext" for="content_id">Assigned to</label> --}}
                                @include("Pluma::errors.span", ['field' => 'type'])
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    @include("Pluma::partials.widget-saving")
                </div>
            </div>
        </form>
    </div>
@endsection

@push('pre-footer')
    @include("Pluma::partials.alert")
@endpush

@push('css')
    <style>
        .select-wrapper .select-dropdown {
            margin-bottom: 0 !important;
        }
    </style>
@endpush

@push('js')
    <script>
        $(document).ready(function() {
            $('select').material_select();
        });
    </script>
@endpush