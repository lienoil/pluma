@extends("Pluma::layouts.admin")

@section("title", 'New Assignment')

@section("content")

    <div class="container-fluid">
        <form action="{{ route('assignments.store') }}" method="POST" enctype="multipart/form-data">
            {{ csrf_field() }}
            <div class="row">
                <div class="col-lg-9">

                    <div class="card">
                        <div class="card-header box-header with-border">
                            <h3 class="box-title">New Assignment</h3>
                        </div>
                        <div class="card-content">
                            <div class="input-field">
                                <input type="text" name="name" class="validate inputfield m-b-0" value="{{ old('name') }}" data-slugger>
                                <label class="inputtext" for="name">Name</label>
                                @include("Pluma::errors.span", ['field' => 'name'])
                            </div>

                            <div class="input-field m-t-3">
                                <textarea name="description" class="materialize-textarea inputfield textarea-rows">{{ old('description') }}</textarea>
                                <label for="textarea1"  class="inputtext">Description</label>
                                @include("Pluma::errors.span", ['field' => 'description'])
                            </div>

                            <div class="file-field input-field">
                                <div class="btn waves-effect waves-yellow btn-default">
                                    <span>Material</span>
                                    <input id="upload" type="file" name="upload" value="{{ old('upload') }}" accept="application/x-rar-compressed, application/zip, application/octet-stream">
                                    {{-- <label for="upload"  class="inputtext">Material</label> --}}
                                    @include("Pluma::errors.span", ['field' => 'upload'])
                                </div>
                                <div class="file-path-wrapper">
                                    <input class="file-path inputfield validate p-r-1" type="text">
                                </div>
                            </div>

                            <div class="input-field">
                                <select name="content_id" class="select m-0 inputfield">
                                    <option value="" disabled selected multiple>Assign to...</option>
                                    @foreach ($contents as $key => $value)
                                        <option value="{{ $key }}" {{ old('content_id') == $key ? 'selected="selected"' : "" }}>{{ $value }}</option>
                                    @endforeach
                                </select>
                                <label class="inputtext" for="content_id">Type</label>
                                @include("Pluma::errors.span", ['field' => 'type'])
                            </div>

                        </div>

                    </div>
                </div>

                <div class="col-lg-3">
                    @include("Pluma::partials.widget-saving")
                </div>

            </div>
        </form>
    </div>
@endsection

@push('pre-footer')
    @include("Pluma::partials.alert")
@endpush

@push('css')
    <style>
        .select-wrapper .select-dropdown {
            margin-bottom: 0 !important;
        }
    </style>
@endpush

@push('js')
    <script>
        $(document).ready(function() {
            $('select').material_select();
        });
    </script>
@endpush