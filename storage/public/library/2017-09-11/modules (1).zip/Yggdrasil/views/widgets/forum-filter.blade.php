<div class="box no-border">
    <div class="box-header with-border">
        <h3 class="box-title">Filter Categories</h3>
    </div>
    <div class="box-body">
        <ul class="collection">
            @foreach ( $categories as $category )
               <li class="collection-item">
                   <a href="#">{{ $category->name }}</a>
               </li>
                @include("Pluma::errors.span", ['field' => 'title'])
            @endforeach
        </ul>
    </div>
</div>

@push('css')
    <style>
        .collection {
            border: none !important;
        }

        .collection .collection-item:last-child {
            border-bottom: none !important;
            margin-bottom: 0 !important;
        }
    </style>
@endpush