@if ( ! empty( $resource ) )
<div class="card">
    @if ( ! isset( $withHeader ) || isset( $withHeader ) && $withHeader )
        <div class="card-header box-header with-border">
            <h3 class="card-title text-dark">Continue Learning</h3>
        </div>
    @endif
    <div class="card horizontal no-shadow">
        <div class="card-image card-image-left card-box bg-psdm">
            <img src="{{ $resource->thumbnail }}" alt="{{ $resource->title }}" width="240">
        </div>
        <div class="card-stacked">
            <div class="card-content">
                <h3 class="card-title uppercase text-dark"><a href="{{ route('courses.show', $resource->code) }}" class="text-dark"><strong>{{ $resource->code }}</strong><span class="card-subtitle">{{ $resource->title }}</span></a></h3>
                <div class="card-metadata m-b-1">
                    <small class="metadata-item"><i class="icon-books">&nbsp;</i>{{ $resource->code }}</small>
                    @include("Pluma::widgets.chips.categories")
                    <div>
                        <small><i class="fa fa-calendar-o">&nbsp;</i>Enrolled {{ $resource->created }}</small>
                    </div>
                </div>

                @if ( $resource->excerpt )
                    {!! $resource->excerpt !!}
                @endif
            </div>

            <div class="card-footer">
                <div class="row col-md-12">
                    @if ($resource->percentage <= '30')
                        <span class="pull-right text-danger percentage-text"><span class="percentage">{{ $resource->percentage or '0' }}</span>% Complete</span>
                    @elseif ($resource->percentage >= '31' && $resource->percentage <= '60')
                        <span class="pull-right text-warning percentage-text"><span class="percentage">{{ $resource->percentage or '0' }}</span>% Complete</span>
                    @else
                        <span class="pull-right text-success percentage-text"><span class="percentage">{{ $resource->percentage or '0' }}</span>% Complete</span>
                    @endif
                    <div class="progress progress-md">

                        @if ($resource->percentage <= '30')
                            <div class="progress-bar progress-bar-danger progress-bar-striped progress-bar-animated" role="progressbar" aria-valuenow="{{ $resource->percentage }}" aria-valuemin="0" aria-valuemax="100" style="width: {{ $resource->percentage }}%">
                        @elseif ($resource->percentage >= '31' && $resource->percentage <= '60')
                            <div class="progress-bar progress-bar-warning progress-bar-striped progress-bar-animated" role="progressbar" aria-valuenow="{{ $resource->percentage }}" aria-valuemin="0" aria-valuemax="100" style="width: {{ $resource->percentage }}%">
                        @else
                            <div class="progress-bar progress-bar-success progress-bar-striped progress-bar-animated" role="progressbar" aria-valuenow="{{ $resource->percentage }}" aria-valuemin="0" aria-valuemax="100" style="width: {{ $resource->percentage }}%">
                        @endif
                            <span class="sr-only"><span class="percentage">{{ $resource->percentage }}%</span> Complete</span>
                        </div>

                    </div>
                </div>
            </div>

            <div class="card-action align-right">
                @allow('show-course')
                    <a href="{{ url($resource->lastlink) }}" class="btn waves-effect waves-light btn-yellow m-r-2"><i class="fa fa-play font-14">&nbsp;</i>{{ $resource->percentage == 0 ? 'Start' : 'Resume' }}</a>
                @endallow
            </div>
        </div>
    </div>
</div>
@endif