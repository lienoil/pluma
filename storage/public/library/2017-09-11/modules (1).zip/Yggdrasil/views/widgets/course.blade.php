@if (!empty($resource))
<div class="card">
    <div class="card-header box-header with-border">
        <h3 class="card-title uppercase text-dark">{{ $resource->title }}</h3>
    </div>
    <div class="card horizontal no-shadow m-b-0">
        <div class="card-image card-image-left card-image-max-30 card-box bg-psdm">
            <img src="{{ $resource->thumbnail }}" alt="{{ $resource->title }}" style="width:190px !important;">
        </div>
        <div class="card-stacked">
            <div class="card-content">
                <div class="card-metadata m-b-1">
                    @enrolled($resource)
                        <small><i class="fa fa-calendar-o">&nbsp;</i>Enrolled {{ $resource->created }}</small>
                    @endenrolled
                    <small class="metadata-item"><i class="icon-books">&nbsp;</i>{{ $resource->code }}</small>
                    @include("Pluma::widgets.chips.categories")
                </div>


                @if ( $resource->description )
                    {!! $resource->description !!}
                @endif
            </div>

            {{-- @allow($resource) --}}
            @allow('show-profile')
            <div class="card-footer">
                <div class="row col-md-12">
                    <span class="pull-right grey-text">{{ $resource->percentage }}% Complete</span>
                    <div class="progress progress-xs">
                        <div class="progress-bar progress-bar-primary progress-bar-striped" role="progressbar" aria-valuenow="{{ $resource->percentage }}" aria-valuemin="0" aria-valuemax="100" style="width: {{ $resource->percentage }}%">
                            <span class="sr-only">{{ $resource->percentage }}% Complete</span>
                        </div>
                    </div>
                </div>
            </div>
            @endallow
        </div>
    </div>
</div>
@endif