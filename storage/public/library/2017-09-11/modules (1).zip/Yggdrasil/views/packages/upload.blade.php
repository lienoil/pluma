@extends("Pluma::layouts.admin")

@section("content")

    <div class="container-fluid">
        <div class="row">

            <form action="{{ route('packages.store') }}" method="POST" enctype="multipart/form-data">
                {{ csrf_field() }}
                {{-- {{ method_field('PUT') }} --}}
                <div class="col-md-9">
                    <div class="box no-border">
                        <div class="box-header with-border">
                            <h3 class="box-title">Upload Package</h3>
                        </div>
                        <div class="box-body">
                            <div class="file-field input-field">
                                <div class="btn waves-effect waves-yellow btn-default">
                                    <span>Choose File</span>
                                    <input id="upload" type="file" name="upload" value="{{ old('upload') }}" accept="application/x-rar-compressed, application/zip, application/octet-stream">
                                    @include("Pluma::errors.span", ['field' => 'upload'])
                                </div>
                                <div class="file-path-wrapper">
                                    <input class="file-path inputfield validate p-r-1" type="text">
                                </div>
                            </div>

                            <div class="input-field m-t-4">
                                <input name="name" type="text" class="validate inputfield m-b-0" value="{{ old('name') }}" data-slugger>
                                <label class="inputtext slug-form" for="name">Name</label>
                                @include("Pluma::errors.span", ['field' => 'name'])
                            </div>

                            <div class="input-field m-t-4">
                                <textarea name="description" type="text" class="materialize-textarea inputfield textarea-rows">{{ old('description') }}</textarea>
                                <label for="textarea1"  class="inputtext">Description</label>
                                @include("Pluma::errors.span", ['field' => 'description'])
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    @include("Pluma::partials.widget-saving")
                </div>
            </form>

        </div>
    </div>
@endsection

@push('pre-footer')
    @include("Pluma::partials.alert")
@endpush