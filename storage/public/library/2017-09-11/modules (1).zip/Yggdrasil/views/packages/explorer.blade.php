@include("Pluma::partials.header")
@include("Pluma::partials.footer")

<div class="container-fluid">



    <div class="box no-border">
        @foreach ( $resources as $resource )
            <div class="col-md-4">
                <div class="box-body">
                    <div class="card-img">
                        <a href="#" data-explorer-title-value="{{ $resource->name }}" data-explorer-text-value="{{ $resource->description }}" data-explorer-preview-value="{{ $resource->thumbnail }}" data-explorer-target-value="{{ $resource->id }}"><img width="{{ $resource->width }}" src="{{ $resource->thumbnail }}" class="card-img-top img-fluid"></a>
                    </div>
                    <div class="card-content card-block">
                        <p><a href="#" data-explorer-title-value="{{ $resource->name }}" data-explorer-text-value="{{ $resource->description }}" data-explorer-preview-value="{{ $resource->thumbnail }}" data-explorer-target-value="{{ $resource->id }}"><strong>{{ $resource->name }}</strong></a></p>
                        <p>{{ $resource->description }}</p>
                        <button data-explorer-title-value="{{ $resource->name }}" data-explorer-text-value="{{ $resource->description }}" data-explorer-preview-value="{{ $resource->thumbnail }}" data-explorer-target-value="{{ $resource->id }}" type="button" class="btn waves-effect waves-yellow btn-default">Select</button>
                    </div>
                </div>
            </div>
        @endforeach
    </div>
</div>