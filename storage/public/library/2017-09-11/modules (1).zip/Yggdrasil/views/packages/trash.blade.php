@extends("Pluma::layouts.admin")

@section("content")
    <div class="container-fluid">

        <div class="box no-border">
            <div class="box-header with-border">
                <h3 class="box-title">Trashed Packages</h3>
            </div>
            <div class="box-body p-0">
                <a href="{{ route('packages.index') }}" class="waves-effect waves-yellow btn btn-default m-l-2 m-t-2 m-b-2">Back</a>
                <div class="pull-right m-r-2 m-t-3">
                    @include("Pluma::partials.trash", ['name' => 'packages'])
                </div>
                <div class="clear"></div>

                <div class="table-responsive p-0">
                    <table class="bordered">
                        <thead>
                            <tr>
                                <th class="p-l-2"><input type="checkbox" id="test1"/><label class="m-t-1" for="test1"></label></th>
                                <th>Title</th>
                                <th>Created</th>
                                <th>Modified</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            @if ( $resources->isEmpty() )
                                <tr>
                                    <td colspan="5" class="text-muted text-xs-center">No resource found.</td>
                                </tr>
                            @endif
                            @foreach ( $resources as $i => $resource )
                                <tr class="tline">
                                    <td width="10" class="mailbox-name p-l-2"><input type="checkbox" id="test1"/><label class="m-t-1" for="test1"></label></td>
                                    <td>
                                        <strong>{{ $resource->name }}</strong>
                                    </td>
                                    <td>{{ $resource->created }}</td>
                                    <td>{{ $resource->modified }}</td>
                                    <td width="20" class="mailbox-name reveal-btn">
                                        <form class="form-inline" action="{{ route('packages.restore', $resource->id) }}" method="POST">
                                                {{ csrf_field() }}
                                            <button type="submit" class="delete-btn" data-toggle="tooltip" data-placement="top" title="restore"><i class="fa fa-refresh"></i></button>
                                        </form>
                                    </td>
                                    <td width="20" class="mailbox-name reveal-btn">
                                        <form class="form-inline" action="{{ route('packages.destroy', $resource->id) }}" method="POST">
                                            {{ csrf_field() }}
                                            {{ method_field('DELETE') }}
                                            <button type="submit" class="delete-btn btn-confirm" data-toggle="tooltip" data-placement="top" title="delete permanently"><i class="fa fa-trash-o"></i></button>
                                        </form>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="card-footer">
                <div class="pull-right">
                    @include("Pluma::partials.pagination", compact('resources'))
                </div>
            </div>
        </div>
    </div>
@endsection

@push('pre-footer')
    @include("Pluma::partials.alert")
@endpush

@push('js')
    {{-- <script src="{{ assets("Pluma/vendor/sweetalert2/dist/sweetalert2.min.js") }}"></script>
    <script>
        $(document).on('click', '.btn-confirm', function (e) {
            var options = $(this).data('swal');
            console.log(options);
            options = $.parseJSON(options);
            swal(options);
            e.preventDefault();
        });
    </script> --}}
@endpush