@extends("Pluma::layouts.admin")

@section('content')

    <div class="container-fluid">
        <div class="no-border">
            <a href="{{ route('packages.upload') }}" class="btn waves-effect waves-light btn-yellow m-b-2">Upload Packages</a>
            <div class="pull-right m-t-1">
                @include("Pluma::partials.trash", ['name' => 'packages'])
            </div>

            @if ( $resources->isEmpty() )
                <p class="m-t-3 text-muted text-center"><i class="fa fa-archive">&nbsp;</i>No Packages to show</p>
            @endif

            <div class="cards-masonry four-columns">
                @foreach ( $resources as $resource )
                    <div class="card sticky-action">
                        <div class="card-image image-reveal waves-effect waves-block waves-light card-bg">
                            <a class="valign-wrapper package-card" href="{{ route('packages.edit', $resource->id) }}">
                            <img src="{{ $resource->thumbnail }}" alt="{{ $resource->displayname }}" class="valign img-responsive"></a>
                        </div>

                        <div class="card-content">
                            <span class="card-title activator grey-text">{{ $resource->displayname }}<i class="material-icons right">more_vert</i></span>
                            @if ( $resource->warning )
                                <p class="text-danger"><i class="fa fa-warning">&nbsp;</i>{{ $resource->warning }}</p>
                            @endif
                        </div>

                        <div class="card-action">
                            <a class="text-info" href="{{ route('packages.edit', $resource->id) }}">Edit</a>

                            @include("Pluma::partials.form-destroy", ['name' => 'packages', 'is_flat' => 1, 'form_class' => 'form-inline right m-0'])
                        </div>

                        <div class="card-reveal">
                            <span class="card-title grey-text">{{ $resource->displayname }}<i class="material-icons right">close</i></span>
                            <div class="metadata m-t-2">
                                @if ( $resource->excerpt )
                                    <p class="metadata-item m-t-1">{{ $resource->excerpt }}</p>
                                @endif
                                <small class="metadata-item text-muted"><i class="fa fa-external-link">&nbsp;</i>{{ $resource->url }}</small>
                                <small class="metadata-item text-muted"><i class="fa fa-calendar">&nbsp;</i>Created {{ $resource->created }}</small>
                                <small class="metadata-item text-muted"><i class="fa fa-calendar">&nbsp;</i>Modified {{ $resource->modified or 'not modified' }}</small>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
        <div class="card-footer no-bg no-border">
            <div class="pull-right">
                {{-- @include("Pluma::partials.pagination", compact('resources')) --}}
            </div>
        </div>
    </div>
@endsection

@push('pre-footer')
    @include("Pluma::partials.alert")
@endpush