@extends("Pluma::layouts.admin")
@section("content")
    @include("Pluma::partials.alert")
    @include("Pluma::errors.messages")

    <div class="container-fluid">
        <div class="box no-border">
            <div class="box-header with-border">
                <h3 class="box-title">Test</h3>
            </div>
            <form action="{{ route('packages.update', $resource->id) }}" method="POST" enctype="multipart/form-data">
                <div class="box-body">
                    {{ csrf_field() }}
                    {{ method_field('PUT') }}

                    <div class="form-group text-xs-center">
                        <p class="text-muted text-xs-center">You cannot edit the SCORM package itself, you should perform a separate upload of the updated file.</p>
                    </div>

                    <div class="input-field m-t-4">
                        <input name="name" type="text" class="validate inputfield m-b-0" value="{{ $resource->name }}" data-slugger>
                        <label class="inputtext slug-form" for="name">Name</label>
                        @include("Pluma::errors.span", ['field' => 'name'])
                    </div>

                    <div class="input-field m-t-4">
                        <textarea name="description" type="text" class="materialize-textarea inputfield textarea-rows">{{ $resource->description }}</textarea>
                        <label for="textarea1"  class="inputtext">Description</label>
                        @include("Pluma::errors.span", ['field' => 'name'])
                    </div>
                </div>
                <div class="card-footer">
                    <button type="submit" class="btn waves-effect waves-light btn-yellow pull-right">Update</button>
                </div>
            </form>
        </div>
    </div>
@endsection