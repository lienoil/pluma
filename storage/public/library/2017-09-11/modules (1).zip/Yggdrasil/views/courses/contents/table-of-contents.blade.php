@foreach ( $contents as $content )
    @if ( ! $content->viewable )
        {{-- <div class="list-group-item"> --}}
            <i class="fa fa-lock">&nbsp;</i>{{ $content->content->name }}
            {{-- {{ $content->id }} --}}
        </div>
    @else
        {{-- <a href="{{ route('contents.show', [$course->code, $content->id]) }}" class="list-group-item {{ $id == $content->id ? 'active' : '' }}">
            {{ $content->content->name }}
        </a> --}}
    @endif
@endforeach

<a class="waves-effect waves-yellow btn btn-default" href="#toc"><i class="fa fa-list-ul font-14" aria-hidden="true"></i> Table of Contents</a>
<div id="toc" class="modal bottom-sheet">
    <div class="modal-content">
        <ul class="collapsible popout" data-collapsible="expandable">
            <li>
                <div class="collapsible-header {{ $id == $content->id ? 'active' : '' }}"><i class="fa fa-unlock" style="color: #6d6d6d;" aria-hidden="true"></i>Intro</div>
                <div class="collapsible-body bg-light">
                    <ul class="collection">
                        <li>
                            <a class="collection-item avatar" href="{{ route('contents.show', [$course->code, $content->id]) }}" class="list-group-item {{ $id == $content->id ? 'active' : '' }}">
                                <span class="circle"><i class="fa fa-check-circle" style="font-size: 42px; color: #00a65a;"aria-hidden="true"></i></span>
                                <p class="title text-dark">{{ $content->content->name }}</p>
                                <p class="text-dark">{{ $content->content->description }}</p>
                                <div class="secondary-content"><i class="material-icons">100%</i></div>
                            </a>
                        </li>
                        <li>
                            <a class="collection-item avatar" href="#!" class="list-group-item">
                                <span class="circle"><i class="fa fa-check-circle" style="font-size: 42px; color: #00a65a;"aria-hidden="true"></i></span>
                                <p class="title text-dark">Title</p>
                                <p class="text-dark">Description</p>
                                <div class="secondary-content"><i class="material-icons">100%</i></div>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li>
                <div class="collapsible-header"><i class="fa fa-lock" style="color: #6d6d6d;" aria-hidden="true"></i>PS 1</div>
                <div class="collapsible-body"><span>Lorem ipsum dolor sit amet.</span></div>
            </li>
            <li>
                <div class="collapsible-header"><i class="fa fa-lock" style="color: #6d6d6d;" aria-hidden="true"></i>PS 2</div>
                <div class="collapsible-body"><span>Lorem ipsum dolor sit amet.</span></div>
            </li>
            <li>
                <div class="collapsible-header"><i class="fa fa-lock" style="color: #6d6d6d;" aria-hidden="true"></i>PS 3</div>
                <div class="collapsible-body"><span>Lorem ipsum dolor sit amet.</span></div>
            </li>
        </ul>
    </div>
</div>


{{-- <div class="box no-border">
    <div class="box-header with-border">
        <h3 class="box-title">Comments</h3>
    </div>
    <div class="box-body">
        <div class="container">
        <p class="text-red">Leave a Reply</p>
            <form>
                <div class="input-field">
                    <textarea disabled name="body" class="materialize-textarea" style="
                        border: 1px solid rgb(138, 138, 138); height: 21px; "></textarea>
                </div>
                <button type="submit" class="btn waves-effect waves-yellow btn-default pull-right">Post Comment</button>
            </form>
            <div class="clear"></div>

            <hr>
            <p class="text-red">3 Responses to [Course Title]</p>
            <ul class="collection no-border">
                <li class="collection-item avatar no-bg no-border" style="border-bottom: none !important;">
                    <img src="https://placeimg.com/640/480/any" alt="" class="circle">
                    <span class="title"><strong>Jane Doe</strong></span> <br>
                    <small><i class="fa fa-clock-o" aria-hidden="true"></i> April 17, 2017 9:00am</small> <br>
                   <div class="m-t-1">
                       Lorem ipsum dolor sit amet, consectetur adipisicing elit. Omnis, nostrum rerum sunt,
                   </div>
                    <ul class="collection">
                        <li class="collection-item avatar no-bg">
                            <img src="https://placeimg.com/640/480/any" alt="" class="circle">
                            <span class="title"><strong>Ken Smith</strong></span> <br>
                            <small><i class="fa fa-clock-o" aria-hidden="true"></i> April 16, 2017 9:00am</small> <br>
                               <div class="m-t-1">
                                    cum ipsum dolorem, laudantium culpa reiciendis aliquid delectus eaque. Quisquam quia, impedit ab. Quidem illum vitae iure velit!
                               </div>
                            </p>
                        </li>
                        <li class="collection-item avatar no-bg">
                            <img src="https://placeimg.com/640/480/any" alt="" class="circle">
                            <span class="title"><strong>Ken Smith</strong></span> <br>
                            <small><i class="fa fa-clock-o" aria-hidden="true"></i> April 16, 2017 9:00am</small> <br>
                               <div class="m-t-1">
                                   <textarea disabled name="" id="" placeholder="Write a comment.." cols="30" rows="10"></textarea>
                                   <a href=""></a>
                               </div>
                            </p>
                        </li>
                    </ul>
                </li>

                <li class="collection-item avatar no-bg no-border" style="border-bottom: none !important;">
                    <img src="https://placeimg.com/640/480/any" alt="" class="circle">
                    <span class="title"><strong>Ken Smith</strong></span> <br>
                    <small><i class="fa fa-clock-o" aria-hidden="true"></i> April 17, 2017 9:00am</small> <br>
                   <div class="m-t-1">
                       Hello!
                   </div>
                    <ul class="collection">
                        <li class="collection-item avatar no-bg">
                            <img src="https://placeimg.com/640/480/any" alt="" class="circle">
                            <span class="title"><strong>Ken Smith</strong></span> <br>
                            <small>April 16, 2017 9:00am</small> <br>
                               <div class="m-t-1">
                                   <textarea name="" id="" placeholder="Write a comment.." cols="30" rows="10" disabled></textarea>
                                   <a href=""></a>
                               </div>
                            </p>
                        </li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</div> --}}

@push('css')
    <style>
        #form1 {
            display : none;
        }
        button {
            margin-bottom: 10px;
        }
    </style>
@endpush

@push('js')
    <script>
        $(document).ready(function(){
            $('.modal').modal();
        });
    </script>
@endpush