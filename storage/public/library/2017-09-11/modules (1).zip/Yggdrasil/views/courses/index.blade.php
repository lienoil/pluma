@extends("Pluma::layouts.admin")

@section("content")

	<div class="container-fluid" id="content-tab-courses">
		<div class="row s12">
			<div class="btn-group list-grid-view pull-right m-b-3" data-toggle="buttons">
				<label id="list" class="btn-flat waves-effect waves-yellow btn m-t-2 btn-default active btn-switcher">
					<input type="radio" name="options" id="option1" autocomplete="off" checked> <i class="fa fa-list info font-14" aria-hidden="true"></i> List</label>
				<label id="grid" class="btn-flat waves-effect waves-yellow btn m-t-2 btn-default btn-switcher">
					<input type="radio" name="options" id="option2" autocomplete="off"> <i class="fa fa-th info font-14" aria-hidden="true"></i> Grid </label>
			</div>
			<div id="nav">
				<ul class="tabs tabs-main m-b-2">
					<li class="tab col s2"><a class="{{ auth()->user()->isRoot() ? 'active' : '' }}" href="#courses">All Courses</a></li>

					@allow('current-course')
						@role('student')
							<li class="tab col s2"><a class="active" href="#current">Current</a></li>
						@else
							<li class="tab col s2"><a href="#current">Current</a></li>
						@endrole
					@endallow

					@allow('previous-course')
					<li class="tab col s2"><a href="#previous">Previous</a></li>
					@endallow
					@allow('recommended-course')
					<li class="tab col s2"><a href="#recommended">Recommended</a></li>
					@endallow
					@allow('bookmarked-course')
					<li class="tab col s2"><a href="#bookmarked">Bookmarked</a></li>
					@endallow
				</ul>
			</div>

			<div id="courses" class="col s12">
				<div class="row">
					@foreach ( $resources as $i => $resource )
						<div class="col-sm-12 item course-item">
							@include("Yggdrasil::widgets.courses.course")
						</div>
					@endforeach
				</div>
			</div>

			@allow('current-course')
			<div id="current" class="col s12">
				@include("Yggdrasil::courses.partials.current")
			</div>
			@endallow

			@allow('previous-course')
			<div id="previous" class="col s12">
				@include("Yggdrasil::courses.partials.previous")
			</div>
			@endallow

			@allow('recommended-course')
			<div id="recommended" class="col s12">
				@include("Yggdrasil::courses.partials.recommended")
			</div>
			@endallow

			@allow('bookmarked-course')
			<div id="bookmarked" class="col s12">
				@include("Yggdrasil::courses.partials.bookmarked")
			</div>
			@endallow
		</div>
	</div>

@endsection

@push('pre-footer')
	@include("Pluma::partials.alert")
@endpush

@push('css')
	{{-- quickfix --}}
	<style>
		#nav{
			z-index: 10 !important;
			margin: 0 !important;
		    padding: 0 !important;
		    width: 100% !important;
		    background-color: #BFFFF3 !important;
		    top: 0 !important;
		    position: -webkit-sticky !important;
		    position: sticky !important;
		}

		.tabs.tabs-main {
			border-bottom: 1px solid #e4e4e4;
		}

		.sticky {
		    top: 0 !important;
		    position: fixed !important;
		}

		.tabx {
			position: absolute;
			right: 0;
			top: 56px;
		}

		#content-tab-courses {
			margin-top: -20px;
		}

		.text-red {
			color: #D8462A !important;
		}

		.tabs .tabs-main {
			width: 100%;
		}
	</style>
@endpush

@push('js')

	<script>
		$(function() {
			$('#list').on('click', function() {
		    	$('#content-tab-courses .item').removeClass('col-md-3').addClass('col-md-12');
		    	$('#content-tab-courses .item.course-item .card').removeClass('vertical').addClass('horizontal');
		    	$('#content-tab-courses .item.course-item .card .card-stacked .card-action').addClass('text-left').removeClass('text-center');
			});

		    $('#grid').on('click', function() {
		    	$('#content-tab-courses .item').removeClass('col-md-12').addClass('col-md-3');
		    	$('#content-tab-courses .item.course-item .card').removeClass('horizontal').addClass('vertical');
		    	$('#content-tab-courses .item.course-item .card .card-stacked .card-action').addClass('text-center').removeClass('text-left');
		    });
		});

		$(function() {
			str = "content-courses";

			if (str == "content-courses") {
				console.log("Right");
			}
			else if (str == "Select") {
				console.log("Meat");
			}
			else if (str == "Food") {
				console.log("Fast food");
			}

			else if (str == "Meaning") {
				console.log("Meaning, right");
			}
			else if (str == "POS") {
				console.log("POS Details");
			}
			else {
				console.log("Wrong");
			}
		})
	</script>
@endpush