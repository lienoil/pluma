@extends("Yggdrasil::layouts.course")

@section("course-content")

    <div class="card">
        <div class="card-header box-header with-border">
            <h3 class="card-title">{{ $resource->name }}</h3>
        </div>
        <div class="card-content">
            @if ( $course->isViewable() )
                @if ( $resource->type == get_class(new \Form\Models\Form) )
                    {!! $resource->form !!}
                @else
                    {{-- {{ $resource->interactive }} --}}
                    {{-- <embed src="{{ $resource->interactive }}" style="width:100%; height:420px;"> --}}
                    <iframe class="course-content" id="interactive" src="{{ $resource->interactive }}" name="course" style="width:100%; min-height:600px;" frameborder="0"></iframe>

                     @if ( $resource->description )
                        <p><strong>Description</strong></p>
                        {!! $resource->description or 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Debitis quo fuga, ratione doloremque autem nihil vitae aspernatur deleniti, iste mollitia eveniet cum esse? Minus esse ipsum omnis exercitationem dolor hic.' !!}
                    @endif
                @endif
            @else

                <div class="placeholder-frame bg-light">
                    <div class="placeholder-frame-content">
                        <p class="placeholder-frame-title grey-text text-center p-t-1"><i class="fa fa-lock">&nbsp;</i>This content is locked</p>
                    </div>
                </div>

            @endif
        </div>
    </div>

@endsection

@push('js')
    <script src="{{ assets("Yggdrasil/js/scorm-1.2-api.js") }}"></script>
    <script>
        initAPI({
            initialize: {
                id: "{{ $id }}",
                student_id: "{{ auth()->user()->id }}",
                method: "GET",
                _token: "{{ csrf_token() }}",
                url: "/api/courses/initialize",
            },
            id: "{{ $id }}", url: "/api/courses/save-status", method: "POST", _token: "{{ csrf_token() }}"
        });
    </script>
    {{-- <script src="{{ assets("Yggdrasil/js/Controllers/Captivate/CaptivateController.js") }}"></script> --}}
@endpush