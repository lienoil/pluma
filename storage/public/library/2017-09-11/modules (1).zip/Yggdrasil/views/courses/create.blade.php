@extends("Pluma::layouts.admin")

@section("content")
	<div class="container-fluid">
		<form action="{{ route('courses.store') }}" method="POST">
			{{ csrf_field() }}
			<div class="row">
				<div class="col-md-9">
					<div class="box no-border">
						<div class="box-header with-border">
							<h3 class="box-title">New Course</h3>
						</div>
						<div class="box-body">
							<div class="input-field">
								<input name="title" type="text" value="{{ old('title') }}" class="validate inputfield m-b-0" data-slugger>
								<label class="inputtext" for="title">Title</label>
								@include("Pluma::errors.span", ['field' => 'title'])
							</div>

							<div class="input-field">
								<span class="slug inline">{{ route('public.show', config("settings.yggdrasil.course_url_prefix", 'courses')) }}/</span>
								<input name="slug" type="text" class="validate slug-form" readonly name="slug" value="{{ old('slug') }}" placeholder="url-slug">
								@include("Pluma::errors.span", ['field' => 'slug'])
							</div>

							<div class="input-field">
								<input name="code" type="text" value="{{ old('code') }}" class="validate inputfield">
								<label class="inputtext" for="code">Course Code</label>
								@include("Pluma::errors.span", ['field' => 'code'])
							</div>

							<div class="input-field m-0 m-t-2">
			                	<textarea name="description" class="materialize-textarea inputfield textarea-rows">{{ old('description') }}</textarea>
			                	<label for="textarea1"  class="inputtext">Description</label>
			                	@include("Pluma::errors.span", ['field' => 'description'])
			              	</div>
						</div>
					</div>

					<div class="clonable-block" data-toggle="cloner">
						<div data-explorer='{"view":"{{ route('content.explorer') }}","_token":"{{ csrf_token() }}","clonable":"true"}'>
							<div class="card">
								<div class="card-header box-header with-border">
									<h3 class="box-title">Content</h3>
								</div>
	                            <div class="todo-list ui-sortable" data-clonable-template>
	                                <div class="clonable" data-clone-source>
		            					<div class="card horizontal m-b-0 clonable no-shadow with-border">
	                                        <div class="card-image card-image-left card-image-max-30">
	                                        	<img class="img-responsive m-2" width="80" style="width:190px !important;" data-explorer-preview>
	                                        </div>
	                                        <div class="card-stacked">
		                                    	<div class="card-content">
	                                    			<span role="button" class="close pull-right" data-clone-close><i class="material-icons">close</i></span>
		                                    		<h5 class="card-title" data-explorer-title>No Content yet</h5>
		                                    		<p data-explorer-text></p>

		                                            <input type="hidden" data-clone-sort-name name="contents[0][package_id]" data-explorer-target>
		                                            <input type="hidden" data-clone-sort-name name="contents[0][sort]" data-clone-sort-value value="1">

	                                                {{-- <p>
	                                                    <input id="locked" name="locked" class="filled-in" value="1" checked="checked" type="checkbox">
	                                                    <label for="locked" class="inputtext">Lock content </label>
	                                                </p> --}}
		                                    	</div>
	                                        </div>
	                                    </div>
	                                </div>
	                            </div>
		                        <div class="card-action align-center text-center">
	                                <div class="form-group m-0 p-0">
	                                    @include("Pluma::errors.span", ['field' => 'contents'])
	                                </div>
	                                <a data-explorer-trigger class="full-width" href="#">Add Content</a>
	                            </div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					@include("Pluma::partials.widget-saving", ['label' => 'Save'])
					@include("Pluma::partials.widget-featured-image")
					@include("Pluma::widgets.categories")
				</div>
			</div>
		</div>
	</form>
@endsection

@push('pre-footer')
    @include("Pluma::partials.alert")
@endpush

@push('css')
	<link rel="stylesheet" href="{{ assets('Pluma/vendor/jquery-file-explorer/dist/css/jquery.file-explorer.min.css') }}">

	<style>
		.todo-list {
			background: #f8f8f8 !important;
		}
	</style>
@endpush

@push("js")
	<script src="{{ assets('Pluma/vendor/jquery-slugger/dist/jquery.slugger.min.js') }}"></script>
	<script src="{{ assets('Pluma/vendor/jquery-cloner/dist/jquery.cloner.min.js') }}"></script>
	<script src="{{ assets('Pluma/vendor/jquery-file-explorer/jquery-custom/jquery-ui-1.12.1.custom/jquery-ui.min.js') }}"></script>
    <script>
        $('select').material_select();
    </script>
@endpush