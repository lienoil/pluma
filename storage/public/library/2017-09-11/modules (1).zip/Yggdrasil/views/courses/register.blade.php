@extends('Pluma::layouts.admin')
@section("content")
	<div class="container-fluid">
		<div class="card horizontal">
			<div class="card-image">
				<img src="https://placeimg.com/640/480/tech">
			</div>
			<div class="card-stacked">
				<div class="card-content">
					<p><strong>Course Title</strong></p>
					<p>This is a sample Course Description.</p>
				</div>
				<div class="card-action text-right">
					<a href="#" class="m-0">Enroll</a>
				</div>
			</div>
		</div>
			<div class="card horizontal">
			<div class="card-image">
				<img src="https://placeimg.com/640/480/architecture">
			</div>
			<div class="card-stacked">
				<div class="card-content">
					<p><strong>Course Title</strong></p>
					<p>This is a sample Course Description.</p>
				</div>
				<div class="card-action text-right">
					<a href="#" class="m-0">Enroll</a>
				</div>
			</div>
		</div>
	</div>
@stop

@push('css')
@endpush
@push('js')
@endpush