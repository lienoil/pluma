@if ( ! empty( $resource ) )
<div class="card">
    @if ( ! isset( $with_header ) || isset( $with_header ) && $with_header )
        <div class="card-header box-header with-border">
            <h3 class="card-title text-dark">Continue Learning</h3>
        </div>
    @endif
    <div class="card horizontal no-shadow">
        <div class="card-image card-image-left card-image-max-30 card-box bg-psdm">
            <img src="{{ $resource->thumbnail }}" alt="{{ $resource->title }}" style="width:190px !important;">
        </div>
        <div class="card-stacked">
            <div class="card-content">
                <h3 class="card-title uppercase text-dark"><a href="{{ route('courses.show', $resource->code) }}" class="text-dark"><strong>{{ $resource->code }}</strong><span class="card-subtitle">{{ $resource->title }}</span></a></h3>
                <div class="card-metadata m-b-1">
                    <small class="metadata-item"><i class="icon-books">&nbsp;</i>{{ $resource->code }}</small>
                    @include("Pluma::widgets.chips.categories")
                    <div>
                        <small><i class="fa fa-calendar-o">&nbsp;</i>Enrolled {{ $resource->created }}</small>
                    </div>
                </div>

                @if ( $resource->excerpt )
                    {!! $resource->excerpt !!}
                @endif
            </div>

            <div class="card-footer">
                <div class="row col-md-12">
                    <span class="pull-right grey-text percentage-text"><span class="percentage">{{ $resource->percentage or '5' }}</span>% Complete</span>
                    <div class="progress progress-xs">
                        <div class="progress-bar progress-bar-primary progress-bar-striped progress-bar-animated" role="progressbar" aria-valuenow="{{ $resource->percentage }}" aria-valuemin="0" aria-valuemax="100" style="width: {{ $resource->percentage or '5' }}%">
                            <span class="sr-only"><span class="percentage">{{ $resource->percentage or '5' }}%</span> Complete</span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card-action align-right">
                @allow('show-course')
                    <a href="{{ route('courses.show', $resource->code) }}" class="btn btn-primary waves-effect waves-light">View</a>
                    <a href="{{ url($resource->lastlink) }}" class="btn waves-effect waves-light btn-yellow m-r-2"><i class="fa fa-play font-14">&nbsp;</i>Resume</a>
                @endallow


                @allow('edit-course')
                    <a href="{{ route('courses.edit', $resource->id) }}" class="btn btn-secondary waves-effect waves-light">Edit</a>
                @endallow

                @allow('trash-course')
                    <a href="{{ route('courses.trash', $resource->id) }}" class="waves-effect waves-light text-right">Trash</a>
                @endallow
            </div>
        </div>
    </div>
</div>
@endif

@push('css')
    <style>
        .percentage-text {
            font-size: 14px;
        }
        .percentage {
            font-size: 25px;
            color: #000;
        }
    </style>
@endpush