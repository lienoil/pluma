@extends("Yggdrasil::layouts.course")

@if (isset($resource->package))
    @section("title", $resource->package->name)
@endif

@section("course-content")

    @if (isset($resource->package))
        <div class="card">
            <div class="card-header box-header with-border">
                <h3 class="card-title">{{ $resource->contentable->title }} | <em>{{ $resource->package->name }}</em></h3>
            </div>
            <div class="card-content">
                @enrolled($resource->contentable)
                    @if ( $resource->package->type == get_class(new \Form\Models\Form) )
                        {!! $resource->package->form !!}
                    @else
                        {{-- <p>Package ID: {{ $resource->package->id }}</p>
                        <p>Resource/Content ID: {{ $resource->id }}</p>
                        <p>Course ID: {{ $resource->contentable->id }}</p>
                        <p>User ID: {{ auth()->user()->id }}</p>
                        {{ $resource->package->interactive }} --}}

                        <iframe id="interactive" src="{{ $resource->package->interactive }}" style="width:100%; height:600px;" frameborder="0"></iframe>

                        {{-- @if ($resource->variables)
                            <p><strong>Status:</strong> {{ $resource->variables()->status() }}</p>
                        @endif --}}

                        @if ( $resource->package->description )
                            <div class="m-t-3 card-action">
                                <p><strong>Description</strong></p>
                                <div class="m-t-2">
                                    {!! $resource->package->description !!}
                                </div>
                            </div>
                        @endif

                    @endif
                @else

                    <div class="placeholder-frame bg-light">
                        <div class="placeholder-frame-content">
                            <p class="placeholder-frame-title grey-text text-center p-t-1"><i class="fa fa-lock">&nbsp;</i>This content is locked</p>
                        </div>
                    </div>

                @endenrolled
            </div>
        </div>

        @include("Yggdrasil::widgets.course-contents", ['contentable' => $resource->contentable])





    @endif

@endsection

@push('css')
    <style>
        #form1 {
            display : none;
        }
        button {
            margin-bottom: 10px;
        }
    </style>
@endpush

@push('js')
    <script src="{{ assets('Yggdrasil/js/Wrappers/SCORM/scorm-api.wrapper.js') }}"></script>
    <script>
        window.API.apiLogLevel = 4 //Error only
        // var simplifiedObject = JSON.parse(JSON.stringify(window.API.cmi));
        window.API.on('LMSInitialize', function() {
            $.ajax({
                url: '{{ route('api.variables.scorm.initialize') }}',
                method: 'POST',
                data: {_token: "{{ csrf_token() }}", content: "{{ $resource->id }}", user: "{{ auth()->user()->id }}", course_id: "{{ $resource->contentable->id }}", course: "{{ $resource->contentable->id }}" },
                success: function (data) {
                    console.info("[LMSInitialize]", data);
                }
            });
        });
        window.API.on('LMSFinish', function() {
            // window.API.LMSGetValue("");

            $.ajax({
                url: '{{ route('api.variables.scorm.finish') }}',
                method: 'POST',
                data: {_token: "{{ csrf_token() }}", content: "{{ $resource->id }}", user: "{{ auth()->user()->id }}", course: "{{ $resource->contentable->id }}" },
                success: function (data) {
                    console.info("[LMSFinish]", data);
                }
            });

            return "true";
        });
        window.API.on("LMSGetValue", function (cmiElement) {
            // console.info(cmiElement);
            var ret = null;
            $.ajax({
                url: '{{ route('api.variables.scorm.get-value') }}',
                method: 'POST',
                data: {_token: "{{ csrf_token() }}", content: "{{ $resource->id }}", user: "{{ auth()->user()->id }}", course: "{{ $resource->contentable->id }}", data: cmiElement },
                async: false,
                success: function (data) {
                    console.info("[LMSGetValue]", cmiElement, " - ", data);

                    ret = data;
                }
            });

            return ret;
        });

        window.API.on("LMSSetValue", function (cmiElement, value) {
            // console.info(cmiElement);
            setTimeout(function () {
                $.ajax({
                    url: '{{ route('api.variables.scorm.set-value') }}',
                    method: 'POST',
                    data: {_token: "{{ csrf_token() }}", content: "{{ $resource->id }}", user: "{{ auth()->user()->id }}", course: "{{ $resource->contentable->id }}", name: cmiElement, value: value },
                    success: function (data) {
                        console.info("[LMSSetValue]", cmiElement, " - ", data);
                    }
                });
            }, 1000);

            return "true";
        });

        window.API.on("LMSCommit", function () {
            window.API.LMSGetValue("");

            return "true";
        })
    </script>

    {{-- <script src="{{ assets("Yggdrasil/js/scorm-1.2-api.js") }}"></script>
    <script>
        initAPI({
            initialize: {
                id: "{{ $id }}",
                student_id: "{{ auth()->user()->id }}",
                method: "GET",
                _token: "{{ csrf_token() }}",
                url: "/api/courses/initialize",
            },
            id: "{{ $id }}", url: "/api/courses/save-status", method: "POST", _token: "{{ csrf_token() }}",
            debug: true,
        });
    </script> --}}
    {{-- <script src="{{ assets("Yggdrasil/js/Controllers/Captivate/CaptivateController.js") }}"></script> --}}
@endpush