<div class="box no-border">
    <div class="box-header with-border">
        <h3 class="box-title">Finished Courses</h3>
        <div class="box-tools pull-right">
            <a type="a" class="box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
            </a>
            <a type="a" class="box-tool" data-widget="remove"><i class="fa fa-times"></i></a>
        </div>
    </div>
    <div class="box-body">
        <ul class="products-list product-list-in-box">
            <li class="item">
                <div class="product-img img-circle">
                    <img src="http://placehold.it/350x150" alt="Image">
                </div>
                <div class="product-info">
                    <h6>Web Design and Development</h6>
                </div>
            </li>

            <li class="item">
                <div class="product-img img-circle">
                    <img src="http://placehold.it/350x150" alt="Image">
                </div>
                <div class="product-info">
                    <h6>Web Design and Development</h6>
                </div>
            </li>

            <li class="item">
                <div class="product-img img-circle">
                    <img src="http://placehold.it/350x150" alt="Image">
                </div>
                <div class="product-info">
                    <h6>Web Design and Development</h6>
                </div>
            </li>
        </ul>
    </div>
    <div class="card-footer text-center">
        <a href="javascript:void(0)">Show more <span><i class="fa fa-angle-double-down" aria-hidden="true"></i></span></a>
    </div>
</div>