@extends("Yggdrasil::layouts.course")

@section("course-content")

    @if ( $resource->viewable )
        <div class="box no-border">
            <div class="box-header with-border">
                <h3 class="box-title">{{ $resource->name }}</h3>
            </div>
            <div class="box-body">
                @if ( $resource->type == get_class(new \Form\Models\Form) )
                    {!! $resource->form !!}
                @else
                    {{-- <embed src="{{ $resource->interactive }}" style="width:100%; height:420px;"> --}}
                    <iframe src="{{ $resource->interactive }}?wmode=transparent" wmode="Opaque" name="course" style="position:relative;z-index:1;width:100%; height:670px;" frameborder="0"></iframe>
                @endif
            </div>
        </div>
    @else
        <div class="container-fluid">
            <div class="col-md-12">

                <div class="card">
                    <div class="card-block min-height-200">
                        <h3 class="text-muted text-center p-t-3">This course is locked</h3>
                    </div>
                </div>

            </div>
        </div>
    @endif

@endsection

@push('css')
    <style>
        .min-height-200 {
            min-height: 200px;
        }
    </style>
    <script src="{{ assets("Yggdrasil/js/scorm-1.2-api.js") }}"></script>
@endpush