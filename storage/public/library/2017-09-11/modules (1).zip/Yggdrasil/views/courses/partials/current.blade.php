<div class="row">
    <div class="m-t-2 col-sm-4 col-sm-12">
        <p class="text-center grey-text">You are currently enrolled in {{ $widgets['courses']['current']->count() }} {{ $widgets['courses']['current']->count() > 1 ? 'courses' : 'course' }}</p>
    </div>
    @if ( ! $widgets['courses']['current']->isEmpty() )
        @foreach ( $widgets['courses']['current'] as $i => $resource )
            <div class="item m-t-2 col-sm-4 col-sm-12">
                @include("Yggdrasil::courses.partials.widget-current", ['with_header' => false])
            </div>
        @endforeach
    @endif
</div>