<a class="waves-effect waves-yellow btn btn-default" href="#toc"><i class="fa fa-th-list">&nbsp;</i>Table of Contents</a>

<div id="toc" class="modal bottom-sheet">
    <div class="modal-content">
        <ul class="collapsible popout" data-collapsible="expandable">
            @foreach( $contents as $content )
            <li>
                <div class="collapsible-header {{ $id == $content->id ? 'active' : '' }}"><i class="fa fa-unlock" style="color: #6d6d6d;" aria-hidden="true"></i>Intro</div>
                <div class="collapsible-body bg-light">
                    <ul class="collection">
                        <li>
                            <a class="collection-item avatar" href="{{ route('contents.show', [$course->slug, $content->id]) }}" class="list-group-item {{ $id == $content->id ? 'active' : '' }}">
                                <span class="circle"><i class="fa fa-check-circle" style="font-size: 42px; color: #00a65a;"aria-hidden="true"></i></span>
                                <p class="title text-dark">{{ $content->content->name }}</p>
                                <p class="text-dark">{{ $content->content->description }}</p>
                                <div class="secondary-content"><i class="material-icons">100%</i></div>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            @endforeach
        </ul>
    </div>
</div>

@push('js')
    <script>
        $(document).ready(function(){
            $('.modal').modal();
        });
    </script>
@endpush