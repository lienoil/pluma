<div class="row">
    <div class="m-t-2 col-sm-4 col-sm-12">
        @if ( $widgets['courses']['bookmarked']->isEmpty() )
            <h6 class="grey-text text-center text-xs-center center-align">You have no bookmarked courses</h6>
        @else
            <h5 class="grey-text">Your previously finished courses</h5>
        @endif
    </div>
    @foreach ( $widgets['courses']['bookmarked'] as $i => $resource )
        <div class="item m-t-2 col-sm-4 col-sm-12">
            <div class="box no-border">
                <div class="box-body p-0">
                    <div class="card horizontal no-shadow m-b-0">
                        <div class="card-image card-image-left card-box">
                            <img src="{{ $resource->img }}">
                        </div>
                        <div class="card-stacked">
                            <div class="card-content">
                                <span class="card-title uppercase text-dark"><strong><a href="{{ route('courses.show', $resource->slug) }}">{{ $resource->title }}</a></strong></span>

                                @if ( $resource->excerpt )
                                    <p>{{ $resource->excerpt }}</p>
                                @endif

                            </div>

                            <div class="card-action no-border align-left">
                                @allow('show-enrollees')
                                    <a href="{{ route('enrollees.create') }}" class="waves-effect waves-light">Enroll</a>
                                @endallow

                                @allow('show-course')
                                    <a href="{{ route('courses.show', $resource->slug) }}" class="waves-effect waves-light">View</a>
                                @endallow

                                @allow('edit-course')
                                    <a href="{{ route('courses.edit', $resource->id) }}" class="waves-effect waves-light">Edit</a>
                                @endallow

                                @allow('trash-course')
                                    <a href="{{ route('courses.trash', $resource->id) }}" class="waves-effect waves-light">Trash</a>
                                @endallow
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    @endforeach
</div>