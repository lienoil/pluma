@extends("Pluma::layouts.admin")

@section("title", $resource->title)

@section("content")

    <div class="container-fluid">
        <div class="row">
            <div class="col-md-9">
                @include("Yggdrasil::widgets.courses.course")
                @include("Yggdrasil::widgets.course-contents", ['contentable' => $resource])
                {{-- @include("Comment::index") --}}
                @include("Yggdrasil::widgets.comments")
                @include("Yggdrasil::courses.partials.recommended_single")
            </div>
            <div class="col-md-3">
                @role('trainer')
                <div class="card">
                    <div class="box-header with-border">
                        <h3 class="card-title">Course Information</h3>
                    </div>
                    <div class="card-content text-center">
                        <div class="m-b-2 text-center a-s">
                            <img class="tasks" src="{{ theme('src/images/avatar-student.png') }}" width="100%">
                        </div>
                        <p><em>{{ $resource->students->count() }} student(s) currently enrolled in this course.</em></p>
                        <ul class="p-l-2">
                            @foreach ($resource->students as $student)
                                <li><a href="{{ route('profiles.show', $student->handlename) }}">{{ $student->fullname }}</a></li>
                            @endforeach
                        </ul>
                    </div>
                </div>
                @endrole
            </div>
        </div>
    </div>
@endsection

@push('css')
    <style>
        .a-s img {
            max-width: 100px;
        }
        .tasks {
            /*opacity: 0.4;*/
            filter: grayscale(100%);
        }
    </style>
@endpush