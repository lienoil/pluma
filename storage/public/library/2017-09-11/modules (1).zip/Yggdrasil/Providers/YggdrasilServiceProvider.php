<?php

namespace Yggdrasil\Providers;

use Schema;
use Illuminate\Support\ServiceProvider;

/**
 * YggdrasilServiceProvider
 * The service provider for the modules. After being registered
 * it will make sure that each of the modules are properly loaded
 * i.e. with their routes, views etc.
 *
 * @author John Lioneil Dionisio <john.dionisio1@gmail.com>
 * @package Pluma
 */
class YggdrasilServiceProvider extends ServiceProvider
{
    /**
     * Will make sure that the required modules have been fully loaded
     *
     * @return void
     */
    public function boot()
    {
        //
    }

    /**
     * Register the application services.
     *
     * @return void
     */
    public function register()
    {
        $this->app->register("Yggdrasil\Providers\LibraryServiceProvider");
        $this->app->register("Yggdrasil\Providers\AssignmentServiceProvider");
    }
}