<?php

namespace Yggdrasil\Providers;

use Schema;
use Yggdrasil\Models\Course;
use Yggdrasil\Observers\CourseObserver;
use Yggdrasil\Models\Content;
use Yggdrasil\Observers\ContentObserver;
use Yggdrasil\Models\Package;
use Yggdrasil\Observers\PackageObserver;
use Illuminate\Support\ServiceProvider;

/**
 * CourseServiceProvider
 * The service provider for the modules. After being registered
 * it will make sure that each of the modules are properly loaded
 * i.e. with their routes, views etc.
 *
 * @author John Lioneil Dionisio <john.dionisio1@gmail.com>
 * @package Pluma
 */
class LibraryServiceProvider extends ServiceProvider
{
    /**
     * Will make sure that the required modules have been fully loaded
     *
     * @return void
     */
    public function boot()
    {
        $this->observe();
    }

    /**
     * Register the application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Observable Models
     *
     * @return void
     */
    public function observe()
    {
        if ( Schema::hasTable('courses') ) {
            Course::observe( CourseObserver::class );
        }

        if ( Schema::hasTable('libraries') ) {
            Package::observe( PackageObserver::class );
        }
    }
}