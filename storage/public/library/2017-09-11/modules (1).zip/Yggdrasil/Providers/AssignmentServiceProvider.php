<?php

namespace Yggdrasil\Providers;

use Illuminate\Support\ServiceProvider;
use Schema;
use Yggdrasil\Models\Assignment;
use Yggdrasil\Observers\AssignmentObserver;

/**
 * The service provider for the modules. After being registered
 * it will make sure that each of the modules are properly loaded
 * i.e. with their routes, views etc.
 *
 * @author John Lioneil Dionisio <john.dionisio1@gmail.com>
 * @package Yggdrasil\Course
 */
class AssignmentServiceProvider extends ServiceProvider
{
    /**
     * Will make sure that the required modules have been fully loaded
     *
     * @return void
     */
    public function boot()
    {
        $this->observe();
    }

    /**
     * Register the application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Observable Models
     *
     * @return void
     */
    public function observe()
    {
        if (Schema::hasTable('assignments')) {
            Assignment::observe(AssignmentObserver::class);
        }
    }
}
