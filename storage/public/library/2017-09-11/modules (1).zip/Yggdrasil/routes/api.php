<?php
/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::group(['prefix' => 'api', 'middleware' => ['api']], function () {
    Route::get('courses/initialize', '\Yggdrasil\Controllers\API\CourseController@initialize')->name('api.courses.initialize');
    Route::post('courses/save-status', '\Yggdrasil\Controllers\API\CourseController@saveStatus')->name('api.courses.save-status');

    Route::post('variables/scorm/initialize', '\Yggdrasil\Controllers\Variable\API\SCORMController@initialize')->name('api.variables.scorm.initialize');
    Route::post('variables/scorm/finish', '\Yggdrasil\Controllers\Variable\API\SCORMController@finish')->name('api.variables.scorm.finish');
    Route::post('variables/scorm/get-value', '\Yggdrasil\Controllers\Variable\API\SCORMController@getValue')->name('api.variables.scorm.get-value');
    Route::post('variables/scorm/set-value', '\Yggdrasil\Controllers\Variable\API\SCORMController@setValue')->name('api.variables.scorm.set-value');
    Route::post('variables/scorm/commit', '\Yggdrasil\Controllers\Variable\API\SCORMController@commit')->name('api.variables.scorm.commit');
});

// Route::any('{.*}', 'Pluma\Controllers\AdminController@page');