<?php

Route::get('~packages/{name?}', function ($name = null) {
    $path = storage_path("/app/packages/".$name);
    $name_array = explode('/', $name);
    $last_file = end($name_array);
    $extension = explode(".", $last_file);
    $extension = end($extension);

    $is_css = $extension == 'css' ? true : false;

    if (\File::exists($path)) {
        return response()->file($path, $is_css ? array('Content-Type' => 'text/css') : []);
    }

    return response()->json([], 404);
})->where('name', '.*');