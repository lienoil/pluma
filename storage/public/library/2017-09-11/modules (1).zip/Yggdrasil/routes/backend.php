<?php
/*
|--------------------------------------------------------------------------
| Backend Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::group(['prefix' => config("modules.backend.prefix"), 'middleware' => ['web']], function () {
// 	$modules = \File::directories(__DIR__.'/../submodules');
// 	foreach ( $modules as $module ) {
// 		$module = basename( $module );
// 		if ( file_exists( __DIR__ . "/../submodules/$module/routes/admin.php") ) {
// 			include_once __DIR__ . "/../submodules/$module/routes/admin.php";
// 		}
// 	}
// });