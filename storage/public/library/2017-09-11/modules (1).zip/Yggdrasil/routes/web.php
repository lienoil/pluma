<?php
//
Route::get('packages/{name?}', function ($name = null) {
    dd('asd');
})->where('name', '.*');