<?php
/**
 * ---------------------------------------------------
 * Dashboard
 * ---------------------------------------------------
 * Custom dashboard, overrides Pluma's and any other
 * previous dashboard.
 * Make sure to put Yggdrasil at the bottom of enabled
 * modules in <root>/config/modules.php, inside
 * 'enabled' array.
 */
Route::get('dashboard', '\Yggdrasil\Controllers\Dashboard\DashboardController@index')->name('dashboard.index');

/**
 * ---------------------------------------------------
 * Course Route
 * ---------------------------------------------------
 * The main courses routes in /admin.
 */
/**
 * ---------------------------------------------------
 * Content Route
 * ---------------------------------------------------
 *
 */
Route::post('contents/explorer', '\Yggdrasil\Controllers\Content\ExplorerController@showExplorerForm')->name('content.explorer');
Route::resource('courses/contents', '\Yggdrasil\Controllers\Content\ContentController');

/**
 * ---------------------------------------------------
 * Category Route
 * ---------------------------------------------------
 *
 */
Route::get('courses/categories/trash', 'Pluma\Controllers\Category\CategoryController@trash')->name('categories.trash');
Route::post('courses/categories/{form}/restore', 'Pluma\Controllers\Category\CategoryController@restore')->name('categories.restore');
Route::delete('courses/categories/{form}/delete', 'Pluma\Controllers\Category\CategoryController@delete')->name('categories.delete');
Route::resource('courses/categories', 'Pluma\Controllers\Category\CategoryController');

/**
 * ---------------------------------------------------
 * Additional Course Route
 * ---------------------------------------------------
 *
 */
Route::get('courses/previous', '\Yggdrasil\Controllers\Course\PreviousCourseController@previous')->name('courses.previous');
Route::get('courses/register', '\Yggdrasil\Controllers\Course\PreviousCourseController@register')->name('courses.register');
Route::get('courses/progress', '\Yggdrasil\Controllers\Course\PreviousCourseController@progress')->name('courses.progress');
Route::get('courses/trash', '\Yggdrasil\Controllers\CourseController@trash')->name('courses.trash');
Route::post('courses/{course}/restore', '\Yggdrasil\Controllers\CourseController@restore')->name('courses.restore');
Route::resource('courses', '\Yggdrasil\Controllers\CourseController');
Route::delete('courses/{course}/delete', '\Yggdrasil\Controllers\CourseController@delete')->name('courses.delete');
Route::get('courses/{course}/{content?}', '\Yggdrasil\Controllers\Course\ContentController@show')->where('content', '.*')->name('contents.show');

/**
 * Package Route
 *
 */
Route::post('packages/explorer', '\Yggdrasil\Controllers\PackageController@explorer')->name('packages.explorer');
Route::get('packages/trash', '\Yggdrasil\Controllers\PackageController@trash')->name('packages.trash');
Route::post('packages/{package}/restore', '\Yggdrasil\Controllers\PackageController@restore')->name('packages.restore');
Route::get('packages/upload', '\Yggdrasil\Controllers\PackageController@create')->name('packages.create');
Route::post('packages/upload', '\Yggdrasil\Controllers\PackageController@upload')->name('packages.upload');
Route::delete('packages/{package}/delete', '\Yggdrasil\Controllers\PackageController@delete')->name('packages.delete');
Route::resource('packages', '\Yggdrasil\Controllers\PackageController', ['except' => 'create']);

/**
 * Enrollees
 *
 */
Route::resource('students', '\Yggdrasil\Controllers\Courses\StudentController');

/**
 * Ranking
 *
 */
Route::resource('ranking', '\Yggdrasil\Controllers\RankController');
Route::get('ranking/trash', '\Yggdrasil\Controllers\RankController@trash')->name('ranking.trash');

// Route::resource('courses/progress', '\Yggdrasil\Controllers\ProgressController');

/**
 * Settings / Profile
 *
 */
Route::get('settings/profile', 'Yggdrasil\Controllers\Settings\ProfileController@getProfileForm')->name('settings.form.profile');
Route::post('settings/profile', 'Yggdrasil\Controllers\Settings\ProfileController@profile')->name('settings.profile');

/**
 * ---------------------------------------------------
 * Assignment Route
 * ---------------------------------------------------
 *
 */
Route::resource('assignments', '\Yggdrasil\Controllers\Assignment\AssignmentController');
Route::get('assignments/trash', 'Yggdrasil\Controllers\Assignment\AssignmentController@trash')->name('assignments.trash');