<?php
/**
 * Course Route
 *
 */
Route::get('courses', '\Yggdrasil\Controllers\Front\CourseController@showCourseList');

Route::get('courses/{course}', '\Yggdrasil\Controllers\Front\CourseController@showSingleCourse')->name('public.course.show');

Route::get('courses/{course}/{content?}', '\Yggdrasil\Controllers\Front\CourseController@showSingleCourseContent')->where('content', '.*')->name('public.course.content.show');

// Includes
include __DIR__ . '/assets.php';