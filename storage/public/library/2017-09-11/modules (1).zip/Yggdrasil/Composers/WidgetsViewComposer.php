<?php

namespace Yggdrasil\Composers;

use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Request;
use Illuminate\Support\Facades\Route;
use Illuminate\View\View;
use Yggdrasil\Models\Course;
use Yggdrasil\Models\Student;

/**
 * -----------------------------------
 * Category View Composer
 * -----------------------------------
 * The view composer for dynamic headings, subheading, and other content on page.
 *
 * @author John Lioneil Dionisio <john.dionisio1@gmail.com>
 */
class WidgetsViewComposer
{
    /**
     * Some of the widgets to load on dashboard
     * and other Yggdrasil views.
     *
     * @var null
     */
    protected $previousCourses = null;
    protected $currentCourses = null;
    protected $bookmarkedCourses = null;
    protected $recommendedCourses = null;

    /**
     * Main function to tie everything together.
     *
     * @param  View   $view
     * @return void
     */
    public function compose(View $view)
    {
        $view->with('widgets', $this->handle());
    }

    public function handle()
    {
        $this->setPreviousCourses();
        $this->setCurrentCourses();
        $this->setBookmarkedCourses();
        $this->setRecommendedCourses();

        return collect([
            'courses' => [
                'previous' => $this->getPreviousCourses(),
                'current' => $this->getCurrentCourses(),
                'bookmarked' => $this->getBookmarkedCourses(),
                'recommended' => $this->getRecommendedCourses(),
            ],
        ]);
    }

    public function setPreviousCourses()
    {
        $this->previousCourses = Student::whereId(auth()->user()->id)->first()
            ->courses()->where('percentage', '>=', 100)
            ->get();
    }

    public function setCurrentCourses()
    {
        $student = Student::whereId(auth()->user()->id)->first();
        $this->currentCourses = $student->courses;
            // ->where('percentage', '<', 100)->orWhere('percentage', NULL)
            // ->get();
    }

    public function setBookmarkedCourses()
    {
        $this->bookmarkedCourses = Course::whereId('-1')->get();
    }

    public function setRecommendedCourses()
    {
        $this->recommendedCourses = Course::whereId('-1')->get();
    }

    public function getPreviousCourses()
    {
        return $this->previousCourses;
    }

    public function getCurrentCourses()
    {
        return $this->currentCourses;
    }

    public function getBookmarkedCourses()
    {
        return $this->bookmarkedCourses;
    }

    public function getRecommendedCourses()
    {
        return $this->recommendedCourses;
    }
}