<?php

namespace Yggdrasil\Support\Traits\Course;

use Yggdrasil\Models\Variable;

trait HasManyVariables
{

    public function variables()
    {
        return $this->hasMany(Variable::class);
    }
}
