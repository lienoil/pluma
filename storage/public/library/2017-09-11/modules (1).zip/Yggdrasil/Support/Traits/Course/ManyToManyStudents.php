<?php

namespace Yggdrasil\Support\Traits\Course;

use Yggdrasil\Models\Student;

trait ManyToManyStudents
{
    public function students()
    {
        return $this->belongsToMany(Student::class)->withPivot('percentage', 'viewed');;
    }

    public function getPercentageAttribute()
    {
        $student = $this->students()->whereStudentId(auth()->user()->id)->first();
        return $student->pivot->percentage;
    }

    public function isViewable()
    {
        return auth()->user()->isRoot() || $this->students->contains(auth()->user()->id);
    }

    public function isEnrolled()
    {
        return auth()->user()->isRoot() || $this->students->contains(auth()->user()->id);
    }
}
