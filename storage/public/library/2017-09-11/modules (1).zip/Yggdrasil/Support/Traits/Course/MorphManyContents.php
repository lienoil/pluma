<?php

namespace Yggdrasil\Support\Traits\Course;

use Pluma\Models\User;
use Yggdrasil\Models\Content;
use Yggdrasil\Models\Course;

trait MorphManyContents
{
    /**
     * The polymorphic column name to use.
     *
     * @var string
     */
    protected $polymorphicKeyword = 'contentable';

    /**
     * Gets the morphing model.
     *
     * @return Illuminate\Database\Eloquent\Model
     */
    public function contents()
    {
        return $this->morphMany(Content::class, $this->polymorphicKeyword);
    }
}
