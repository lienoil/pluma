<?php

namespace Yggdrasil\Support\Traits\Course;

trait MorphToContent
{
    /**
     * Get all of the owning commentable models.
     *
     * @return Illuminate\Database\Eloquent\Model
     */
    public function contentable()
    {
        return $this->morphTo();
    }
}
