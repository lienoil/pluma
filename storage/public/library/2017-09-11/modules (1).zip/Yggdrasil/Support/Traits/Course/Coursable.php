<?php

namespace Yggdrasil\Support\Traits\Course;

use Yggdrasil\Models\Course;
use Pluma\Models\User;

trait Coursable
{

    public function courses()
    {
        return $this->morphToMany( Course::class, 'coursable' );
    }

    public function course()
    {
        return $this->belongsTo( Course::class );
    }

    public function user()
    {
        return $this->belongsToMany( User::class )->select('*');
    }

    public function getIsLockedAttribute()
    {
        return 0;
        // return auth()->user()->viewed;
    }
}