<?php

namespace Yggdrasil\Support\Traits\Course;

use Yggdrasil\Models\Package;

trait BelongsToPackage
{

    /**
     * Gets the package that owns this model.
     *
     * @return Illuminate\Database\Eloquent\Model
     */
    public function package()
    {
        return $this->belongsTo(Package::class);
    }
}
