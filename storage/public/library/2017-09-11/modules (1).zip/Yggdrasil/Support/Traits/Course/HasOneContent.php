<?php

namespace Yggdrasil\Support\Traits\Course;

use Yggdrasil\Models\Content;

trait HasOneContent
{
    /**
     * Get the course that owns the content.
     *
     * @return Illuminate\Database\Eloquent\Model
     */
    public function content()
    {
        return $this->hasOne(Content::class);
    }
}
