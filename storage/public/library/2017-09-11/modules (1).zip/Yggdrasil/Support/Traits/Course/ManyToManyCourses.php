<?php

namespace Yggdrasil\Support\Traits\Course;

use Yggdrasil\Models\Course;

trait ManyToManyCourses
{
    /**
     * The courses that belong to the model.
     *
     */
    public function courses()
    {
        return $this->belongsToMany(Course::class);
    }
}
