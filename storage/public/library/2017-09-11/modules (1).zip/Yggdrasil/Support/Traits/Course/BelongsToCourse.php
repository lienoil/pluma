<?php

namespace Yggdrasil\Support\Traits\Course;

use Yggdrasil\Models\Course;

trait BelongsToCourse
{
    /**
     * Get the course that owns the content.
     *
     * @return Illuminate\Database\Eloquent\Model
     */
    public function course()
    {
        return $this->belongsTo(Course::class);
    }
}
