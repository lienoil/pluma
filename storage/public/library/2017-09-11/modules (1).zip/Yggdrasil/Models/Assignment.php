<?php

namespace Yggdrasil\Models;

use Illuminate\Database\Eloquent\SoftDeletes;
use Pluma\Models\Model;
use Yggdrasil\Support\Traits\Course\BelongsToContent;

class Assignment extends Model
{
    use SoftDeletes, BelongsToContent;
}
