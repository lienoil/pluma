<?php

namespace Yggdrasil\Models;

use File;
use Form\Models\Form;
use Illuminate\Database\Eloquent\SoftDeletes;
use Pluma\Models\Model;
use Pluma\Support\Traits\HasManyCategories;
use Pluma\Support\Traits\Ownable;
use Storage;
use Yggdrasil\Models\Content;
use Yggdrasil\Models\Package;
use Yggdrasil\Support\Traits\Course\ManyToManyStudents;
use Yggdrasil\Support\Traits\Course\MorphManyContents;

class Course extends Model
{
    use HasManyCategories, ManyToManyStudents, MorphManyContents, Ownable, SoftDeletes;

    /**
     * Array of attachable related models.
     *
     * @var array
     */
    public $with = ['contents'];

    public function getLastlinkAttribute()
    {
        // TODO: last link
        $contents = $this->contents;
        return route('contents.show', $this->code);
    }
}
