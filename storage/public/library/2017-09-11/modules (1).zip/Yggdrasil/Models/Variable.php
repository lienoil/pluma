<?php

namespace Yggdrasil\Models;

use Pluma\Models\Model;

class Variable extends Model
{
    protected $lessonStatus = 'cmi.core.lesson_status';

    public function scopeStatus()
    {
        $status = $this->where('name', $this->lessonStatus)->first();

        return ucfirst($status->value);
    }
}
