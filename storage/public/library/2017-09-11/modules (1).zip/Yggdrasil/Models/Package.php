<?php

namespace Yggdrasil\Models;

use File;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Http\Response;
use Pluma\Models\Library;
use Pluma\Support\Traits\Library\MorphManyLibraries;
use SimpleXMLElement;
use Yggdrasil\Models\Courses\Variable;
use Yggdrasil\Support\Traits\Course\HasOneContent;
use Yggdrasil\Support\Traits\Course\MorphManyContents;

class Package extends Library
{
    use HasOneContent, MorphManyContents, SoftDeletes;

    protected $table = 'libraries';

    public function getThumbnailAttribute()
    {
        $file = "$this->name/thumbnail.png";

        if (!File::exists(storage_path("app/packages/$file"))) {
            $error_thumb = 'errors/blank.png';
            $this->warning = "This package is missing the thumbnail.png";

            return asset("storage/$error_thumb");
        }

        return url("~packages/$file");
    }

    /**
     * Get all of the models from the database.
     *
     * @param  array|mixed  $columns
     * @return \Illuminate\Database\Eloquent\Collection|static[]
     */
    public static function all($columns = ['*'])
    {
        $columns = is_array($columns) ? $columns : func_get_args();

        $instance = new static;

        return $instance->where('type', get_class(new Package))->newQuery()->get($columns);
    }

    public static function pluck($name, $id)
    {
        $instance = new static;

        return $instance->where('type', 'Yggdrasil\Models\Package::class')->newQuery()->pluck($name, $id);
    }

    public function getInteractiveAttribute()
    {
        $file = pathinfo(storage_path($this->url));
        $file = $file['dirname']."/$this->name";

        $xml = File::get("$file/imsmanifest.xml");
        $xml = new SimpleXMLElement($xml);
        // dd($xml);
        $startpoint = isset($xml->resources->resource['href']) ? $xml->resources->resource['href'] : 'index.html';

        return url("~packages/$this->name/$startpoint");
    }
}
