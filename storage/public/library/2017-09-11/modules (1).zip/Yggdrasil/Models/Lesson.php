<?php

namespace Yggdrasil\Models;

use Pluma\Models\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Yggdrasil\Support\Traits\Coursable;

class Lesson extends Model
{
    use SoftDeletes, Coursable;
}