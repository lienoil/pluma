<?php

namespace Yggdrasil\Models;

use Pluma\Models\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Rank extends Model
{
    use SoftDeletes;
}