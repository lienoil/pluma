<?php

namespace Yggdrasil\Models;

use File;
use Pluma\Models\Model;
use Pluma\Support\Traits\Library\MorphManyLibraries;
use Yggdrasil\Models\Course;
use Yggdrasil\Support\Traits\Course\BelongsToPackage;
use Yggdrasil\Support\Traits\Course\HasManyVariables;
use Yggdrasil\Support\Traits\Course\MorphToContent;

class Content extends Model
{
    use BelongsToPackage, MorphToContent, HasManyVariables;

    /**
     * Checks if the content is viewable by user.
     *
     * @return boolean
     */
    public function isViewable()
    {
        if (auth()->user()->isRoot()) return true;

        if (null === auth()->user()->id) return false;

        if (null === $this->users) return false;

        return $this->users->contains(auth()->user()->id);
    }
}
