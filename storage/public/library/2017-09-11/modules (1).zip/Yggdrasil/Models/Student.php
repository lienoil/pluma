<?php

namespace Yggdrasil\Models;

use Pluma\Models\User;
use Yggdrasil\Support\Traits\Course\ManyToManyCourses;

/**
 * Enrollee Model is an
 * extended Pluma\Models\User Model
 *
 */
class Student extends User
{
    use ManyToManyCourses;

    protected $table = 'users';

    public $with = ['courses'];
}
