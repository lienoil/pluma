<?php

namespace Yggdrasil\Models;

use Pluma\Models\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Quiz extends Model
{
    use SoftDeletes;

    // public function courses()
    // {
    //     return $this->morphedByMany(Course::class, 'quizzable');
    // }

    // public function packages()
    // {
    //     return $this->morphedByMany(Package::class, 'quizzable');
    }
}