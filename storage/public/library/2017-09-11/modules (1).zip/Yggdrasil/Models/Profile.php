<?php

namespace Yggdrasil\Models;

use Pluma\Models\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Profile extends Model
{
    use SoftDeletes;
}