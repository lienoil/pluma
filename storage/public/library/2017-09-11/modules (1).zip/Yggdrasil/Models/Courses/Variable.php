<?php

namespace Yggdrasil\Models\Courses;

use Pluma\Models\Model;
use Pluma\Support\Traits\BelongsToUser;
use Yggdrasil\Support\Traits\Course\BelongsToCourse;
use Yggdrasil\Support\Traits\Course\BelongsToContent;

class Variable extends Model
{
    use BelongsToCourse, BelongsToUser, BelongsToContent;
}
