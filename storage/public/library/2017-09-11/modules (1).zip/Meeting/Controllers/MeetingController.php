<?php
namespace Meeting\Controllers;

use Meeting\Models\Meeting;
use Illuminate\Http\Request;
use Meeting\Requests\MeetingRequest;
use Pluma\Controllers\AdminController as Controller;

class MeetingController extends Controller
{

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $resources = Meeting::filter()->paginate(config("settings.pagination_count", $this->pagination_count));
        $trashed = Meeting::onlyTrashed();
        $filtered = count ( $request->all() ) ? true : false;

        return view('Meeting::index')->with(compact('resources', 'trashed', 'filtered'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        return view("Meeting::create");
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(MeetingRequest $request)
    {
        $meeting = new Meeting();
        $meeting->title = $request->input('title');
        $meeting->slug = $request->input('slug');
        $meeting->body = $request->input('body');
        if ( null !== $request->input('schedule') ) {
            $meeting->schedule = date ('Y-m-d H:i:s', strtotime($request->input('schedule')));
        }

        $meeting->save();

        return back();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $resource = Meeting::findOrFail($id);

        return view("Meeting::show")->with(compact('resource'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $resource = Meeting::findOrFail( $id );

        return view("Meeting::edit")->with(compact('resource'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $meeting = Meeting::findOrFail ( $id );
        $meeting->title = $request->input('title');
        $meeting->slug = $request->input('slug');
        $meeting->body = $request->input('body');
        if (null !== $request->input('schedule')) {
            $meeting->schedule = date('Y-m-d H:i:s', strtotime($request->input('schedule')));
        }
        $meeting->save();

        return back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $meeting = Meeting::findOrFail($id);
        $meeting->delete();

        return back();
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function trash()
    {
        $resources = Meeting::onlyTrashed()->paginate(config("settings.pagination_count", $this->pagination_count));

        return view("Meeting::trash")->with(compact('resources'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function restore($id)
    {
        $resource = Meeting::onlyTrashed()->findOrFail($id);
        $resource->restore();

        return back();
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function delete($id)
    {
        $meeting = Meeting::onlyTrashed()->findOrFail( $id );
        $meeting->forceDelete();

        return back();
    }
}