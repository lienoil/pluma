<?php

namespace Meeting\Providers;

use Illuminate\Support\ServiceProvider;
use Meeting\Console\Kernel;
use Pluma\Middleware\AuthenticateAdmin;
use Pluma\Middleware\CheckRole;
use Meeting\Models\Meeting;
use Meeting\Observers\MeetingObserver;
use Schema;

/**
 * PlumaServiceProvider
 * The service provider for the modules. After being registered
 * it will make sure that each of the modules are properly loaded
 * i.e. with their routes, views etc.
 *
 * @author John Lioneil Dionisio <john.dionisio1@gmail.com>
 * @package Pluma
 */
class MeetingServiceProvider extends ServiceProvider
{
	/**
	 * Will make sure that the required modules have been fully loaded
	 *
	 * @return void
	 */
	public function boot()
	{
		$this->observe();
	}

	/**
	 * Register the application services.
	 *
	 * @return void
	 */
	public function register()
	{
		// $console = new Kernel();
		// $this->commands( $console->commands );
	}

	/**
	 * Observable Models
	 *
	 * @return void
	 */
	public function observe()
	{
		if ( Schema::hasTable('meetings') ) {
			Meeting::observe( MeetingObserver::class );
		}
	}
}