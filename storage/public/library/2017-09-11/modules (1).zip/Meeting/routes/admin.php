<?php

/**
 * Meetings Routes
 *
 */
Route::get('meetings/trash', 'Meeting\Controllers\MeetingController@trash')->name('meetings.trash');
Route::post('meetings/{meeting}/restore', 'Meeting\Controllers\MeetingController@restore')->name('meetings.restore');
Route::delete('meetings/{meeting}/delete', 'Meeting\Controllers\MeetingController@delete')->name('meetings.delete');
Route::resource('meetings', '\Meeting\Controllers\MeetingController');

// Route::get('meetings/trash', 'Meeting\Controllers\MeetingController@trash')->name('meetings.trash');

