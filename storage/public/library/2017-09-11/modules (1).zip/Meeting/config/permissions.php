<?php


/*
 | --------------------------------------
 | Permissions Array
 | --------------------------------------
 |
 | Here we define our permissions that you can attach to roles.
 |
 | These permissions corresponds to a counterpart
 | route (found in <this module>/routes/<route-files>.php).
 | All permissionable routes should have a `name` (e.g. 'posts.store')
 | for the CheckRole to work.
 |
 | These routes must have the middleware 'roles' for this to work.
 */

return [
	/**
	 * Survey Permissions
	 *
	 */
	'view-meeting' => [
		'name' =>  'meetings.index',
		'slug' => 'view-meeting',
		'description' => 'View meetings',
	],
	'show-meeting' => [
		'name' => 'meetings.show',
		'slug' => 'show-meeting',
		'description' => 'Show a meeting',
	],
	'create-meeting' => [
		'name' => 'meetings.create',
		'slug' => 'create-meeting',
		'description' => 'Show the meeting',
	],
	'store-meeting' => [
		'name' => 'meetings.store',
		'slug' => 'store-meeting',
		'description' => 'Store the meeting',
	],
	'edit-meeting' => [
		'name' => 'meetings.edit',
		'slug' => 'edit-meeting',
		'description' => 'Edit the meeting',
	],
	'update-meeting' => [
		'name' => 'meetings.update',
		'slug' => 'update-meeting',
		'description' => 'Update the meeting',
	],
	'destroy-meeting' => [
		'name' =>  'meetings.destroy',
		'slug' => 'destroy-meeting',
		'description' => 'Destroy the meeting',
	],
	'trash-meeting' => [
		'name' =>  'meetings.trash',
		'slug' => 'trash-meeting',
		'description' => 'Trash the meeting',
	],
	'restore-meeting' => [
		'name' => 'meetings.restore',
		'slug' => 'restore-meeting',
		'description' => 'Restore the meeting',
	],

	/**
	 * Field Permission
	 *
	 */
	'view-field' => [
		'name' =>  'fields.index',
		'slug' => 'view-field',
		'description' => 'View fields',
	],
	'show-field' => [
		'name' => 'fields.show',
		'slug' => 'show-field',
		'description' => 'Show a field',
	],
	'create-field' => [
		'name' => 'fields.create',
		'slug' => 'create-field',
		'description' => 'Show the field',
	],
	'store-field' => [
		'name' => 'fields.store',
		'slug' => 'store-field',
		'description' => 'Store the field',
	],
	'edit-field' => [
		'name' => 'fields.edit',
		'slug' => 'edit-field',
		'description' => 'Edit the field',
	],
	'update-field' => [
		'name' => 'fields.update',
		'slug' => 'update-field',
		'description' => 'Update the field',
	],
	'destroy-field' => [
		'name' =>  'fields.destroy',
		'slug' => 'destroy-field',
		'description' => 'Destroy the field',
	],
	'trash-field' => [
		'name' =>  'fields.trash',
		'slug' => 'trash-field',
		'description' => 'Trash the field',
	],
	'restore-field' => [
		'name' => 'fields.restore',
		'slug' => 'restore-field',
		'description' => 'Restore the field',
	],

	/**
	 * Template Permission
	 *
	 */
	'view-template' => [
		'name' =>  'templates.index',
		'slug' => 'view-template',
		'description' => 'View templates',
	],
	'show-template' => [
		'name' => 'templates.show',
		'slug' => 'show-template',
		'description' => 'Show a template',
	],
	'create-template' => [
		'name' => 'templates.create',
		'slug' => 'create-template',
		'description' => 'Show the template',
	],
	'store-template' => [
		'name' => 'templates.store',
		'slug' => 'store-template',
		'description' => 'Store the template',
	],
	'edit-template' => [
		'name' => 'templates.edit',
		'slug' => 'edit-template',
		'description' => 'Edit the template',
	],
	'update-template' => [
		'name' => 'templates.update',
		'slug' => 'update-template',
		'description' => 'Update the template',
	],
	'destroy-template' => [
		'name' =>  'templates.destroy',
		'slug' => 'destroy-template',
		'description' => 'Destroy the template',
	],
	'trash-template' => [
		'name' =>  'templates.trash',
		'slug' => 'trash-template',
		'description' => 'Trash the template',
	],
	'restore-template' => [
		'name' => 'templates.restore',
		'slug' => 'restore-template',
		'description' => 'Restore the template',
	],
];