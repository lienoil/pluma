<?php

return [
	/**
	 * Meetings
	 *
	 */
	'meeting' => [
		'name' => 'meeting',
		'slug' => 'meetings',
		'parent' => true,
		// 'is_always_viewable' => true,
		'order' => 70,
		'icon' => [
			'class' => 'fa fa-whatsapp',
			'tag' => 'i',
			'content' => '&nbsp;',
		], // or can be a html string e.g. <span class="fa fa-edit">&nbsp;</span>
		'label' => [
			'singular_name' => 'Meeting',
			'plural_name' => 'Meeting',
		],
	],
	'view-meeting' => [
		'is_child_of' => 'meeting',
		'name' => 'view-meeting',
		'slug' => '/',
		// 'is_always_viewable' => true,
		// 'order' => 1,
		'label' => [
			'singular_name' => 'All Meeting',
			'plural_name' => 'All Meetings',
		],
	],
	'create-meeting' => [
		'is_child_of' => 'meeting',
		'name' => 'create-meeting',
		'slug' => 'create',
		// 'is_always_viewable' => true,
		// 'order' => 2,
		'label' => [
			'singular_name' => 'Create Meeting',
			'plural_name' => 'Create Meeting',
		],
	],

	/**
	 * Fields
	 *
	 */
	'view-field' => [
		'is_child_of' => 'meeting',
		'name' => 'view-field',
		'slug' => 'fields',
		// 'before' => '<hr>',
		'icon' => [
			'class' => 'fa fa-check-square-o',
			'tag' => 'i',
			'content' => '&nbsp;',
		],
		'label' => [
			'singular_name' => 'Field',
			'plural_name' => 'Fields',
		],
	],

	/**
	 * Templates
	 *
	 */
	'view-template' => [
		'is_child_of' => 'meeting',
		'name' => 'view-template',
		'slug' => 'templates',
		// 'before' => '<hr>',
		'icon' => [
			'class' => 'fa fa-file-text-o',
			'tag' => 'i',
			'content' => '&nbsp;',
		],
		'label' => [
			'singular_name' => 'Template',
			'plural_name' => 'Templates',
		],
	],

	/**
	 * Meeting Trash
	 */
	'trash-meeting' => [
		'is_child_of' => 'meeting',
		'name' => 'trash-meeting',
		'slug' => 'trash',
		// 'before' => '<hr>',
		// 'is_always_viewable' => true,
		// 'order' => 2,
		'icon' => [
			'class' => 'fa fa-trash',
			'tag' => 'i',
			'content' => '&nbsp;',
		],
		'label' => [
			'singular_name' => 'Trash',
			'plural_name' => 'Trash',
		],
	],
];