<?php

namespace Meeting\Observers;

use Meeting\Models\Meeting;
use Pluma\Models\Ownership;

class MeetingObserver
{
	/**
	 * Listen to the Meeting created event.
	 *
	 * @param  Meeting  $meeting
	 * @return void
	 */
	public function created(Meeting $meeting)
	{
		session()->flash('name', $meeting->name);
		session()->flash('icon', "fa fa-check");
		session()->flash('message', "Meeting successfully saved");
		session()->flash('type', 'info');
	}

	/**
	 * Listen to the Meeting updated event.
	 *
	 * @param  Meeting  $meeting
	 * @return void
	 */
	public function updated(Meeting $meeting)
	{
		session()->flash('name', $meeting->name);
		session()->flash('icon', "fa fa-check");
		session()->flash('message', "Meeting successfully updated");
		session()->flash('type', 'info');
	}

	/**
	 * Listen to the Meeting deleted event.
	 *
	 * @param  Meeting  $meeting
	 * @return void
	 */
	public function deleted(Meeting $meeting)
	{
		session()->flash('name', $meeting->name);
		session()->flash('icon', "fa fa-check");
		session()->flash('message', "Meeting successfully moved to trash");
		session()->flash('type', 'info');
	}

	/**
	 * Listen to the Meeting restored event.
	 *
	 * @param  Meeting  $meeting
	 * @return void
	 */
	public function restored(Meeting $meeting)
	{
		session()->flash('name', $meeting->name);
		session()->flash('icon', "fa fa-check");
		session()->flash('message', "Meeting successfully restored");
		session()->flash('type', 'info');
	}
}