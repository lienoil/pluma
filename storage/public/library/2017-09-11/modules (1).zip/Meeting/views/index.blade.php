@extends('Pluma::layouts.admin')

@section("content")
    <div class="container-fluid">
		<div class="row">

		<div class="col-md-8">
            <div class="card min-height-300">
			    <div class="card-header box-header with-border">
					<span class="box-title text-light">Meetings</span>
			    </div>
	            <div class="card-content">
					<div class="card-header p-l-0 p-t-0">
						<a href="{{ route('meetings.create') }}" class="btn waves-effect waves-light btn-yellow">Create</a>
					</div>

		            <table>
						<tbody>
							<thead>
								<th>Title</th>
								<th>Created</th>
								<th>Updated</th>
								<th>Schedule</th>
							</thead>
							@if ( $resources->isEmpty() )
								<tr>
									<td colspan="5" class="text-muted text-center">No resource found.</td>
								</tr>
							@endif
							@foreach ( $resources as $i => $resource )
								<tr class="tline p-l-2 p-r-2">
									<td><strong>{!! $resource->edit_link('meetings', $resource->title) !!}</strong></td>
									{{-- <td><a href="{{ route('meetings.index', ['author' => $resource->owner->id]) }}">{{ $resource->owner->displayname }}</a></td> --}}
									<td>{{ $resource->created }}</td>
									<td>{{ $resource->modified }}</td>
									<td>{{ $resource->schedule }}</td>

									<td width="20" class="mailbox-name reveal-btn">
										<a class="delete-btn" data-toggle="tooltip" data-placement="top" title="show" href="{{ route('meetings.show', $resource->id) }}"><i class="fa fa-eye"></i></a>
									</td>
									<td width="20" class="mailbox-name reveal-btn">
										<a class="delete-btn" data-toggle="tooltip" data-placement="top" title="edit" href="{{ route('meetings.edit', $resource->id) }}"><i class="fa fa-edit"></i></a>
									</td>
									<td width="20" class="mailbox-name reveal-btn">
										<form class="form-inline" action="{{ route('meetings.destroy', $resource->id) }}" method="POST">
											{{ csrf_field() }}
											{{ method_field('DELETE') }}
											<button type="submit" class="delete-btn" data-toggle="tooltip" data-placement="top" title="delete" data-swal='{"title":"Are you sure?","text":"{{ $resource->title }} page will be moved to Trash.","type":"warning","showCancelButton":"true","confirmButtonText":"Remove"}'><i class="fa fa-trash-o"></i></button>
										</form>
									</td>
								</tr>
							@endforeach
						</tbody>
					</table>
		        </div>
			</div>

			 <div class="card min-height-300">
			    <div class="card-header box-header with-border">
					<span class="box-title">Chat</span>
			    </div>
	            <div class="card-content">
		            <div class="placeholder-text m-t-2">
		                <p class="text-center grey-text">No new message/s.</p>
		            </div>
		        </div>
			</div>
        </div>

        <div class="col-md-4">
			<div class="row">
				<div class="col s12">
					<ul class="tabs tabs-fixed-width tabs-main">
						<li class="tab col s3"><a class="active" href="#participant">Participants</a></li>
						<li class="tab col s3"><a href="#online">Online</a></li>
					</ul>
				</div>

				<div id="participant" class="col s12">
					<div class="card">
        				<div class="card-content">
        					<div class="text-right m-b-2">
        					<a href="#" class="m-l-04" title="Add Participants"><span class="icon-btn icon-btn-default"><i class="fa fa-user-plus" aria-hidden="true"></span></i></a>
							<a href="#" class="m-l-04" title="Handset"><span class="icon-btn icon-btn-default"><i class="fa fa-headphones" aria-hidden="true"></span></i></a>
							<a href="#" class="m-l-04" title="Delete Participants"><span class="icon-btn icon-btn-delete"><i class="fa fa-user-times" aria-hidden="true"></span></i></a>
        					</div>
							<table class="bordered">
								<tbody>
									<tr>
										<td>Will</td>
										{{-- <td class="text-center"><span class="text-success status"><i class="fa fa-circle" aria-hidden="true"></i></span></td> --}}
									</tr>
									<tr>
										<td>Claire</td>
										{{-- <td class="text-center"><span class="text-success status"><i class="fa fa-circle" aria-hidden="true"></i></span></td> --}}
									</tr>
									<tr>
										<td>Jonathan</td>
										{{-- <td class="text-center"><span class="text-success status"><i class="fa fa-circle" aria-hidden="true"></i></span></td> --}}
									</tr>
								</tbody>
							</table>
						</div>
        			</div>
        		</div>

				<div id="online" class="col s12">
					<div class="card">
        				<div class="card-content">
							<table class="bordered">
								<tbody>
									<tr>
										<td>Anna</td>
										{{-- <td class="text-center"><span class="text-success status"><i class="fa fa-circle" aria-hidden="true"></i></span></td> --}}
									</tr>
									<tr>
										<td>Jane</td>
										{{-- <td class="text-center"><span class="text-success status"><i class="fa fa-circle" aria-hidden="true"></i></span></td> --}}
									</tr>
									<tr>
										<td>Mary</td>
										{{-- <td class="text-center"><span class="text-success status"><i class="fa fa-circle" aria-hidden="true"></i></span></td> --}}
									</tr>
								</tbody>
							</table>
			        	</div>
        			</div>
				</div>
			</div>
        </div>
   </div>
@stop

@push('css')
	<style>
		.icon-btn {
		    padding: 7px;
		    border-radius: 4px;
		}

		.icon-btn-default {
		    border: 1px solid #0c796f;
			background: #009688;
		}

		.icon-btn-delete {
			background: #dd4b39 !important;
			border: 1px solid #c1311f;
		}

		.m-l-04 {
			margin-left: 4px;
		}

		.icon-btn i {
			color: #fff;
		}

		.status i {
			font-size: 10px;
		}
	</style>
@endpush

@push('js')

@endpush