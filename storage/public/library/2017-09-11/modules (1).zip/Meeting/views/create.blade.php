@extends('Pluma::layouts.admin')

@section("content")
	@include("Pluma::partials.alert")

	<div class="container-fluid">
		<form action="{{ route('meetings.store') }}" method="POST">
			<div class="row">
				<div class="col-md-9">
					{{ csrf_field() }}

					<div class="card clonable-block">
						<div class="box-header with-border">
							<h3 class="box-title">New Meeting</h3>
						</div>

						<div class="box-body">
							<div class="input-field">
								<input type="text" name="title" class="validate inputfield m-b-0" value="{{ old('title') }}" data-slugger>
								<label for="title" class="inputtext">Name</label>
								@include("Pluma::errors.span", ['field' => 'title'])
							</div>

							<div class="input-field">
								<span class="slug inline">{{ url('/') }}/</span>
								<input type="text" name="slug" class="validate slug-form" readonly value="{{ old('slug') }}" placeholder="url-slug">
								@include("Pluma::errors.span", ['field' => 'slug'])
							</div>

							<div class="input-field m-0">
								<textarea name="body" class="materialize-textarea inputfield textarea-rows">{{ old('body') }}</textarea>
								<label for="textarea1" class="inputtext">Description</label>
								@include("Pluma::errors.span", ['field' => 'body'])
							</div>

							<div class="input-field m-0">
								<input type="datetime" name="schedule" class="datepicker validate inputfield" value="{{ old('schedule') }}" placeholder="Pick a Schedule">
								@include("Pluma::errors.span", ['field' => 'schedule'])
							</div>
						</div>
					</div>
				</div>

				<div class="col-md-3">
					@include("Pluma::partials.widget-saving")
				</div>
			</div>
		</form>
	</div>
@stop

@push('css')
@endpush

@push('js')
	<script src="{{ assets('Pluma/vendor/jquery-slugger/dist/jquery.slugger.min.js') }}"></script>
	<script>
		$('.datepicker').pickadate({
			selectMonths: true,
			selectYears: 15
		});
	</script>
@endpush