@extends("Pluma::layouts.admin")

@section("content")
    @include("Pluma::partials.alert")

    <div class="container-fluid">
        <form action="{{ route('meetings.update', $resource->id) }}" method="POST">
            {{ csrf_field() }}
            {{ method_field('PUT') }}
            <div class="row">
                <div class="col-md-9">
                    <div class="box no-border clonable-block" data-toggle="cloner">
                        <div class="box-header with-border">
                            <h3 class="box-title">Edit Post</h3>
                        </div>
                        <div class="box-body">
                            <div class="input-field">
                                <input name="title" type="text" class="validate inputfield m-b-0" value="{{ $resource->title }}" data-slugger>
                                <label class="inputtext slug-form" for="title">Title</label>
                                @include("Pluma::errors.span", ['field' => 'title'])
                            </div>

                            <div class="input-field">
                                <span class="slug inline">{{ url('/') }}/</span>
                                <input name="slug" type="text" class="validate slug-form" readonly name="slug" value="{{ $resource->slug }}" placeholder="url-slug">
                                @include("Pluma::errors.span", ['field' => 'slug'])
                            </div>

                            <div class="input-field m-0 clonable">
                                <button class="close clonable-button-close pull-right" type="button"><i class="fa fa-close"></i></button>
                                <textarea name="body" class="materialize-textarea inputfield textarea-rows">{{ $resource->body }}</textarea>
                                <label for="textarea1"  class="inputtext">Description</label>
                                @include("Pluma::errors.span", ['field' => 'body'])
                            </div>

                            <div class="input-field">
                                <input type="datetime" name="schedule" class="datepicker validate inputfield" value="{{ date( 'd F, Y', strtotime($resource->schedule) ) }}">
                                <label for="schedule">Pick a Schedule</label>
                                @include("Pluma::errors.span", ['field' => 'schedule'])
                            </div>
                        </div>
                        {{-- <div class="card-footer">
                            <a type="button" class="btn waves-effect waves-yellow btn-default clonable-button-add pull-right">Add Section</a>
                        </div> --}}
                    </div>
                </div>

                <div class="col-md-3">
                    {{-- @include("Pluma::partials.widget-saving") --}}

                    <div class="box no-border">
                        <div class="box-header with-border">
                            <h3 class="box-title">Saving</h3>
                        </div>
                        <div class="box-body">
                            <span>Far far away..</span>
                        </div>
                        <div class="card-footer">
                            <button type="submit" class="btn waves-effect waves-light btn-yellow pull-right">{{ isset( $label ) ? $label : ( isset( $resource->id ) ? 'Update' : 'Save' ) }}</button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
@endsection

@push('css')
@endpush

@push('js')
    <script src="{{ assets('Pluma/vendor/jquery-slugger/dist/jquery.slugger.min.js') }}"></script>
    <script src="{{ assets('Pluma/vendor/jquery-cloner/dist/jquery.cloner.min.js') }}"></script>
    <script>
        $('.datepicker').pickadate({
            selectMonths: true,
            selectYears: 15
        });
    </script>
@endpush