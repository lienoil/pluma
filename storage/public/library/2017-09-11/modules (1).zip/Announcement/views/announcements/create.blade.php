@extends("Pluma::layouts.admin")

@section("content")

	<div class="container-fluid">
		<form action="{{ route('announcements.store') }}" method="POST">
			{{ csrf_field() }}
			<div class="row">
				<div class="col-md-9">
					<div class="card">
						<div class="card-header box-header with-border">
							<h3 class="box-title">New Announcement</h3>
						</div>
						<div class="card-content">
							<div class="input-field">
								<input name="title" type="text" class="validate inputfield m-b-0" value="{{ old('title') }}" data-slugger>
								<label class="inputtext" for="title">Title</label>
								@include("Pluma::errors.span", ['field' => 'title'])
							</div>

							<div class="input-field m-0 m-t-4">
			                	<textarea name="body" class="materialize-textarea inputfield textarea-rows">{{ old('body') }}</textarea>
			                	<label for="textarea1"  class="inputtext">Description</label>
			                	@include("Pluma::errors.span", ['field' => 'body'])
			              	</div>

			              	<div class="input-field">
								<input type="datetime" name="schedule" class="datepicker validate inputfield" value="{{ old('schedule') }}" placeholder="Pick a schedule">
								{{-- <label class="inputtext" for="schedule">Schedule</label> --}}
								@include("Pluma::errors.span", ['field' => 'schedule'])
							</div>

						</div>

					</div>
				</div>
				<div class="col-md-3">
					@include("Pluma::partials.widget-saving")
				</div>
			</div>
		</form>
	</div>
@endsection

@push('post-footer')
	@include("Pluma::partials.alert")
@endpush

@push('js')
	<script>
		$('.datepicker').pickadate({
    		selectMonths: true, // Creates a dropdown to control month
    		selectYears: 15 // Creates a dropdown of 15 years to control year
  		});
	</script>
@endpush