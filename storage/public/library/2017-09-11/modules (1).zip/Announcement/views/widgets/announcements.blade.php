<div class="card">
    <div class="card-header box-header with-border bg-green">
        <h3 class="card-title text-light text-white">{!! isset( $title ) ? $title : 'Announcements' !!}</h3>
    </div>

    @if ( ! isset( $announcements ) || $announcements->isEmpty() )
    <div class="card-content text-center">
        <img src="{{ theme('src/images/megaphone.png') }}" width="100%" class="m-b-2 mx-80 tasks">
        {{-- <i class="icon-announcement fa-3x grey-text"></i> --}}
        <p class="grey-text">No announcements for the past 7 days</p>
    </div>
    @endif

    @if ( isset( $announcements ) && $announcements )
    <ul class="collection m-0 no-border">
        @foreach ( $announcements as $announcement )
            <li class="collection-item">
                <div>
                    <p><strong>{{ $announcement->title }}</strong></p>
                    <p>{{ $announcement->body }}</p>
                </div>
                <div class="clearfix">
                    <small class="right grey-text">{{ $announcement->created }}</small>
                </div>
            </li>
        @endforeach
    </ul>
    @endif
</div>

@push('css')
    <style>
        .mx-80 {
            max-width: 80px;
        }

        .text-d-blue {
            color: #236aa2 !important;
        }
    </style>
@endpush