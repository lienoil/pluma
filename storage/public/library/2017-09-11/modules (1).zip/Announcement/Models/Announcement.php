<?php

namespace Announcement\Models;

use Pluma\Models\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Announcement extends Model
{
    use SoftDeletes;
}