<?php

/*
 | --------------------------------------
 | Permissions Array
 | --------------------------------------
 |
 | Here we define our permissions that you can attach to roles.
 |
 | These permissions corresponds to a counterpart
 | route (found in <this module>/routes/<route-files>.php).
 | All permissionable routes should have a `name` (e.g. 'announcements.store')
 | for the CheckRole to work.
 |
 | These routes must have the middleware 'roles' for this to work.
 */

return [
	/**
	 * Announcement Permissions
	 *
	 */
	'view-announcement' => [
		'name' =>  'announcements.index',
		'slug' => 'view-announcement',
		'description' => 'View announcements',
	],
	'show-announcement' => [
		'name' => 'announcements.show',
		'slug' => 'show-announcement',
		'description' => 'Show a announcement',
	],
	'create-announcement' => [
		'name' => 'announcements.create',
		'slug' => 'create-announcement',
		'description' => 'Show announcement form',
	],
	'store-announcement' => [
		'name' => 'announcements.store',
		'slug' => 'store-announcement',
		'description' => 'Store the announcement',
	],
	'edit-announcement' => [
		'name' => 'announcements.edit',
		'slug' => 'edit-announcement',
		'description' => 'Edit the announcement',
	],
	'update-announcement' => [
		'name' => 'announcements.update',
		'slug' => 'update-announcement',
		'description' => 'Update the announcement',
	],
	'destroy-announcement' => [
		'name' =>  'announcements.destroy',
		'slug' => 'destroy-announcement',
		'description' => 'Destroy the announcement',
	],
	'trash-announcement' => [
		'name' =>  'announcements.trash',
		'slug' => 'trash-announcement',
		'description' => 'Trash the announcement',
	],
	'restore-announcement' => [
		'name' => 'announcements.restore',
		'slug' => 'restore-announcement',
		'description' => 'Restore the announcement',
	],
];