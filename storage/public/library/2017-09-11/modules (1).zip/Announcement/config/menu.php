<?php

/**
 * -------------------------------------------------
 * The Menu
 * -------------------------------------------------
 * Here we define our menu to be parsed in the Backend.
 */

return [
	/**
	 * Announcements Menu
	 *
	 */
	'announcement' => [
		'name' => 'announcement',
		'slug' => 'announcements',
		'parent' => true,
		// 'is_always_viewable' => true,
		'order' => 12,
		'icon' => [
			'class' => 'icon-announcement',
			'tag' => 'i',
			'content' => '&nbsp;',
		], // or can be a html string e.g. <span class="fa fa-edit">&nbsp;</span>
		'label' => [
			'singular_name' => 'Announcement',
			'plural_name' => 'Announcements',
		],
	],
	'view-announcement' => [
		'is_child_of' => 'announcement',
		'name' => 'view-announcement',
		'slug' => '/',
		'label' => [
			'singular_name' => 'All Announcement',
			'plural_name' => 'All Announcements',
		],
	],
	'create-announcement' => [
		'is_child_of' => 'announcement',
		'name' => 'create-announcement',
		'slug' => 'create',
		'label' => [
			'singular_name' => 'Create Announcement',
			'plural_name' => 'Create Announcement',
		],
	],
	'trash-announcement' => [
		'is_child_of' => 'announcement',
		'name' => 'trash-announcement',
		'slug' => 'trash',
		'icon' => [
			'class' => 'fa fa-trash',
			'tag' => 'i',
			'content' => '&nbsp;',
		],
		'label' => [
			'singular_name' => 'Trash',
			'plural_name' => 'Trash',
		],
	],
];