<?php

return [
    [
        'views' => ['Pluma::layouts.admin', '*'],
        'class' => 'Announcement\Composers\AnnouncementViewComposer',
    ],
];