<?php

namespace Announcement\Observers;

use Announcement\Models\Announcement;
use Pluma\Models\Ownership;

class AnnouncementObserver
{
	/**
	 * Listen to the Announcement created event.
	 *
	 * @param  Announcement  $announcement
	 * @return void
	 */
	public function created(Announcement $announcement)
	{
		session()->flash('name', $announcement->name);
		session()->flash('icon', "fa fa-check");
		session()->flash('message', "Announcement successfully saved");
		session()->flash('type', 'info');
	}

	/**
	 * Listen to the Announcement updated event.
	 *
	 * @param  Announcement  $announcement
	 * @return void
	 */
	public function updated(Announcement $announcement)
	{
		session()->flash('name', $announcement->name);
		session()->flash('icon', "fa fa-check");
		session()->flash('message', "Announcement successfully updated");
		session()->flash('type', 'info');
	}

	/**
	 * Listen to the Announcement deleted event.
	 *
	 * @param  Announcement  $announcement
	 * @return void
	 */
	public function deleted(Announcement $announcement)
	{
		session()->flash('name', $announcement->name);
		session()->flash('icon', "fa fa-check");
		session()->flash('message', "Announcement successfully moved to trash");
		session()->flash('type', 'info');
	}

	/**
	 * Listen to the Announcement restored event.
	 *
	 * @param  Announcement  $announcement
	 * @return void
	 */
	public function restored(Announcement $announcement)
	{
		session()->flash('name', $announcement->name);
		session()->flash('icon', "fa fa-check");
		session()->flash('message', "Announcement successfully restored");
		session()->flash('type', 'info');
	}
}