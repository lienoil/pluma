<?php
/**
 * Announcement Routes
 *
 */
Route::resource('announcements', '\Announcement\Controllers\AnnouncementController');