<?php

namespace Announcement\Composers;

use Announcement\Models\Announcement;
use Illuminate\Support\Facades\Request;
use Illuminate\Support\Facades\Route;
use Illuminate\View\View;
use Schema;

class AnnouncementViewComposer
{
    /**
     * snnouncement variable
     *
     * @var [array]
     */
    protected $announcements;

    /**
     * Main function to tie everything together.
     *
     * @param  View   $view
     * @return void
     */
    public function compose(View $view)
    {
        $view->with('announcements', $this->handle());
    }

    public function handle()
    {
        $announcements = Announcement::where('schedule', '<=', date('Y-m-d'))
            ->orderBy('created_at', 'DESC')
            ->get();

        return $announcements;
    }
}
