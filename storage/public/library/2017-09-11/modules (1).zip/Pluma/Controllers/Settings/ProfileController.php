<?php
namespace Pluma\Controllers\Settings;

use Illuminate\Http\Request;
use Pluma\Controllers\AdminController;
use Pluma\Models\Detail;
use Pluma\Models\Role;
use Pluma\Models\User;
use Pluma\Requests\ProfileRequest;
use Storage;

class ProfileController extends AdminController
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth.admin');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @param  String $handle
     * @return \Illuminate\Http\Response
     */
    public function show(ProfileRequest $request, $handle)
    {
        // Find
        $resource = User::whereUsername( $handle )->firstOrFail();

        // Load
        return view("Pluma::profiles.show")->with( compact('resource') );
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(ProfileRequest $request, $handle)
    {
        // Find
        $resource = User::whereUsername( $handle )->firstOrFail();

        // Suppliments
        $roles = Role::pluck('name', 'id');

        // Load
        return view("Pluma::profiles.edit")->with( compact('resource', 'roles') );
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(ProfileRequest $request, $handle)
    {
        // Find
        $user = User::whereUsername( $handle )->firstOrFail();
        $user->prefixname = $request->input('prefixname');
        $user->firstname = $request->input('firstname');
        $user->middlename = $request->input('middlename');
        $user->lastname = $request->input('lastname');
        $user->username = $request->input('username');
        $user->email = $request->input('email');

        // Commit
        $user->save();

        // Suppliments
        # Details
        $detail = Detail::findOrNew( $user->detail ? $user->detail->id : false );
        if ( $request->file('avatar') ) {
            $detail->avatar ? Storage::delete("public/{$detail->avatar}") : null;
            if ( $request->file('avatar')->move( storage_path( "app/public/avatars/$user->id" ), $request->file('avatar')->getClientOriginalName() ) ) {
                $detail->avatar = "avatars/$user->id/" . $request->file('avatar')->getClientOriginalName();
            }
        }
        $detail->address = $request->input('address');
        $detail->contact = $request->input('contact');
        $detail->metadata = serialize( $request->input('metadata') );
        $user->detail()->save( $detail );

        // Back
        return redirect()->route('profiles.edit', $user->handlename);
    }
}