<?php

namespace Pluma\Controllers\Debug;

use GuzzleHttp\Client;
use Illuminate\Http\Request;
use Pluma\Controllers\AdminController;

class DebugController extends AdminController
{

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $client = new Client();
        $result = $client->request('POST', "http://uat-ssa-tms.matchbyte.net:81/api/Account/GetUserSessions", []);

        echo "Status:" . $result->getStatusCode() . "<br>";
        echo "Header:" . $result->getHeader('content-type') . "<br>";
        echo "Body:" . $result->getBody() . "<br>";

        dd($result);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $resource = $request->all();

        return view("Pluma::debug.store")->with( compact('resource', 'request') );
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}