<?php
namespace Pluma\Controllers;

use Pluma\Controllers\AdminController;
use Illuminate\Http\Request;
use Pluma\Models\Permission;
use Pluma\Models\Role;
use Pluma\Requests\RoleRequest;
use Route;

class RoleController extends AdminController
{
	/**
	 * Display a listing of the resource.
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function index()
	{
		$resources = Role::where('slug', '!=', 'superadmin')->paginate( config("modules.settings.pagination_count", $this->pagination_count) );
		$trashed = Role::onlyTrashed()->get();

		return view("Pluma::roles.index")->with( compact('resources', 'trashed') );
	}

	/**
	 * Show the form for creating a new resource.
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function create()
	{
		$permissions = Permission::orderBy('name')->pluck('name', 'id');

		return view("Pluma::roles.create")->with( compact("permissions") );
	}

	/**
	 * Store a newly created resource in storage.
	 *
	 * @param  \Illuminate\Http\Request  $request
	 * @return \Illuminate\Http\Response
	 */
	public function store(Request $request)
	{
		$role = new Role();
		$role->name = $request->input('name');
		$role->slug = $request->input('slug');
		$role->description = $request->input('description');
		$role->save();
		$role->permissions()->attach( $request->input('permissions') );

		return back();
	}

	/**
	 * Display the specified resource.
	 *
	 * @param  int  $id
	 * @return \Illuminate\Http\Response
	 */
	public function show($id)
	{
		return view("Pluma::roles.show");
	}

	/**
	 * Show the form for editing the specified resource.
	 *
	 * @param  int  $id
	 * @return \Illuminate\Http\Response
	 */
	public function edit($id)
	{
		$resource = Role::find( $id );
		$permissions = Permission::orderBy('name')->get();

		return view("Pluma::roles.edit")->with( compact('resource', 'permissions') );
	}

	/**
	 * Update the specified resource in storage.
	 *
	 * @param  \Illuminate\Http\Request  $request
	 * @param  int  $id
	 * @return \Illuminate\Http\Response
	 */
	public function update(RoleRequest $request, $id)
	{
		$role = Role::find( $id );

		$role->name = $request->input('name');
		$role->slug = $request->input('slug');
		$role->description = $request->input('description');
		$role->save();
		$role->permissions()->sync( $request->input('permissions') );

		return back();
	}

	/**
	 * Display a listing of the trashed resource.
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function trash()
	{
		$resources = Role::onlyTrashed()->paginate( config("modules.settings.pagination_count", 20) );

		return view("Pluma::roles.trash")->with( compact('resources') );
	}

	/**
	 * Remove the specified resource from storage.
	 *
	 * @param  int  $id
	 * @return \Illuminate\Http\Response
	 */
	public function destroy($id)
	{
		$role = Role::find($id);
		$role->delete();

		return back();
	}

	/**
	 * Restore the specified resource from storage.
	 *
	 * @param  int  $id
	 * @return \Illuminate\Http\Response
	 */
	public function restore($id)
	{
		$role = Role::onlyTrashed()->findOrFail( $id );
		$role->restore();

		return back();
	}

	/**
	 * Delete the specified resource from storage.
	 *
	 * @param  int  $id
	 * @return \Illuminate\Http\Response
	 */
	public function delete($id)
	{
		$role = Role::onlyTrashed()->findOrFail( $id );
		$role->permissions()->detach();
		$role->forceDelete();

		return back();
	}
}