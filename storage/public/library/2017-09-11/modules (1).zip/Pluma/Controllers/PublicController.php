<?php
namespace Pluma\Controllers;

use Pluma\Models\Page;
use Illuminate\Http\Request;

class PublicController extends Controller
{
	/**
	 * The default slug.
	 *
	 * @var string
	 */
	protected $defaultSlug = 'home';

	/**
	 * Display a listing of the resource.
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function index()
	{
		return view('Pluma::public.index');
	}

	/**
	 * Display the specified resource.
	 *
	 * @param  string  $slug
	 * @return \Illuminate\Http\Response
	 */
	public function show($slug = '')
	{
		// TODO: handle nested url e.g. /blogs/feb-2017/01-the-witcher-analysis
		// $slug = explode('/', $slug);

		if ( empty( $slug ) ) $slug = $this->defaultSlug;

		if ( ! Page::whereSlug( $slug )->exists() ) return $this->staticPage( $slug );

		$page = Page::whereSlug( $slug )->first();

		return view('Pluma::public.show')->with( compact('page') );
	}

	/**
	 * Store a newly created resource in storage.
	 *
	 * @param  \Illuminate\Http\Request  $request
	 * @return \Illuminate\Http\Response
	 */
	public function store(Request $request)
	{
		dd('public controller');
	}

	public function staticPage($slug)
	{
		$modules = config('modules.enabled');

		foreach ( $modules as $module ) {
			if ( view()->exists("$module::static.$slug") ) return view("$module::static.$slug");
		}

		return abort(404);
	}
}