<?php
namespace Pluma\Controllers;

use Hash;
use Illuminate\Http\Request;
use Pluma\Controllers\AdminController as BaseController;
use Pluma\Models\Role;
use Pluma\Models\User;
use Pluma\Models\Detail;
use Pluma\Requests\DeleteUser;
use Pluma\Requests\UserRequest;
use Pluma\Requests\UserPasswordRequest;
use Storage;

class UserController extends BaseController
{

	/**
	 * Display a listing of the resource.
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function index(Request $request)
	{
		// Find
		$resources = User::paginate();

		// Suppliments
		$trashed = User::onlyTrashed();
		$filtered = count( $request->all() ) ? true : false;

		// Load
		return view("Pluma::users.index")->with( compact('resources', 'trashed', 'filtered') );
	}

	/**
	 * Show the form for creating a new resource.
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function create()
	{
		// Suppliments
		$roles = Role::except(['superadmin'])->pluck('name', 'id');

		// Load
		return view("Pluma::users.create")->with( compact('roles') );
	}

	/**
	 * Store a newly created resource in storage.
	 *
	 * @param  \Illuminate\Http\Request  $request
	 * @return \Illuminate\Http\Response
	 */
	public function store(UserRequest $request)
	{
		// Create
		$user = new User();
		$user->prefixname = $request->input('prefixname');
		$user->firstname = $request->input('firstname');
		$user->middlename = $request->input('middlename');
		$user->lastname = $request->input('lastname');
		$user->username = $request->input('username');
		$user->password = Hash::make( $request->input('password') );
		$user->email = $request->input('email');

		// Commit
		$user->save();

		// Suppliments
		# Roles
		$user->roles()->attach( $request->input('roles') );
		# Details
		$detail = new Detail();
		if ( $request->file('avatar') && $request->file('avatar')->move( storage_path( "app/public/avatars/$user->id" ), $request->file('avatar')->getClientOriginalName() ) ) {
			$detail->avatar = "avatars/$user->id/" . $request->file('avatar')->getClientOriginalName();
		}
		$detail->address = $request->input('address');
		$detail->contact = $request->input('contact');
		// $detail->sex 	 = $request->input('sex');
		$detail->metadata = serialize( $request->input('metadata') );
		$user->detail()->save( $detail );

		// Back
		return back();
	}

	/**
	 * Display the specified resource.
	 *
	 * @param  int  $id
	 * @return \Illuminate\Http\Response
	 */
	public function show($id)
	{
		// Find
		$resource = User::findOrFail( $id );

		// Load
		return view("Pluma::users.show")->with( compact('resource') );
	}

	/**
	 * Show the form for editing the specified resource.
	 *
	 * @param  int  $id
	 * @return \Illuminate\Http\Response
	 */
	public function edit($id)
	{
		// Find
		$resource = User::findOrFail( $id );

		// Suppliments
		$roles = Role::pluck('name', 'id');

		// Load
		return view("Pluma::users.edit")->with( compact('resource', 'roles') );
	}

	/**
	 * Update the specified resource in storage.
	 *
	 * @param  \Illuminate\Http\Request  $request
	 * @param  int  $id
	 * @return \Illuminate\Http\Response
	 */
	public function update(UserRequest $request, $id)
	{
		// Find
		$user = User::findOrFail( $id );
		$user->prefixname = $request->input('prefixname');
		$user->firstname = $request->input('firstname');
		$user->middlename = $request->input('middlename');
		$user->lastname = $request->input('lastname');
		$user->username = $request->input('username');
		$user->email = $request->input('email');

		// Commit
		$user->save();

		// Suppliments
		# Roles
		$user->roles()->sync( $request->input('roles') );
		# Details
		$detail = Detail::findOrNew( $user->detail ? $user->detail->id : false );
		if ( $request->file('avatar') ) {
			$detail->avatar ? Storage::delete("public/{$detail->avatar}") : null;
			if ( $request->file('avatar')->move( storage_path( "app/public/avatars/$user->id" ), $request->file('avatar')->getClientOriginalName() ) ) {
				$detail->avatar = "avatars/$user->id/" . $request->file('avatar')->getClientOriginalName();
			}
		}
		$detail->address = $request->input('address');
		$detail->contact = $request->input('contact');
		// $detail->sex 	 = $request->input('sex');
		$detail->metadata = serialize( $request->input('metadata') );
		$user->detail()->save( $detail );

		// Back
		return back();
	}

	/**
	 * Remove the specified resource from storage.
	 *
	 * @param  \Pluma\Models\User  $user
	 * @return \Illuminate\Http\Response
	 */
	public function destroy(DeleteUser $request, $id)
	{
		// Commit
		$resource = User::destroy( $id );

		// Back
		return back();
	}

	/**
	 * Display a listing of the trashed resource.
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function trash()
	{
		// Find
		$resources = User::onlyTrashed()->paginate();

		// Load
		return view("Pluma::users.trash")->with( compact('resources') );
	}

	/**
	 * Restore the specified resource from storage.
	 *
	 * @param  int  $id
	 * @return \Illuminate\Http\Response
	 */
	public function restore($id)
	{
		// Find
		$user = User::onlyTrashed()->findOrFail( $id );

		// Commit
		$user->restore();

		// Back
		return back();
	}

	/**
	 * Delete the specified resource from storage permanently.
	 *
	 * @param  int  $id
	 * @return \Illuminate\Http\Response
	 */
	public function delete($id)
	{
		// Find
		$user = User::onlyTrashed()->findOrFail( $id );

		// Detach
		$user->roles()->detach();

		// Commit
		$user->forceDelete();

		// Back
		return back();
	}

	/**
	 * Change the Password for a given resource
	 *
	 * @param  \Illuminate\Http\Request  $request
	 * @param  int  $id
	 * @return \Illuminate\Http\Response
	 */
	public function changePassword(UserPasswordRequest $request, $id)
	{
		// Find
		$user = User::findOrFail( $id );
		$user->password = Hash::make( $request->input('password') );

		// Commit
		$user->save();

		// Back
		return back();
	}
}