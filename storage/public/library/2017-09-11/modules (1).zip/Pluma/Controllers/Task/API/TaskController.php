<?php

namespace Pluma\Controllers\Task\API;

use Pluma\Controllers\APIController as Controller;
use Illuminate\Http\Request;
use Pluma\Models\Task;
use Pluma\Models\User;

class TaskController extends Controller
{

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        if ( $request->ajax() ) {
            $resources = Task::whereUserId( $request->get('user_id') )
                // ->orderBy('status', 'ASC')
                ->orderBy('created_at', 'DESC')
                ->get();

            return view("Pluma::tasks.partials.list")->with( compact('resources') );
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // Create
        $user = User::find( $request->input('user_id') );
        $task = new Task();
        $task->note = $request->input('note');
        $task->status = $request->input('status');
        $task->user()->associate( $user );

        // Commit
        $task->save();

        // Back
        return response()->json( $request->all() );
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        // Find
        $task = Task::findOrFail( $id );
        $task->status = $request->input('status') ? $request->input('status') : 'pending';

        // Commit
        $task->save();

        // Back
        return response()->json( $request->all() );
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        // Find
        $task = Task::findOrFail( $id );

        // Commit
        $task->delete();

        // Suppliment
        $this->successResponse['message'] = "Successfully deleted tasks";

        // Back
        return response()->json( $this->successResponse );
    }
}