<?php
namespace Pluma\Controllers\Library;

use Pluma\Controllers\Controller as Controller;
use Illuminate\Http\Request;
use Pluma\Models\Library;

class ExplorerController extends Controller
{

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function showExplorerForm($mime = null)
    {
        if ( is_null( $mime ) ) {
            $resources = Library::orderBy('updated_at', 'DESC')->get();
        } else {
            $resources = Library::orderBy('updated_at', 'DESC')->where('mime', $mime)->get();
        }

        return view("Pluma::library.explorer")->with( compact('resources') );
    }
}