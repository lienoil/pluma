<?php
namespace Pluma\Controllers\Library;

use Pluma\Controllers\AdminController as Controller;
use Illuminate\Http\Request;
use Pluma\Models\Library;
use File;

class LibraryController extends Controller
{

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $resources = Library::orderBy('updated_at', 'DESC')->whereType( get_class(new Library) )->paginate();
        $trashed = Library::whereType( get_class(new Library) )->onlyTrashed();
        $filtered = count( $request->all() ) ? true : false;

        return view("Pluma::library.index")->with( compact('resources', 'trashed', 'filtered') );
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view("Pluma::library.create");
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        return response()->json( $request->all() );
    }

    /**
     * Display the specified resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request)
    {
        $resource = Library::findOrFail( $request->get('file') );

        return view("Pluma::library.show")->with( compact('resource') );
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $resource = Library::findOrFail( $id );

        return view("Pluma::library.edit")->with( compact('resource') );
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $library = Library::findOrFail( $id );
        $library->delete();

        return back();
    }

    public function trash()
    {
        $resources = Library::onlyTrashed()->whereType( get_class(new Library) )->paginate();

        return view("Pluma::library.trash")->with( compact('resources') );
    }

    /**
     * Upload the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function upload(Request $request, $uploadDir = 'uploads', $prefixDir = 'app/public')
    {
        if ( is_array( $request->file('upload') ) ) {

            foreach ( $request->file('upload') as $file ) {

                $path = config("settings.upload_path", "$uploadDir/") . date('m-d-y');

                if ( $file->move( storage_path( "$prefixDir/$path/" ), $file->getClientOriginalName() ) ) {

                    $library = new Library();
                    $library->originalname = $file->getClientOriginalName();
                    $library->pathname = $path . "/" . $file->getClientOriginalName();
                    $library->url = $path . "/" . $file->getClientOriginalName();
                    $library->size = $file->getClientSize();
                    $library->mime = File::mimeType( storage_path( "$prefixDir/$path" . "/" . $file->getClientOriginalName() ) );
                    $library->type = get_class(new Library);
                    $library->save();

                }
            }

        } else {

            $file = $request->file('upload');

            $path = config("settings.upload_path", "$uploadDir/") . date('m-d-y');

            if ( $file->move( storage_path( $path ), $file->getClientOriginalName() ) ) {

                $library = new Library();
                $library->originalname = $file->getClientOriginalName();
                $library->pathname = $path . "/" . $file->getClientOriginalName();
                $library->url = $path . "/" . $file->getClientOriginalName();
                $library->size = $file->getClientSize();
                $library->type = get_class(new Library);
                $library->save();

            }
        }

        return back();
    }

    public function delete($id)
    {
        $library = Library::findOrFail( $id );
        $file = $library->pathname;
        $library->forceDelete();

        if ( File::exists( $file ) ) {
            File::delete( $file );
        }

        return back();
    }
}