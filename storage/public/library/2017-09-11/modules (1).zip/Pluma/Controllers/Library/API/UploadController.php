<?php
namespace Pluma\Controllers\Library\API;

use Pluma\Controllers\APIController as Controller;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use Illuminate\Http\Request;
use Pluma\Models\Library;
use File;

class UploadController extends Controller
{

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function uploadFile(Request $request, $uploadDir = 'uploads', $prefixDir = 'app/public')
    {

        if ( is_array( $request->file('upload') ) ) {

            foreach ( $request->file('upload') as $file ) {

                $path = config("settings.upload_path", "$uploadDir/") . date('m-d-y');

                if ( $file->move( storage_path( "$prefixDir/$path/" ), $file->getClientOriginalName() ) ) {

                    $library = new Library();
                    $library->originalname = $file->getClientOriginalName();
                    $library->pathname = $path . "/" . $file->getClientOriginalName();
                    $library->url = $path . "/" . $file->getClientOriginalName();
                    $library->size = $file->getClientSize();
                    $library->mime = File::mimeType( storage_path( "$prefixDir/$path" . "/" . $file->getClientOriginalName() ) );
                    $library->type = get_class(new Library);
                    $library->save();

                }
            }

        } else {

            $file = $request->file('upload');

            $path = config("settings.upload_path", "$uploadDir/") . date('m-d-y');

            if ( $file->move( storage_path( "$prefixDir/$path" ), $file->getClientOriginalName() ) ) {

                $library = new Library();
                $library->originalname = $file->getClientOriginalName();
                $library->pathname = $path . "/" . $file->getClientOriginalName();
                $library->url = $path . "/" . $file->getClientOriginalName();
                $library->size = $file->getClientSize();
                $library->type = get_class(new Library);
                $library->save();

            }
        }

        // session()

        return response()->json([ 'success'=> true, 'message' => 'Upload successful', 'fileBag' => $request->file(), 'requestBag' => $request->all()]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}