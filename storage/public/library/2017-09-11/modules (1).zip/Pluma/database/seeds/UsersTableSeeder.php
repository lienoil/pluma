<?php

namespace Pluma\Database\Seeds;

use Illuminate\Database\Seeder;
use Pluma\Models\User;
use Pluma\Models\Role;
use Hash;

class UsersTableSeeder extends Seeder
{

	public function run()
	{
		$user = new User();
		$user->firstname = "John Lioneil";
		$user->lastname = "Dionisio";
		$user->username = "";
		$user->email = "john.dionisio1@gmail.com";
		$user->password = Hash::make('admin');
		$user->save();
		$user->roles()->save( Role::find(1) );

		$user = new User();
		$user->firstname = "Good";
		$user->lastname = "God";
		$user->username = "";
		$user->email = "god@heaven.com";
		$user->password = Hash::make('admin');
		$user->save();
		$user->roles()->save( Role::find(1) );
	}

}