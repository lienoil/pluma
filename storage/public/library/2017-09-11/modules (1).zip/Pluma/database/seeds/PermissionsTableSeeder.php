<?php

namespace Pluma\Database\Seeds;

use Illuminate\Database\Seeder;
use Pluma\Models\Permission;

class PermissionsTableSeeder extends Seeder
{

	public function run()
	{
		$modules = config("modules.enabled");
		$permissions = [];
		foreach ( $modules as $module ) {
			if ( file_exists( base_path("modules/$module/config/permissions.php") ) ) {
				$permissions += (array) require base_path("modules/$module/config/permissions.php");
			}
		}

		foreach ( $permissions as $name => $permission ) {
			if ( ! Permission::whereSlug($permission['slug'])->exists() ) {
				$_permission = new Permission();//Permission::create( $permission );
				$_permission->name = $permission['name'];
				$_permission->slug = $permission['slug'];
				$_permission->description = $permission['description'];
				$_permission->save();
			}
		}
	}

}