<?php

namespace Pluma\Database\Seeds;

use Illuminate\Database\Seeder;
use Pluma\Models\Menu;
use Pluma\Support\Traits\Module;

class MenusTableSeeder extends Seeder
{
	use Module;

	public function run()
	{
		$menus = $this->getModuleConfigFromKey('menu');
		foreach ( $menus as $menu ) {
			$m = new Menu();
			$m->name = $menu['name'];
			$m->slug = $menu['slug'];
			$m->parent = isset( $menu['is_child_of'] ) ? $menu['is_child_of'] : '';
			// $m->lft =
		}
	}

}