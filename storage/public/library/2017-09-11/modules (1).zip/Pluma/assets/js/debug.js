// Do not include in production

alert('asdasd');