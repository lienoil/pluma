<?php

/**
 * -------------------------------------------------
 * The Menu
 * -------------------------------------------------
 * Here we define our menu to be parsed in the Backend.
 */

return [
	/**
	 * Dashboard
	 *
	 */
	'dashboard' => [
		'name' => 'dashboard',
		'slug' => 'dashboard',
		'parent' => true,
		'is_always_viewable' => true,
		'order' => 1,
		'icon' => [
			'class' => 'icon-dashboard',
			'tag' => 'i',
			'content' => '&nbsp;',
		], // or can be a html string e.g. <span class="fa fa-edit">&nbsp;</span>
		'label' => [
			'singular_name' => 'Dashboard',
			'plural_name' => 'Dashboard',
		],
	],

	'content' => [
		'name' => 'content',
		'slug' => '#',
		'order' => 2,
		'parent' => true,
		'is_always_viewable' => true,
		'ignore' => true,
		'is_separator' => true,
		// 'icon' => [
		// 	'class' => 'fa fa-cogs',
		// 	'tag' => 'i',
		// 	'content' => '&nbsp;',
		// ], // or can be a html string e.g. <span class="fa fa-edit">&nbsp;</span>
		'label' => [
			'singular_name' => 'Content',
			'plural_name' => 'Content',
		],
	],

	/**
	 * Pages Menu
	 *
	 */
	'page' => [
		'name' => 'page',
		'slug' => 'pages',
		'parent' => true,
		'is_always_viewable' => false,
		'order' => 3,
		'icon' => [
			'class' => 'fa fa-file',
			'tag' => 'i',
			'content' => '&nbsp;',
		], // or can be a html string e.g. <span class="fa fa-edit">&nbsp;</span>
		'label' => [
			'singular_name' => 'Page',
			'plural_name' => 'Pages',
		],
	],
	'view-page' => [
		'is_child_of' => 'page',
		'name' => 'view-page',
		'slug' => '/',
		// 'is_always_viewable' => true,
		// 'order' => 1,
		'label' => [
			'singular_name' => 'All Page',
			'plural_name' => 'All Pages',
		],
	],
	'create-page' => [
		'is_child_of' => 'page',
		'name' => 'create-page',
		'slug' => 'create',
		// 'is_always_viewable' => true,
		// 'order' => 2,
		'label' => [
			'singular_name' => 'Create Page',
			'plural_name' => 'Create Page',
		],
	],
	'trash-page' => [
		'is_child_of' => 'page',
		'name' => 'trash-page',
		'slug' => 'trash',
		// 'before' => '<hr>',
		// 'is_always_viewable' => true,
		// 'order' => 2,
		'icon' => [
			'class' => 'fa fa-trash',
			'tag' => 'i',
			'content' => '&nbsp;',
		],
		'label' => [
			'singular_name' => 'Trash',
			'plural_name' => 'Trash',
		],
	],
	'manage' => [
		'name' => 'manage',
		'slug' => '#',
		'order' => 69,
		'is_always_viewable' => true,
		'ignore' => true,
		'is_separator' => true,
		'icon' => [
			'class' => 'fa fa-cogs',
			'tag' => 'i',
			'content' => '&nbsp;',
		], // or can be a html string e.g. <span class="fa fa-edit">&nbsp;</span>
		'label' => [
			'singular_name' => 'Manage',
			'plural_name' => 'Manage',
		],
	],

	/**
	 * Library
	 *
	 */
	'library' => [
		'name' => 'library',
		'slug' => 'library',
		'parent' => true,
		'order' => 98,
		'icon' => [
			'class' => 'fa fa-picture-o',
			'tag' => 'i',
			'content' => '&nbsp;',
		], // or can be a html string e.g. <span class="fa fa-edit">&nbsp;</span>
		'label' => [
			'singular_name' => 'Media Library',
			'plural_name' => 'Media Library',
		],
	],

	'view-library' => [
		'is_child_of' => 'library',
		'name' => 'view-library',
		'slug' => '/',
		'label' => [
			'singular_name' => 'Library',
			'plural_name' => 'Library',
		],
	],

	'create-library' => [
		'is_child_of' => 'library',
		'name' => 'create-library',
		'slug' => 'create',
		'label' => [
			'singular_name' => 'Add Media',
			'plural_name' => 'Add Media',
		],
	],

	'trash-library' => [
		'is_child_of' => 'library',
		'name' => 'trash-library',
		'slug' => 'trash',
		'icon' => [
			'class' => 'fa fa-trash',
			'tag' => 'i',
			'content' => '&nbsp;',
		], // or can be a html string e.g. <span class="fa fa-edit">&nbsp;</span>
		'label' => [
			'singular_name' => 'Trash',
			'plural_name' => 'Trash',
		],
	],

	/**
	 * User Menu
	 *
	 */
	'user' => [
		'name' => 'user',
		'slug' => 'users',
		'parent' => true,
		'order' => 99,
		'icon' => [
			'class' => 'fa fa-users',
			'tag' => 'i',
			'content' => '&nbsp;',
		], // or can be a html string e.g. <span class="fa fa-edit">&nbsp;</span>
		'label' => [
			'singular_name' => 'User',
			'plural_name' => 'Users',
		],
	],

	'view-user' => [
		'is_child_of' => 'user',
		'name' => 'view-user',
		'slug' => '/',
		'label' => [
			'singular_name' => 'All User',
			'plural_name' => 'All Users',
		],
	],

	'create-user' => [
		'is_child_of' => 'user',
		'name' => 'create-user',
		'slug' => 'create',
		'label' => [
			'singular_name' => 'Create User',
			'plural_name' => 'Create User',
		],
	],

	'trash-user' => [
		'is_child_of' => 'user',
		'name' => 'trash-user',
		'slug' => 'trash',
		'icon' => [
			'class' => 'fa fa-trash',
			'tag' => 'i',
			'content' => '&nbsp;',
		], // or can be a html string e.g. <span class="fa fa-edit">&nbsp;</span>
		'label' => [
			'singular_name' => 'Trash',
			'plural_name' => 'Trash',
		],
	],

	'role' => [
		'name' => 'role',
		'slug' => 'roles',
		'parent' => true,
		'order' => 100,
		'icon' => [
			'class' => 'icon-roles',
			'tag' => 'i',
			'content' => '&nbsp;',
		], // or can be a html string e.g. <span class="fa fa-edit">&nbsp;</span>
		'label' => [
			'singular_name' => 'Role',
			'plural_name' => 'Roles',
		],
	],

	'view-role' => [
		'name' => 'view-role',
		'slug' => '/',
		'is_child_of' => 'role',
		// 'order' => 1,
		// 'icon' => [
		// 	'class' => 'fa fa-user',
		// 	'tag' => 'i',
		// 	'content' => '&nbsp;',
		// ], // or can be a html string e.g. <span class="fa fa-edit">&nbsp;</span>
		'label' => [
			'singular_name' => 'All Role',
			'plural_name' => 'All Roles',
		],
	],

	'create-role' => [
		'name' => 'create-role',
		'slug' => 'create',
		'is_child_of' => 'role',
		// 'order' => 1,
		// 'icon' => [
		// 	'class' => 'fa fa-user',
		// 	'tag' => 'i',
		// 	'content' => '&nbsp;',
		// ], // or can be a html string e.g. <span class="fa fa-edit">&nbsp;</span>
		'label' => [
			'singular_name' => 'Create Role',
			'plural_name' => 'Create Role',
		],
	],

	'view-permission' => [
		'name' => 'view-permissions',
		'slug' => 'permissions',
		'is_child_of' => 'role',
		// 'order' => 1,
		'icon' => [
			'class' => 'fa fa-unlock',
			'tag' => 'i',
			'content' => '&nbsp;',
		], // or can be a html string e.g. <span class="fa fa-edit">&nbsp;</span>
		'label' => [
			'singular_name' => 'Permission',
			'plural_name' => 'Permissions',
		],
	],

	'trash-role' => [
		'name' => 'trash-role',
		'slug' => 'trash',
		'is_child_of' => 'role',
		// 'order' => 1,
		'icon' => [
			'class' => 'fa fa-trash',
			'tag' => 'i',
			'content' => '&nbsp;',
		], // or can be a html string e.g. <span class="fa fa-edit">&nbsp;</span>
		'label' => [
			'singular_name' => 'Trash',
			'plural_name' => 'Trash',
		],
	],

	'settings' => [
		'name' => 'settings',
		'slug' => 'settings',
		'parent' => true,
		'order' => 999,
		'is_always_viewable' => true,
		'icon' => [
			'class' => 'icon-settings',
			'tag' => 'i',
			'content' => '&nbsp;',
		], // or can be a html string e.g. <span class="fa fa-edit">&nbsp;</span>
		'label' => [
			'singular_name' => 'Settings',
			'plural_name' => 'Settings',
		],
	],

	// 'view-settings' => [
	// 	'is_child_of' => 'settings',
	// 	'name' => 'view-settings',
	// 	'slug' => 'general',
	// 	'order' => 1,
	// 	'is_always_viewable' => true,
	// 	'label' => [
	// 		'singular_name' => 'General',
	// 		'plural_name' => 'General',
	// 	],
	// ],

	'view-profile' => [
		'is_always_viewable' => true,
		'is_child_of' => 'settings',
		'name' => 'view-profile',
		'slug' => 'profile',
		// 'order' => 2,
		'icon'=> [
			'class' => 'fa fa-vcard',
			'tag' => 'i',
			'content' => '&nbsp;',
		], // or can be a html string e.g. <span class="fa fa-edit">&nbsp;</span>
		'label' => [
			'singular_name' => 'Profile',
			'plural_name' => 'Profile',
		],
	],
];