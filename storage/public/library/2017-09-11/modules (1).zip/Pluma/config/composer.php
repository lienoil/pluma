<?php

return [
	[
		'views' => ['Pluma::layouts.admin'],
		'class' => 'Pluma\Composers\MenuViewComposer',
	],
	[
		'views' => ['Pluma::widgets.categories', 'Pluma::categories.widget'],
		'class' => 'Pluma\Composers\CategoryViewComposer',
	],
	[
		'views' => ['Pluma::layouts.admin', 'Pluma::layouts.public'],
        'class' => 'Pluma\Composers\BreadcrumbViewComposer',
	],
	[
		'views' => ['*'],
       	'class' => 'Pluma\Composers\PageViewComposer',
	],
	[
		'views' => ['*'],
		'class' => 'Pluma\Composers\ColumnViewComposer',
	],
	[
		'views' => ['Pluma::layouts.admin', '*::dashboard.*', 'Pluma::partials.utilitybar'],
		'class' => 'Pluma\Composers\WidgetsViewComposer',
	],
];