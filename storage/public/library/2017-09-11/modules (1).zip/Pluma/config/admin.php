<?php

return [
    'menus' => [
        'attributes' => [
            'menu' => array(
                'id' => '',
                'class' => 'nav sidebar-stacked',
            ),
            'item' => array(
                'class' => 'sidebar-item',
            ),
            'link' => array(
                'class' => 'sidebar-link',
            ),
        ],
    ],
];