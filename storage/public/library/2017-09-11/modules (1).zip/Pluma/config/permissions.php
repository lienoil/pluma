<?php


/*
 | --------------------------------------
 | Permissions Array
 | --------------------------------------
 |
 | Here we define our permissions that you can attach to roles.
 |
 | These permissions corresponds to a counterpart
 | route (found in <this module>/routes/<route-files>.php).
 | All permissionable routes should have a `name` (e.g. 'posts.store')
 | for the CheckRole to work.
 |
 | These routes must have the middleware 'roles' for this to work.
 */

return [
	/**
	 * Page Permissions
	 *
	 */
    'view-page' => [
        'name' =>  'pages.index',
        'slug' => 'view-page',
        'description' => 'View pages',
    ],
    'show-page' => [
        'name' => 'pages.show',
        'slug' => 'show-page',
        'description' => 'Show a page',
    ],
    'create-page' => [
        'name' => 'pages.create',
        'slug' => 'create-page',
        'description' => 'Show page form',
    ],
    'store-page' => [
        'name' => 'pages.store',
        'slug' => 'store-page',
        'description' => 'Store the page',
    ],
    'edit-page' => [
        'name' => 'pages.edit',
        'slug' => 'edit-page',
        'description' => 'Edit the page',
    ],
    'update-page' => [
        'name' => 'pages.update',
        'slug' => 'update-page',
        'description' => 'Update the page',
    ],
    'destroy-page' => [
        'name' =>  'pages.destroy',
        'slug' => 'destroy-page',
        'description' => 'Destroy the page',
    ],
    'trash-page' => [
        'name' =>  'pages.trash',
        'slug' => 'trash-page',
        'description' => 'Trash the page',
    ],
    'restore-page' => [
        'name' => 'pages.restore',
        'slug' => 'restore-page',
        'description' => 'Restore the page',
    ],

	/**
	 * User Permissions
	 *
	 */
	'view-user' => [
		'name' =>  'users.index',
		'slug' => 'view-user',
		'description' => 'View users',
	],
	'show-user' => [
		'name' => 'users.show',
		'slug' => 'show-user',
		'description' => 'Show a user',
	],
	'create-user' => [
		'name' => 'users.create',
		'slug' => 'create-user',
		'description' => 'Show user form',
	],
	'store-user' => [
		'name' => 'users.store',
		'slug' => 'store-user',
		'description' => 'Store the user',
	],
	'edit-user' => [
		'name' => 'users.edit',
		'slug' => 'edit-user',
		'description' => 'Edit the user',
	],
	'update-user' => [
		'name' => 'users.update',
		'slug' => 'update-user',
		'description' => 'Update the user',
	],
	'destroy-user' => [
		'name' =>  'users.destroy',
		'slug' => 'destroy-user',
		'description' => 'Destroy the user',
	],
	'trash-user' => [
		'name' =>  'users.trash',
		'slug' => 'trash-user',
		'description' => 'Trash the user',
	],
	'restore-user' => [
		'name' => 'users.restore',
		'slug' => 'restore-user',
		'description' => 'Restore the user',
	],

	/**
	 * Role Permissions
	 *
	 */
	'view-role' => [
		'name' =>  'roles.index',
		'slug' => 'view-role',
		'description' => 'View roles',
	],
	'show-role' => [
		'name' => 'roles.show',
		'slug' => 'show-role',
		'description' => 'Show a role',
	],
	'create-role' => [
		'name' => 'roles.create',
		'slug' => 'create-role',
		'description' => 'Show role form',
	],
	'store-role' => [
		'name' => 'roles.store',
		'slug' => 'store-role',
		'description' => 'Store the role',
	],
	'edit-role' => [
		'name' => 'roles.edit',
		'slug' => 'edit-role',
		'description' => 'Edit the role',
	],
	'update-role' => [
		'name' => 'roles.update',
		'slug' => 'update-role',
		'description' => 'Update the role',
	],
	'destroy-role' => [
		'name' =>  'roles.destroy',
		'slug' => 'destroy-role',
		'description' => 'Destroy the role',
	],
	'trash-role' => [
		'name' =>  'roles.trash',
		'slug' => 'trash-role',
		'description' => 'Trash the role',
	],
	'restore-role' => [
		'name' => 'roles.restore',
		'slug' => 'restore-role',
		'description' => 'Restore the role',
	],

	/**
	 * Permission Permissions
	 *
	 */
	'view-permissions' => [
		'name' => 'permissions.index',
		'slug' => 'view-permissions',
		'description' => 'View permissions',
	],
	'show-permissions' => [
		'name' => 'permissions.show',
		'slug' => 'show-permissions',
		'description' => 'Show the permission',
	],
	'refresh-permissions' => [
		'name' => 'permissions.refresh',
		'slug' => 'refresh-permissions',
		'description' => 'Refresh the permissions',
	],
	'reset-permissions' => [
		'name' => 'permissions.reset',
		'slug' => 'reset-permissions',
		'description' => 'Reset the permissions',
	],

    /**
     * Category Permissions
     *
     */
    'view-category' => [
        'name' =>  'categories.index',
        'slug' => 'view-category',
        'description' => 'View categories',
    ],
    'show-category' => [
        'name' => 'categories.show',
        'slug' => 'show-category',
        'description' => 'Show a category',
    ],
    'create-category' => [
        'name' => 'categories.create',
        'slug' => 'create-category',
        'description' => 'Show category form',
    ],
    'store-category' => [
        'name' => 'categories.store',
        'slug' => 'store-category',
        'description' => 'Store the category',
    ],
    'edit-category' => [
        'name' => 'categories.edit',
        'slug' => 'edit-category',
        'description' => 'Edit the category',
    ],
    'update-category' => [
        'name' => 'categories.update',
        'slug' => 'update-category',
        'description' => 'Update the category',
    ],
    'destroy-category' => [
        'name' =>  'categories.destroy',
        'slug' => 'destroy-category',
        'description' => 'Destroy the category',
    ],
    'trash-category' => [
        'name' =>  'categories.trash',
        'slug' => 'trash-category',
        'description' => 'Trash the category',
    ],
    'restore-category' => [
        'name' => 'categories.restore',
        'slug' => 'restore-category',
        'description' => 'Restore the category',
    ],

    /**
     * Profile Permissions
     *
     */
    'view-profile' => [
        'name' =>  'profiles.index',
        'slug' => 'view-profile',
        'description' => 'View profiles',
    ],
    'show-profile' => [
        'name' => 'profiles.show',
        'slug' => 'show-profile',
        'description' => 'Show a profile',
    ],
    'edit-profile' => [
        'name' => 'profiles.edit',
        'slug' => 'edit-profile',
        'description' => 'Edit the profile',
    ],
    'update-profile' => [
        'name' => 'profiles.update',
        'slug' => 'update-profile',
        'description' => 'Update the profile',
    ],

    /**
     * Library Permissions
     *
     */
    'view-library' => [
        'name' =>  'library.index',
        'slug' => 'view-library',
        'description' => 'View library',
    ],
    'show-library' => [
        'name' => 'library.show',
        'slug' => 'show-library',
        'description' => 'Show a library',
    ],
    'create-library' => [
        'name' => 'library.create',
        'slug' => 'create-library',
        'description' => 'Show library form',
    ],
    'store-library' => [
        'name' => 'library.store',
        'slug' => 'store-library',
        'description' => 'Store the library',
    ],
    'edit-library' => [
        'name' => 'library.edit',
        'slug' => 'edit-library',
        'description' => 'Edit the library',
    ],
    'update-library' => [
        'name' => 'library.update',
        'slug' => 'update-library',
        'description' => 'Update the library',
    ],
    'destroy-library' => [
        'name' =>  'library.destroy',
        'slug' => 'destroy-library',
        'description' => 'Destroy the library',
    ],
    'trash-library' => [
        'name' =>  'library.trash',
        'slug' => 'trash-library',
        'description' => 'Trash the library',
    ],
    'restore-library' => [
        'name' => 'library.restore',
        'slug' => 'restore-library',
        'description' => 'Restore the library',
    ],
];