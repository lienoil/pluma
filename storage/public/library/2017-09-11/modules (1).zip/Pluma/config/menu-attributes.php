<?php

return [
    'depth-1' => [
        'menu' => [
            'tag' => 'ul',
            'class' => ['sidebar-menu'],
            'active' => [],
            'active-parent' => [],
            'parent' => ['has-child'],
        ],
        'item' => [
            'tag' => 'li',
            'class' => [''],
            'active' => ['active'],
            'active-parent' => ['active', 'open'],
            'parent' => ['treeview'],
        ],
        'link' => [
            'tag' => 'a',
            'class' => [],
            'active' => [],
            'parent' => ['dropdown-toggle'],
            'data-toggle' => ['sidebar-dropdown'],
        ],
    ],

    'depth-2' => [
        'menu' => [
            'tag' => 'ul',
            'class' => ['treeview-menu', 'menu-open'],
            'active' => ['active'],
            'active-parent' => ['active', 'open'],
            'parent' => [],
        ],
        'item' => [
            'tag' => 'li',
            'class' => [],
            'active' => ['active'],
            'active-parent' => ['active', 'open'],
            'parent' => [],
        ],
        'link' => [
            'tag' => 'a',
            'class' => [],
            'active' => ['active'],
            'parent' => [],
        ],
    ],

    'depth-3' => [
        'menu' => [
            'tag' => 'ul',
            'class' => ['tri-menu', 'open'],
            'active' => ['active'],
            'parent' => [],
        ],
        'item' => [
            'tag' => 'li',
            'class' => ['dropdown-item-group'],
            'active' => ['active'],
            'active-parent' => ['active', 'open'],
            'parent' => [],
        ],
        'link' => [
            'tag' => 'a',
            'class' => ['dropdown-item'],
            'active' => ['active'],
            'parent' => [],
        ],
    ],
];