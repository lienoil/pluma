<?php
namespace Pluma\Composers;

use Illuminate\Support\Facades\Request;
use Illuminate\View\View;
use Pluma\Helpers\Arrays;
use Pluma\Helpers\Menus;
use Pluma\Helpers\Permission;
use Pluma\Support\Traits\CheckIfMenuIsViewableByUser;
use Pluma\Support\Traits\Traverser;
use Route;
use stdClass;

/**
 * -----------------------------------
 * Menu View Composer
 * -----------------------------------
 * The view composer for dynamic menus based on modules.
 *
 * @author John Lioneil Dionisio <john.dionisio1@gmail.com>
 */
class MenuViewComposer
{
    use Traverser, CheckIfMenuIsViewableByUser;

    protected $activeItems;
    protected $activeSlug;
    protected $attributes = [
        'depth-1' => [
            'menu' => [
                'tag' => 'ul',
                'class' => ['nav', 'sidebar-stacked'],
                'active' => ['active'],
                'active-parent' => ['active', 'open'],
                'parent' => ['has-child'],
            ],
            'item' => [
                'tag' => 'li',
                'class' => ['sidebar-item'],
                'active' => ['active'],
                'active-parent' => ['active', 'open'],
                'parent' => ['dropdown'],
            ],
            'link' => [
                'tag' => 'a',
                'class' => ['sidebar-link'],
                'active' => [],
                'parent' => ['dropdown-toggle'],
                'data-toggle' => ['sidebar-dropdown'],
            ],
        ],

        'depth-2' => [
            'menu' => [
                'tag' => 'ul',
                'class' => ['dropdown-menu'],
                'active' => ['active'],
                'active-parent' => ['active', 'open'],
                'parent' => [],
            ],
            'item' => [
                'tag' => 'li',
                'class' => ['dropdown-item-group'],
                'active' => ['active'],
                'active-parent' => ['active', 'open'],
                'parent' => [],
            ],
            'link' => [
                'tag' => 'a',
                'class' => ['dropdown-item'],
                'active' => ['active'],
                'parent' => [],
            ],
        ],

        'depth-3' => [
            'menu' => [
                'tag' => 'ul',
                'class' => ['tri-menu', 'open'],
                'active' => ['active'],
                'parent' => [],
            ],
            'item' => [
                'tag' => 'li',
                'class' => ['dropdown-item-group'],
                'active' => ['active'],
                'active-parent' => ['active', 'open'],
                'parent' => [],
            ],
            'link' => [
                'tag' => 'a',
                'class' => ['dropdown-item'],
                'active' => ['active'],
                'parent' => [],
            ],
        ],
    ];

    /**
     * Main function to tie everything together.
     *
     * @param  View   $view
     * @return void
     */
    public function compose(View $view)
    {
        $modules = config('modules.enabled');
        $menus = [];

        foreach ($modules as $module) {
            if (file_exists(base_path("modules/$module/config/menu.php"))) {
                $menus += (array) require base_path("modules/$module/config/menu.php");
            }
        }

        $menus = $this->filterViewableMenus($menus);

        $this->setActiveLink();
        $this->setActiveSlug();
        $this->setAttributes();

        $this->set($menus);
        $this->prepare('root', 1, ['parent' => 'is_child_of']);
        $menus = $this->get();

        $menus = $this->rechild($menus, 'root', ['parent'=>'is_child_of']);

        $menus = $this->sortBy('order', $menus);
        $menus = $this->checkIfMenuHasChild($menus);
        $menus = Arrays::to_object_recursive([
            'html' => $this->make($menus, 1),
            'segments' => $menus,
        ]);

        config()->set("modules.admin.menu.raw", $this->get());

        $view->with('menus', $menus);
    }

    public function make($menus = null, $depth = 1)
    {
        $this->setActiveItems($menus);

        $html = '';
        $traversables = $menus ? $menus : $this->get();
        $attributes = $this->attributes;
        $attributes = isset($attributes["depth-$depth"]) ? $attributes["depth-$depth"] : $attributes["depth-3"];
        $attributes['menu']['class'][] = "level-$depth";
        $attributes['menu']['class'] = implode(' ', $attributes['menu']['class']);
        $attributes['link']['class'] = implode(' ', $attributes['link']['class']);

        $html .= "<{$attributes['menu']['tag']} class='{$attributes['menu']['class']}'>";

        foreach ($traversables as $traversable) {
            if (isset($traversable['is_separator']) && $traversable['is_separator']) {
                $html .= "</{$attributes['menu']['tag']}>";
                // $html .= "<li>";
                $html .= "<div class='separator-block' style='padding:2rem 1rem 0 1rem;color:gray;font-size:10px;text-transform:uppercase;' class='sidebar-separator'><strong>{$traversable['label']['plural_name']}</strong></div>";
                // $html .= $traversable['label']['singular_name'];//$this->makeHeader($traversable);
                // $html .= "</li>";
                $html .= "</{$attributes['menu']['tag']}><{$attributes['menu']['tag']} class='{$attributes['menu']['class']}'>";

                // Start the next loop imidiately
                continue;
            }


            $url = isset($traversable['slug']) ? $this->url($traversable['slug'], $this->getParentsAsSlug($traversable['left'], $traversable['right'])) : '';
            $icon = isset($traversable['icon']) ? $this->icon($traversable['icon']) : '';
            $parent = $traversable['is_child_of'];

            $item_attr = [];
            $item_class = [];

            $link_attr = [];
            $link_class = [];
            $link_roles = [];

            $item_class[] = implode(" ", $this->attributes["depth-$depth"]['item']['class']);
            $link_class[] = implode(" ", $this->attributes["depth-$depth"]['link']['class']);

            if ($this->isActiveLink($url)) {
                $item_class[] = implode(" ", $this->attributes["depth-$depth"]['item']['active']);
                $link_class[] = implode(" ", $this->attributes["depth-$depth"]['link']['active']);
            }

            if ($this->isActiveItem($traversable['name'])) {
                $item_class[] = implode(" ", $this->attributes["depth-$depth"]['item']['active-parent']);
            }

            if ($this->activeLinkIsChildOfParent($traversable['name'], $traversable['slug'])) {
                $item_class[] = implode(" ", $this->attributes["depth-$depth"]['item']['active-parent']);
                $link_class[] = implode(" ", $this->attributes["depth-$depth"]['link']['active']);
            }

            if ($traversable['has_children']) {
                $item_class[] = implode(" ", $this->attributes["depth-$depth"]['item']['parent']);
                $link_class[] = implode(" ", $this->attributes["depth-$depth"]['link']['parent']);
                // $link_attr[] = "data-toggle='" . (isset($this->attributes["depth-$depth"]['link']['data-toggle']) ? implode(" ", $this->attributes["depth-$depth"]['link']['data-toggle']) : 'sidebar-dropdown') . "'";
                $link_attr[] = isset($this->attributes["depth-$depth"]['link']['data-toggle']) ? "data-toggle='" . implode(" ", $this->attributes["depth-$depth"]['link']['data-toggle']) . "'" : "";

                // If has children, and one of the children is active,
                // then activate this parent aswell.
                $descendants = $this->descendants($traversable['left'], $traversable['right']);
                foreach ($descendants as $descendant) {
                    $url = isset($descendant['slug']) ? $this->url($descendant['slug'], $this->getParentsAsSlug($descendant['left'], $descendant['right'])) : '';
                    if ($this->isActiveLink($url)) {
                        $item_class[] = implode(" ", $this->attributes["depth-$depth"]['item']['active-parent']);
                    }
                }
            }

            $item_class = 'class="'.implode(" ", $item_class).'"';
            $item_attr[] = $item_class;
            $item_attr = implode(" ", $item_attr);

            $link_class = 'class="'.implode(" ", $link_class).'"';
            $link_attr[] = $link_class;
            $link_attr[] = "href='".$url."'";
            $link_attr = implode(" ", $link_attr);

            $html .= "<{$attributes['item']['tag']} {$item_attr}>";

            // if( ! isset( $traversable['label'] ) ) {
            // 	dd($traversable);
            // }
            $before = isset($traversable['before']) ? $traversable['before'] : "";
            $after = isset($traversable['after']) ? $traversable['after'] : "";

            $html .= "{$before}<{$attributes['link']['tag']} $link_attr>{$icon}<span>{$traversable['label']['plural_name']}</span></{$attributes['link']['tag']}>{$after}";
            $html .= $traversable['has_children'] ? $this->make($traversable['children'], $this->getDepth($traversable['left'], $traversable['right'])) : '';
            $html .= "</{$attributes['item']['tag']}>";
        }
        $html .= "</{$attributes['menu']['tag']}>";

        return $html;
    }

    public function setAttributes()
    {
        $current = config("settings.theme", 'default');
        if (file_exists(base_path("themes/$current/config/menu-attributes.php"))) {
            $this->attributes = require_once base_path("themes/$current/config/menu-attributes.php");
        }

        return $this->attributes;
    }

    public function icon($icon)
    {
        if (is_array($icon)) {
            return "<{$icon['tag']} class='{$icon['class']}'>{$icon['content']}</{$icon['tag']}>";
        }

        return $icon;
    }

    public function url($url, $parent)
    {
        return url(preg_replace('#/+#', '/', "$parent/$url"));
    }

    public function getActiveItems()
    {
        return $this->activeItems;
    }

    public function setActiveItems($menus)
    {
        // dd($menus);
        $activeItems = [];
        foreach ($menus as $i => $menu) {
            $url = isset($menu['slug']) ? $this->url($menu['slug'], $this->getParentsAsSlug($menu['left'], $menu['right'])) : '';

            if ($this->isActiveLink($url)) {
                $ancestors = $this->ancestors($menu['left'], $menu['right']);
                $activeItems = $ancestors;
            }
        }

        $this->activeItems = $activeItems;

        return $this;
    }

    public function isActiveItem($activeItem)
    {
        // dd($activeItem);
        return in_array($activeItem, (array) $this->getActiveItems());
    }

    public function setActiveSlug($slug = "")
    {
        if ("" != $slug) {
            return $this->activeSlug = $slug;
        }

        if (null == Request::route()) {
            return false;
        }

        $this->activeSlug = Route::current()->getCompiled()->getStaticPrefix();
    }

    public function getActiveSlug()
    {
        return $this->activeSlug;
    }

    public function setActiveLink($url = null)
    {
        // dd(Route::current());
        if (null == Request::route()) {
            return $this->currentUrl = null;
        }

        $this->currentUrl = $url ? $url : url(Request::route()->getUri()); // Request::url();
    }

    public function getActiveLink()
    {
        return $this->currentUrl;
    }

    public function isActiveLink($url)
    {
        return $url == $this->getActiveLink();
    }

    public function activeLinkIsChildOfParent($param, $slug = null, $menu = null)
    {
        // TODO: better way to write this?
        $r[] = $this->getPrefix();
        $r[] = str_plural($param);
        $r[] = 'trash';
        $active_links[] = url(implode("/", $r));

        $parent = $this->getActiveSlug();
        $parents = explode("/", $parent);
        $old_param = $param;
        $param = "{".$param."}";

        $current = url(Route::current()->getUri());
        $active_links[] = url("$parent/$param");
        $active_links[] = url("$parent/$param/edit");

        // foreach ( $parents as $p ) {
        // 	$pp = implode("/", $parents);
        // 	$active_links[] = url("$pp");
        // 	$end = count($parents) - 1;
        // 	unset( $parents[ $end ] );
        // }

        // $active_links[] = url("$parent/$param/remove");
        // if (Route::current()->getUri()==="admin/forms/{$menu['slug']}/{field}/edit") dd($active_links);//dd($active_links);
        // dd( $active_links );

        return in_array($this->getActiveLink(), $active_links);
    }

    public function getPrefix()
    {
        if (null === Route::current()) {
            return false;
        }

        $actions = Route::current()->getAction();
        return isset($actions['prefix']) ? $actions['prefix'] : false;
    }

    public function getParentsAsSlug($left, $right)
    {
        $parents = $this->ancestors($left, $right);

        foreach ($parents as &$parent) {
            if ('root' == $parent['name']) {
                $parent['slug'] = config("modules.backend.prefix");
            }
            $parent = $parent['slug'];
        }

        return implode('/', $parents);
    }

    public function getDepth($left, $right)
    {
        return count($this->ancestors($left, $right)) + 1; // +1 for current depth
    }

    public function sortBy($type, $menus)
    {
        uasort($menus, function ($a, $b) use ($type) {
            $a[ $type ] = isset($a[ $type ]) ? $a[ $type ] : 0;
            $b[ $type ] = isset($b[ $type ]) ? $b[ $type ] : 0;
            return ((array) $a[ $type ] <= (array) $b[ $type ]) ? -1 : 1;
        });

        return $menus;
    }
}
