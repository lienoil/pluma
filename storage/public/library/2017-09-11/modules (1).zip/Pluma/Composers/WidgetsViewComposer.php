<?php
namespace Pluma\Composers;

use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Request;
use Illuminate\Support\Facades\Route;
use Illuminate\View\View;
use Pluma\Models\Task;

/**
 * -----------------------------------
 * Category View Composer
 * -----------------------------------
 * The view composer for dynamic headings, subheading, and other content on page.
 *
 * @author John Lioneil Dionisio <john.dionisio1@gmail.com>
 */
class WidgetsViewComposer
{
    /**
     * Some of the widgets to load on dashboard
     * and other Yggdrasil views.
     *
     * @var null
     */
    protected $tasks = null;

    /**
     * Main function to tie everything together.
     *
     * @param  View   $view
     * @return void
     */
    public function compose(View $view)
    {
        $view->with('tasks', $this->handle());
    }

    public function handle()
    {
        $this->setTasks();

        return $this->getTasks();
    }

    public function setTasks()
    {
        $this->tasks = Task::whereUserId( auth()->user()->id )
            ->orderBy('status', 'ASC')
            ->orderBy('created_at', 'DESC')
            ->get();
    }

    public function getTasks()
    {
        return $this->tasks;
    }

}