<?php
namespace Pluma\Composers;

use Illuminate\View\View;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Request;
use Pluma\Models\Category;

/**
 * -----------------------------------
 * Category View Composer
 * -----------------------------------
 * The view composer for dynamic headings, subheading, and other content on page.
 *
 * @author John Lioneil Dionisio <john.dionisio1@gmail.com>
 */
class CategoryViewComposer
{

    /**
     * Main function to tie everything together.
     *
     * @param  View   $view
     * @return void
     */
    public function compose(View $view)
    {
        $view->with('categories', $this->handle());
    }

    public function handle()
    {
        return Category::pluck('name', 'id');
    }
}