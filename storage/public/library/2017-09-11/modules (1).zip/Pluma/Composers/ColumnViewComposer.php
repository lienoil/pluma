<?php

namespace Pluma\Composers;

use Illuminate\View\View;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Request;
use Schema;

class ColumnViewComposer
{
	protected $columns;
	protected $resource;

	/**
	 * Main function to tie everything together.
	 *
	 * @param  View   $view
	 * @return void
	 */
	public function compose(View $view)
	{
		$this->set_columns( $view );
		$view->with('columns', function ($resource) {
			$this->set_resource( $resource );
			return $this->get_columns();
		});
	}

	public function set_columns(View $view)
	{
		if (null == Route::getFacadeRoot()->current()) return false;

		$this->columns = Schema::getColumnListing(strtolower($this->resource));
	}

	public function get_columns()
	{
		return $this->columns;
	}

	public function set_resource($resource)
	{
		$this->resource = $resource;
	}

	public function get_resource()
	{
		return $this->resource;
	}
}