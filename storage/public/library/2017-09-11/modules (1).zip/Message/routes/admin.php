<?php

// Message
Route::get('messages/trash', 'Message\Controllers\MessageController@trash')->name('messages.trash');
Route::post('messages/{message}/restore', 'Message\Controllers\MessageController@restore')->name('messages.restore');
Route::delete('messages/{message}/delete', 'Message\Controllers\MessageController@delete')->name('messages.delete');
Route::resource('messages', '\Message\Controllers\MessageController');