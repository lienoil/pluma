<?php

namespace Message\Observers;

use Message\Models\Message;
use Pluma\Models\Ownership;
use Illuminate\Http\Request;

class MessageObserver
{
	/**
	 * Listen to the Message created event.
	 *
	 * @param  Message  $message
	 * @return void
	 */
	public function created(Message $message)
	{
		// $ownership = new Ownership();
		// $ownership->created_by = auth()->user()->id;
		// $ownership->updated_by = auth()->user()->id;
		// $ownership->user()->associate( auth()->user() );
		// $ownership->save();

		// $message->ownerships()->save( $ownership );

		session()->flash('title', $message->title);
		session()->flash('icon', "fa fa-check");
		session()->flash('message', "Message successfully saved");
		session()->flash('type', 'info');
	}

	/**
	 * Listen to the Message updated event.
	 *
	 * @param  Message  $message
	 * @return void
	 */
	public function updated(Meeting $meeting)
	{
		session()->flash('name', $meeting->name);
		session()->flash('icon', "fa fa-check");
		session()->flash('message', "Meeting successfully updated");
		session()->flash('type', 'info');
	}

	/**
	 * Listen to the Message deleted event.
	 *
	 * @param  Message  $message
	 * @return void
	 */
	public function deleted(Meeting $meeting)
	{
		session()->flash('name', $meeting->name);
		session()->flash('icon', "fa fa-check");
		session()->flash('message', "Meeting successfully updated");
		session()->flash('type', 'info');
	}

	/**
	 * Listen to the Message restored event.
	 *
	 * @param  Message  $message
	 * @return void
	 */
	public function restored(Meeting $meeting)
	{
		session()->flash('name', $meeting->name);
		session()->flash('icon', "fa fa-check");
		session()->flash('message', "Meeting successfully updated");
		session()->flash('type', 'info');
	}
}