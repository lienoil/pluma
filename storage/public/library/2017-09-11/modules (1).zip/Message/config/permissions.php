<?php


/*
 | --------------------------------------
 | Permissions Array
 | --------------------------------------
 |
 | Here we define our permissions that you can attach to roles.
 |
 | These permissions corresponds to a counterpart
 | route (found in <this module>/routes/<route-files>.php).
 | All permissionable routes should have a `name` (e.g. 'posts.store')
 | for the CheckRole to work.
 |
 | These routes must have the middleware 'roles' for this to work.
 */

return [
	/**
	 * Survey Permissions
	 *
	 */
	'view-message' => [
		'name' =>  'messages.index',
		'slug' => 'view-message',
		'description' => 'View messages',
	],
	'show-message' => [
		'name' => 'messages.show',
		'slug' => 'show-message',
		'description' => 'Show a message',
	],
	'create-message' => [
		'name' => 'messages.create',
		'slug' => 'create-message',
		'description' => 'Show the message',
	],
	'store-message' => [
		'name' => 'messages.store',
		'slug' => 'store-message',
		'description' => 'Store the message',
	],
	'edit-message' => [
		'name' => 'messages.edit',
		'slug' => 'edit-message',
		'description' => 'Edit the message',
	],
	'update-message' => [
		'name' => 'messages.update',
		'slug' => 'update-message',
		'description' => 'Update the message',
	],
	'destroy-message' => [
		'name' =>  'messages.destroy',
		'slug' => 'destroy-message',
		'description' => 'Destroy the message',
	],
	'trash-message' => [
		'name' =>  'messages.trash',
		'slug' => 'trash-message',
		'description' => 'Trash the message',
	],
	'restore-message' => [
		'name' => 'messages.restore',
		'slug' => 'restore-message',
		'description' => 'Restore the message',
	],
];