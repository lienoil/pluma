<?php

return [
	/**
	 * Messages
	 *
	 */
	'message' => [
		'name' => 'message',
		'slug' => 'messages',
		'parent' => true,
		// 'is_always_viewable' => true,
		'order' => 70,
		'icon' => [
			'class' => 'fa fa-whatsapp',
			'tag' => 'i',
			'content' => '&nbsp;',
		], // or can be a html string e.g. <span class="fa fa-edit">&nbsp;</span>
		'label' => [
			'singular_name' => 'Message',
			'plural_name' => 'Message',
		],
	],
	'view-message' => [
		'is_child_of' => 'message',
		'name' => 'view-message',
		'slug' => '/',
		// 'is_always_viewable' => true,
		// 'order' => 1,
		'label' => [
			'singular_name' => 'All Message',
			'plural_name' => 'All Messages',
		],
	],
	'create-message' => [
		'is_child_of' => 'message',
		'name' => 'create-message',
		'slug' => 'create',
		// 'is_always_viewable' => true,
		// 'order' => 2,
		'label' => [
			'singular_name' => 'Create Message',
			'plural_name' => 'Create Message',
		],
	],

	/**
	 * Message Trash
	 */
	'trash-message' => [
		'is_child_of' => 'message',
		'name' => 'trash-message',
		'slug' => 'trash',
		// 'before' => '<hr>',
		// 'is_always_viewable' => true,
		// 'order' => 2,
		'icon' => [
			'class' => 'fa fa-trash',
			'tag' => 'i',
			'content' => '&nbsp;',
		],
		'label' => [
			'singular_name' => 'Trash',
			'plural_name' => 'Trash',
		],
	],
];