<?php
namespace Message\Controllers;

use Message\Models\Message;
use Illuminate\Http\Request;
use Message\Requests\MessageRequest;
use Pluma\Controllers\AdminController as Controller;

class MessageController extends Controller
{

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $resources = Message::filter()->paginate(config("settings.pagination_count", $this->pagination_count));
        $trashed = Message::onlyTrashed();
        $filtered = count ( $request->all() ) ? true : false;

        return view('Message::index')->with(compact('resources', 'trashed', 'filtered'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        return view("Message::create");
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(MessageRequest $request)
    {
        $message = new Message();
        $message->title = $request->input('title');
        $message->slug = $request->input('slug');
        $message->body = $request->input('body');

        $message->save();

        return back();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $resource = Message::findOrFail($id);

        return view("Message::show")->with(compact('resource'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $resource = Message::findOrFail( $id );

        return view("Message::edit")->with(compact('resource'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $message = Message::findOrFail ( $id );
        $message->title = $request->input('title');
        $message->slug = $request->input('slug');
        $message->body = $request->input('body');
        $message->save();

        return back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $message = Message::findOrFail($id);
        $message->delete();

        return back();
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function trash()
    {
        $resources = Message::onlyTrashed()->paginate(config("settings.pagination_count", $this->pagination_count));

        return view("Message::trash")->with(compact('resources'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function restore($id)
    {
        $resource = Message::onlyTrashed()->findOrFail($id);
        $resource->restore();

        return back();
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function delete($id)
    {
        $message = Message::onlyTrashed()->findOrFail( $id );
        $message->forceDelete();

        return back();
    }
}