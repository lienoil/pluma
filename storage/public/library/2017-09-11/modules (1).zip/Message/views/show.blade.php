@extends("Pluma::layouts.admin")
@section("content")
	@include("Pluma::partials.alert")
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">

				<div class="box no-border card">
					<div class="box-header with-border">
						<h3 class="box-title">{{ $resource->title }}</h3>
					</div>

					<div class="box-body">
						{{ $resource->body }}
					</div>
				</div>
			</div>
		</div>
	</div>
@endsection

@push('css')
	<style>
		.card-image a img {
			border-radius: 50% !important;
			padding: 20px;
		}
	</style>
@endpush