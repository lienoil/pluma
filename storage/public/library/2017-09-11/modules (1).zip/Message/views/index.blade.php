@extends('Pluma::layouts.admin')

@section("content")
	<div class="container-fluid">
		<div class="box no-border">
			<div class="box-body p-0">
				<div class="row">
					<div class="col-md-4">
						<div class="box-header with-border border-right">
							<div class="left">
								Messages
							</div>
							<div class="right">
								<a href="messages/create"><i class="fa fa-edit"></i></a>
							</div>
						</div>
						<div class="clear"></div>
						<div class="user-msg border-right">
							<ul class="collection m-0">
								<li class="collection-item avatar m-0 no-border">
									<i class="material-icons circle green">insert_chart</i>
									<span class="title">Jane Doe</span>
									<p>Hello
									</p>
									<p href="#!" class="secondary-content"><small class="text-muted">10:40am</small></p>
								</li>
							</ul>
						</div>
					</div>

					<div class="col-md-8 row p-0">
						<div class="box-header with-border border-right">
							<div class="text-center">
								Jane Doe
							</div>
						</div>

						<div class="user-msg">
							<div class="box-body">
								Hello
							</div>
						</div>
					</div>
				</div>
				{{-- <table>
					<tbody>
						<thead>
							<th>Title</th>
							<th>Created</th>
							<th>Updated</th>
						</thead>
						@if ( $resources->isEmpty() )
							<tr>
								<td colspan="5" class="text-muted text-center">No resource found.</td>
							</tr>
						@endif
						@foreach ( $resources as $i => $resource )
							<tr class="tline p-l-2 p-r-2">
								<td><strong>{!! $resource->edit_link('messages', $resource->title) !!}</strong></td>
								<td>{{ $resource->created }}</td>
								<td>{{ $resource->modified }}</td>

								<td width="20" class="mailbox-name reveal-btn">
									<a class="delete-btn" data-toggle="tooltip" data-placement="top" title="show" href="{{ route('messages.show', $resource->id) }}"><i class="fa fa-eye"></i></a>
								</td>
								<td width="20" class="mailbox-name reveal-btn">
									<a class="delete-btn" data-toggle="tooltip" data-placement="top" title="edit" href="{{ route('messages.edit', $resource->id) }}"><i class="fa fa-edit"></i></a>
								</td>
								<td width="20" class="mailbox-name reveal-btn">
									<form class="form-inline" action="{{ route('messages.destroy', $resource->id) }}" method="POST">
										{{ csrf_field() }}
										{{ method_field('DELETE') }}
										<button type="submit" class="delete-btn" data-toggle="tooltip" data-placement="top" title="delete" data-swal='{"title":"Are you sure?","text":"{{ $resource->title }} page will be moved to Trash.","type":"warning","showCancelButton":"true","confirmButtonText":"Remove"}'><i class="fa fa-trash-o"></i></button>
									</form>
								</td>
							</tr>
						@endforeach
					</tbody>
				</table> --}}
		</div>
   </div>
@stop

@push('css')
	<style>
		.scroll {
			overflow: auto !important;
		}

		.user-msg {
			overflow: auto;
			max-height: 80vh;
			min-height: 80vh;
		}

		.no-border {
			border: none !important;
		}

		.collection {
			border: none !important;
		}

		.collection .collection-item {
			border-bottom: none !important;
		}

		.n-b-l {
			border-left: transparent !important;
		}

		.n-b-b {
			border-bottom: transparent !important;
		}

		.n-b-t {
			border-top: transparent !importants;
		}

		.n-b-r {
			border-right: transparent !important;
		}

		.font-20 {
			font-size: 20px !important;
		}

		.icon-btn {
			padding: 7px;
			border-radius: 4px;
		}

		.icon-btn-default {
			border: 1px solid #0c796f;
			background: #009688;
		}

		.icon-btn-delete {
			background: #dd4b39 !important;
			border: 1px solid #c1311f;
		}

		.m-l-04 {
			margin-left: 4px;
		}

		.icon-btn i {
			color: #fff;
		}

		.status i {
			font-size: 10px;
		}
	</style>
@endpush

@push('js')

@endpush