@extends("Pluma::layouts.admin")

@section("content")
	@include("Pluma::partials.alert")

	<div class="container-fluid">
		<form action="{{ route('messages.store') }}" method="POST">
			<div class="row">
				<div class="col-md-9">
					{{ csrf_field() }}
					<div class="box no-border clonable-block" data-toggle="cloner">
						<div class="box-header with-border">
							<h3 class="box-title">New Message</h3>
						</div>
						<div class="box-body">
							<div class="input-field">
								<input name="title" type="text" class="validate inputfield m-b-0" value="{{ old('title') }}" data-slugger>
								<label class="inputtext slug-form" for="title">To</label>
								@include("Pluma::errors.span", ['field' => 'title'])
							</div>

							<div class="input-field">
								<span class="slug inline">{{ url('/') }}/</span>
								<input name="slug" type="text" class="validate slug-form" readonly value="{{ old('slug') }}" placeholder="url-slug">
								@include("Pluma::errors.span", ['field' => 'slug'])
							</div>

							<div class="input-field m-0">
			                	<textarea name="body" class="materialize-textarea inputfield textarea-rows">{{ old('body') }}</textarea>
			                	<label for="textarea1"  class="inputtext">Message</label>
			                	@include("Pluma::errors.span", ['field' => 'body'])
			              	</div>
			            </div>
					</div>
				</div>

				<div class="col-md-3">
					@include("Pluma::partials.widget-saving")
				</div>
			</div>
		</form>
	</div>
@endsection

@push('css')
@endpush

@push('js')
	<script src="{{ assets('Pluma/vendor/jquery-slugger/dist/jquery.slugger.min.js') }}"></script>
	<script src="{{ assets('Pluma/vendor/jquery-cloner/dist/jquery.cloner.min.js') }}"></script>
@endpush