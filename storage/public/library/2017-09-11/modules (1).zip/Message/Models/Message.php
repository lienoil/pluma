<?php

namespace Message\Models;

use Pluma\Models\Model;
use Pluma\Models\User;
use Pluma\Support\Traits\Ownable;
use Pluma\Support\Traits\Searchable;
use Illuminate\Database\Eloquent\SoftDeletes;

class Message extends Model
{
    use Ownable, SoftDeletes, Searchable;

	/**
	 * The alias for column `body`
	 *
	 * @return string
	 */

	public function getContentAttribute()
	{
		return $this->body;
	}

	public function authors()
	{
		//
	}
}