<?php

namespace Form\Requests;

use Pluma\Requests\FormRequest as Request;

class FormRequest extends Request
{
	/**
	 * Determine if the user is authorized to make this request.
	 *
	 * @return bool
	 */
	public function authorize()
	{
		switch ( $this->method() ) {
			case 'POST':
				if ( $this->user()->can('store-form') ) return true;
				break;

			case 'PUT':
				if ( $this->user()->can('update-form') ) return true;
				break;

			case 'DELETE':
				if ( $this->user()->can('destroy-form') ) return true;
				break;

			default:
				return false;
				break;
		}

		return false;
	}

	/**
	 * Get the validation rules that apply to the request.
	 *
	 * @return array
	 */
	public function rules()
	{
		return [
			'name' => 'required',
			'method' => 'required',
		];
	}
}
