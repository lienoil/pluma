<?php
namespace Form\Controllers;

use Form\Models\Field;
use Form\Requests\FieldRequest;
use Illuminate\Http\Request;
use Pluma\Controllers\AdminController as Controller;
use Pluma\Helpers\Arrays;

class FieldController extends Controller
{

	/**
	 * Display a listing of the resource.
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function index(Request $request)
	{
		$resources = Field::paginate(config("settings.pagination_count", $this->pagination_count));
		$filtered = count( $request->all() ) ? true : false;

		return view("Form::fields.index")->with( compact('resources', 'filtered') );
	}

	/**
	 * Show the form for creating a new resource.
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function create()
	{
		$types = Field::$types;
		$rules = Field::$rules;

		return view("Form::fields.create")->with( compact('types', 'rules') );
	}

	/**
	 * Store a newly created resource in storage.
	 *
	 * @param  \Illuminate\Http\Request  $request
	 * @return \Illuminate\Http\Response
	 */
	public function store(FieldRequest $request)
	{
		$field = new Field();
		$field->title = $request->input('title');
		$field->name = $request->input('name');
		$field->label = $request->input('label');
		$field->type = $request->input('type');
		$field->value = $request->input('value');
		$field->attrs = serialize( $request->input('attrs') );
		$field->validations = serialize( $request->input('rules') );
		$field->save();

		return back();
	}

	/**
	 * Display the specified resource.
	 *
	 * @param  int  $id
	 * @return \Illuminate\Http\Response
	 */
	public function show($id)
	{
		$resource = Field::findOrFail( $id );

		return view("Form::fields.show")->with( compact('resource') );
	}

	/**
	 * Show the form for editing the specified resource.
	 *
	 * @param  int  $id
	 * @return \Illuminate\Http\Response
	 */
	public function edit($id)
	{
		$resource = Field::findOrFail( $id );
		$types = Field::$types;
		$rules = Field::$rules;

		return view("Form::fields.edit")->with( compact('resource', 'types', 'rules') );
	}

	/**
	 * Update the specified resource in storage.
	 *
	 * @param  \Illuminate\Http\Request  $request
	 * @param  int  $id
	 * @return \Illuminate\Http\Response
	 */
	public function update(Request $request, $id)
	{
		$field = Field::findOrFail( $id );
		$field->title = $request->input('title');
		$field->name = $request->input('name');
		$field->label = $request->input('label');
		$field->type = $request->input('type');
		$field->value = $request->input('value');
		$field->attr = serialize( $request->input('attr') );
		$field->rules = serialize( $request->input('rules') );
		$field->save();

		return back();
	}

	/**
	 * Remove the specified resource from storage.
	 *
	 * @param  int  $id
	 * @return \Illuminate\Http\Response
	 */
	public function destroy($id)
	{
		$resource = Field::findOrFail( $id );
		$resource->delete();

		return back();
	}
}