<?php
namespace Form\Controllers;

use Form\Models\Template;
use Form\Requests\TemplateRequest;
use Illuminate\Http\Request;
use Pluma\Controllers\AdminController as Controller;
use Pluma\Helpers\Arrays;

class TemplateController extends Controller
{

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $resources = Template::paginate(config("settings.pagination_count", $this->pagination_count));
        $filtered = count( $request->all() ) ? true : false;

        return view("Form::templates.index")->with( compact('resources', 'filtered') );
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view("Form::templates.create");
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(TemplateRequest $request)
    {
        $template = new Template();
        $template->name = $request->input('name');
        $template->body = $request->input('body');
        $template->save();

        return back();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $resource = Template::findOrFail( $id );

        return view("Form::templates.show")->with( compact('resource') );
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $resource = Template::findOrFail( $id );

        return view("Form::templates.edit")->with( compact('resource') );
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(TemplateRequest $request, $id)
    {
        $template = Template::findOrFail( $id );
        $template->name = $request->input('name');
        $template->body = $request->input('body');
        $template->save();

        return back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $resource = Template::findOrFail( $id );
        $resource->delete();

        return back();
    }
}