<?php
namespace Form\Controllers;

use Form\Models\Field;
use Form\Models\Form;
use Form\Models\Template;
use Form\Requests\FormRequest;
use Form\Support\Builder\FormBuilder;
use Illuminate\Http\Request;
use Pluma\Controllers\AdminController as Controller;

class FormController extends Controller
{

	/**
	 * Display a listing of the resource.
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function index(Request $request)
	{
		$resources = Form::paginate();
		$trashed = Form::onlyTrashed();
		$filtered = count( $request->all() ) ? true : false;

		return view("Form::forms.index")->with( compact('resources', 'trashed', 'filtered') );
	}

	/**
	 * Show the form for creating a new resource.
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function create()
	{
		$methods = ['POST' => "POST Method", 'GET' => 'GET Method'];
		$fields = Field::pluck('title', 'id');
		$templates = Template::pluck('name', 'id');

		return view("Form::forms.create")->with( compact('methods', 'fields', 'templates') );
	}

	/**
	 * Store a newly created resource in storage.
	 *
	 * @param  \Illuminate\Http\Request  $request
	 * @return \Illuminate\Http\Response
	 */
	public function store(Request $request)
	{
		// dd($request->all());
		$form = new Form();
		$form->name = $request->input('name');
		$form->method = $request->input('method');
		$form->description = $request->input('description');
		$form->type = get_class(new Form);

		$template = Template::findOrFail( $request->input('template') );
		$form->template()->associate( $template );

		$form->save();
		$form->fields()->attach( $request->input('fields') );
		return back();
	}

	/**
	 * Display the specified resource.
	 *
	 * @param  int  $id
	 * @return \Illuminate\Http\Response
	 */
	public function show($id)
	{
		// TODO: do TemplateController first before doing this
		$resource = Form::findOrFail( $id );

		$form = FormBuilder::make( $resource, 'debug.store' );
		// dd($form);
		// dd($form);
		// $form = Form::make($id);

		return view("Form::forms.show")->with( compact('resource', 'form') );
	}

	/**
	 * Show the form for editing the specified resource.
	 *
	 * @param  int  $id
	 * @return \Illuminate\Http\Response
	 */
	public function edit($id)
	{
		$resource = Form::with(['fields' => function ($q) {
			// Preserve the order of the fields
			$q->orderBy('field_form.sort', 'asc');

		}])->findOrFail( $id );

		$methods = ['POST' => "POST Method", 'GET' => 'GET Method'];
		$fields = Field::pluck('title', 'id');
		$templates = Template::pluck('name', 'id');

		return view("Form::forms.edit")->with( compact('resource', 'methods', 'fields', 'templates') );
	}

	/**
	 * Update the specified resource in storage.
	 *
	 * @param  \Illuminate\Http\Request  $request
	 * @param  int  $id
	 * @return \Illuminate\Http\Response
	 */
	public function update(FormRequest $request, $id)
	{
		$form = Form::findOrFail( $id );
		$form->name = $request->input('name');
		$form->method = $request->input('method');
		$form->description = $request->input('description');
		$form->type = get_class(new Form);

		$form->template()->dissociate();
		$template = Template::findOrFail( $request->input('template') );
		$form->template()->associate( $template );

		$form->save();

		$form->fields()->sync( $request->input('fields') );
		$form->template()->associate( $request->input('template') );

		return back();
	}

	/**
	 * Display a listing of the trashed resource.
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function trash()
	{
		$resources = Form::onlyTrashed()->paginate( config("settings.pagination_count", $this->pagination_count) );

		return view("Form::forms.trash")->with( compact('resources') );
	}

	/**
	 * Remove the specified resource from storage.
	 *
	 * @param  int  $id
	 * @return \Illuminate\Http\Response
	 */
	public function destroy($id)
	{
		$resource = Form::findOrFail( $id );
		$resource->delete();

		return back();
	}

	/**
	 * Restore the specified resource from storage.
	 *
	 * @param  int  $id
	 * @return \Illuminate\Http\Response
	 */
	public function restore($id)
	{
		$form = Form::onlyTrashed()->findOrFail( $id );
		$form->restore();

		return back();
	}

	/**
	 * Delete the specified resource from storage.
	 *
	 * @param  int  $id
	 * @return \Illuminate\Http\Response
	 */
	public function delete($id)
	{
		$form = Form::onlyTrashed()->findOrFail( $id );
		$form->fields()->detach();
		$form->forceDelete();

		return back();
	}
}
