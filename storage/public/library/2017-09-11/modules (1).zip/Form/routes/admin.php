<?php

/**
 * Field Routes
 *
 */
Route::resource('forms/fields', '\Form\Controllers\FieldController');

/**
 * Template Routes
 *
 */
Route::resource('forms/templates', '\Form\Controllers\TemplateController');

/**
 * Forms Routes
 *
 */
Route::get('forms/trash', '\Form\Controllers\FormController@trash')->name('forms.trash');
Route::post('forms/{form}/restore', '\Form\Controllers\FormController@restore')->name('forms.restore');
Route::delete('forms/{form}/delete', '\Form\Controllers\FormController@delete')->name('forms.delete');
// Route::post('porms', '\Form\Controllers\FormController@store')->name('porms.store');
Route::resource('forms', '\Form\Controllers\FormController');
