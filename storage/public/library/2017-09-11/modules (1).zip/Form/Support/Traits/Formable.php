<?php

namespace Form\Support\Traits;

use Closure;

/**
 * Attachable to any Model
 * Trait to use for using Polymorphic Relationship
 *
 */
trait Formable
{
    protected $class = 'Form\Models\Form';
    protected $morphable = 'formable';

    public function forms()
    {
        return $this->morphMany( $this->class, $this->morphable );
    }
}