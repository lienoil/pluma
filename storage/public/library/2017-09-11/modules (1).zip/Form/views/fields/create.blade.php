@extends("Pluma::layouts.admin")

@section("title", 'Create Field')

@section("content")

    <div class="container-fluid">
        <form action="{{ route('fields.store') }}" method="POST">
            {{ csrf_field() }}
            <div class="row">
                <div class="col-md-9">
                    <div class="box no-border">
                        <div class="box-header with-border">
                            <h3 class="box-title">New Field</h3>
                        </div>

                        <div class="box-body">
                            <div class="input-field col s12">
                                <input type="text" name="title" class="validate inputfield m-b-0" value="{{ old('title') }}" data-slugger>
                                <label class="inputtext" for="title">Title</label>
                                @include("Pluma::errors.span", ['field' => 'title'])
                            </div>

                            <div class="input-field col s12 m-t-4">
                                <input type="text" name="name" class="validate inputfield m-b-0" value="{{ old('name') }}">
                                <label class="inputtext" for="name">Name</label>
                                @include("Pluma::errors.span", ['field' => 'name'])
                            </div>

                            <div class="input-field col s12 m-t-4">
                                <input type="text" name="label" class="validate inputfield m-b-0" value="{{ old('label') }}">
                                <label class="inputtext" for="label">Label</label>
                                @include("Pluma::errors.span", ['field' => 'label'])
                            </div>

                            <div class="input-field col s12 m-t-4">
                                <select name="type" class="select inputfield">
                                    <option value="" disabled selected>Choose Type</option>
                                    @foreach ($types as $key => $value)
                                        <option value="{{ $key }}" {{ old('type') == $key ? 'selected="selected"' : "" }}>{{ $value }}</option>
                                    @endforeach
                                </select>
                                <label class="inputtext" for="type">Type</label>
                                @include("Pluma::errors.span", ['field' => 'type'])
                            </div>

                            <div class="input-field col s12 m-t-4">
                                <input type="text" name="value" class="validate inputfield m-b-0" value="{{ old('value') }}">
                                <label class="inputtext" for="value">Value</label>
                                @include("Pluma::errors.span", ['field' => 'value'])
                            </div>
                        </div>

                        <div class="box-header with-border">
                            <h5 class="box-title">Attributes</h5>
                        </div>
                        <div class="box-body">
                            <div class="clonable-block" data-toggle="cloner">
                                <div class="input-field">
                                    <div class="clonable row">
                                        <div class="col-xs-5">
                                            <div class="input-field">
                                                <input type="text" name="attrs[0][key]" class="validate inputfield m-b-0 clonable-increment-name">
                                            </div>
                                        </div>

                                        <div class="col-xs-6">
                                            <div class="input-field">
                                                <input type="text" name="attrs[0][value]" class="validate inputfield m-b-0 clonable-increment-name">
                                            </div>
                                        </div>

                                        <div class="col-xs-1">
                                            <button type="button" class="no-border no-bg clonable-button-close">
                                                <i class="fa fa-close"></i>
                                            </button>
                                        </div>
                                    </div>
                                    @include("Pluma::errors.span", ['field' => 'attr'])
                                </div>
                                <div class="card-action text-center">
                                    <button class="activator clonable-button-add" type="button">Add Attribute</button>
                                </div>
                            </div>
                        </div>

                        <div class="box-header with-border">
                            <h5 class="box-title">Rules</h5>
                        </div>

                        <div class="box-body">
                            <div class="clonable-block" data-toggle="cloner">
                                <div class="input-field">
                                    <div class="clonable row">
                                        <div class="col-xs-5">
                                            <div class="input-field">
                                                <input type="text" name="rules[0][value]" class="validate inputfield m-b-0 clonable-increment-name">
                                            </div>
                                        </div>

                                        <div class="col-xs-6">
                                            <div class="input-field">
                                                <input type="text" name="rules[0][message]" class="validate inputfield m-b-0 clonable-increment-name">
                                            </div>
                                        </div>

                                        <div class="col-xs-1">
                                            <button type="button" class="no-border no-bg clonable-button-close"><i class="fa fa-close"></i></button>
                                        </div>

                                    </div>
                                    @include("Pluma::errors.span", ['field' => 'rules'])
                                </div>

                                <div class="card-action">
                                    <button class="activator m-t-2 clonable-button-add" type="button">Add Rule</button>
                                </div>
                                {{-- <div class="col-md-4">
                                    <div class="input-field-x">
                                        <select name="rules[0][key]" class="clonable-increment-name">
                                            @foreach ( $rules as $key => $value )
                                                <option value="{{ $key }}">{{ $value }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div> --}}
                            </div>
                        </div>

                    </div>
                </div>

                <div class="col-md-3">
                    @include("Pluma::partials.widget-saving")
                </div>

            </div>
        </form>
    </div>

@endsection

@section("pre-footer")
    @include("Pluma::partials.alert")
@endsection

@push("js")
    <script src="{{ assets('Pluma/vendor/jquery-slugger/dist/jquery.slugger.min.js') }}"></script>
    <script src="{{ assets('Pluma/vendor/jquery-cloner/dist/jquery.cloner.min.js') }}"></script>
    <script>
        $('[data-slugger]').slugger({
            target: '[name=label]',
            separator: " ",
            convertToLowerCase: false,
        });
        $('[data-slugger]').slugger({
            target: '[name=name]',
            separator: "_",
        })
        $(document).ready(function() {
            $('.select').material_select();
        });
    </script>
@endpush