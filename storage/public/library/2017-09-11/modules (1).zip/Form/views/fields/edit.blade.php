@extends("Pluma::layouts.admin")
@section("title", 'Edit Field')
@section("content")

    <div class="container-fluid">
        <form action="{{ route('fields.update', $resource->id) }}" method="POST">
            {{ csrf_field() }}
            {{ method_field('PUT') }}
            <div class="row">
                <div class="col-md-9">
                   <div class="box no-border">
                       <div class="box-header with-border">
                            <h3 class="box-title">Edit Field</h3>
                        </div>

                        <div class="box-body">
                            <div class="input-field">
                                <input type="text" name="title" class="validate inputfield" value="{{ $resource->title }}" placeholder="Title" data-slugger>
                                @include("Pluma::errors.span", ['field' => 'title'])
                            </div>

                            <div class="input-field">
                                <input type="text" name="name" class="validate inputfield" value="{{ $resource->name }}" placeholder="Name">
                                @include("Pluma::errors.span", ['field' => 'name'])
                            </div>

                            <div class="input-field">
                                <input type="text" name="label" class="validate inputfield" value="{{ $resource->label }}" placeholder="Label">
                                @include("Pluma::errors.span", ['field' => 'label'])
                            </div>

                            <div class="input-field">
                                <select name="type" class="select">
                                    @foreach ( $types as $key => $value )
                                        <option value="{{ $key }}" {{ $resource->type == $key ? 'selected="selected"' : "" }}>{{ $value }}</option>
                                    @endforeach
                                </select>
                                @include("Pluma::errors.span", ['field' => 'type'])
                            </div>

                            <div class="input-field">
                                <input type="text" name="value" class="validate inputfield" value="{{ $resource->value }}" placeholder="Default value">
                                @include("Pluma::errors.span", ['field' => 'value'])
                            </div>
                        </div>

                        <div class="box-header with-border">
                            <h3 class="box-title">Attributes</h3>
                        </div>

                        <div class="box-body">
                            <div class="clonable-block" data-toggle="cloner">
                                <div class="input-field">
                                    @if ( count( $resource->attr ) <= 0 )

                                        <div class="clonable row">
                                            <div class="col-md-5">
                                                <div class="input-field">
                                                    <input type="text" name="attr[0][key]" class="validate inputfield clonable-increment-name" placeholder="key">
                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="input-field">
                                                    <input type="text" name="attr[0][value]" class="validate inputfield clonable-increment-name" placeholder="value">
                                                </div>
                                            </div>

                                            <div class="col-md-1">
                                                <button type="button" class="no-bg no-border clonable-button-close"><i class="fa fa-close"></i></button>
                                            </div>
                                        </div>

                                    @else

                                        @foreach ( $resource->attributes as $i => $attr )
                                            <div class="clonable row">
                                                <div class="col-md-5">
                                                    <div class="input-field">
                                                        <input type="text" name="attr[{{ $i }}][key]" class="validate inputfield clonable-increment-name" value="{{ $attr['key'] }}" placeholder="key">
                                                    </div>
                                                </div>

                                                <div class="col-md-6">
                                                    <div class="input-field">
                                                        <input type="text" name="attr[{{ $i }}][value]" class="validate inputfield clonable-increment-name" value="{{ $attr['value'] }}" placeholder="value">
                                                    </div>
                                                </div>

                                                <div class="col-md-1">
                                                    <button type="button" class="no-bg no-border clonable-button-close"><i class="fa fa-close"></i></button>
                                                </div>
                                            </div>
                                        @endforeach

                                    @endif
                                </div>

                                <button class="waves-effect waves-yellow btn btn-default m-t-1 clonable-button-add" type="button">Add Attribute</button>
                            </div>
                        </div>

                        <div class="box-body">
                            <div class="clonable-block" data-toggle="cloner">
                                <div class="input-field">

                                    @if ( empty( $resource->rules ) && count( $resource->rules ) <= 0 )

                                        <div class="clonable row">
                                           {{--  <div class="col-md-4">
                                                <div class="input-field">
                                                    <select name="rules[0][key]" class="clonable-increment-name">
                                                        @foreach ( $rules as $key => $value )
                                                            <option value="{{ $key }}">{{ $value }}</option>
                                                        @endforeach
                                                    </select>
                                                </div>
                                            </div> --}}

                                            <div class="col-md-5">
                                                <div class="input-field">
                                                    <input type="text" name="rules[0][value]" class="validate inputfield clonable-increment-name" placeholder="value">
                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="input-field">
                                                    <input type="text" name="rules[0][message]" class="validate inputfield clonable-increment-name" placeholder="Message">
                                                </div>
                                            </div>

                                            <div class="col-md-1">
                                                <button type="button" class="no-bg no-border clonable-button-close"><i class="fa fa-close"></i></button>
                                            </div>

                                        </div>

                                    @else

                                        @foreach ( unserialize( $resource->rules ) as $i => $rule )

                                            <div class="clonable row">
                                                <div class="col-sm-12">
                                                    <div class="card">
                                                        <div class="card-content row">

                                                           {{--  <div class="col-md-4">
                                                                <div class="input-field">
                                                                    <select name="rules[{{ $i }}][key]" class="validate inputfield clonable-increment-name">
                                                                        @foreach ( $rules as $key => $value )
                                                                            <option value="{{ $key }}" {{ $rule['key'] == $key ? 'selected="selected"' : "" }}>{{ $value }}</option>
                                                                        @endforeach
                                                                    </select>
                                                                </div>
                                                            </div> --}}

                                                            <div class="col-md-3">
                                                                <div class="input-field">
                                                                    <input type="text" name="rules[{{ $i }}][value]" class="validate inputfield clonable-increment-name" placeholder="value" value="{{ $rule['value'] }}">
                                                                </div>
                                                            </div>

                                                            <div class="col-md-4">
                                                                <div class="input-field">
                                                                    <input type="text" name="rules[{{ $i }}][message]" class="validate inputfield clonable-increment-name" placeholder="Message" value="{{ $rule['message'] }}">
                                                                </div>
                                                            </div>

                                                            <div class="col-md-1">
                                                                <button type="button" class="no-bg no-border clonable-button-close"><i class="fa fa-close"></i></button>
                                                            </div>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        @endforeach
                                    @endif
                                    @include("Pluma::errors.span", ['field' => 'rules'])
                                </div>
                                <button class="waves-effect waves-yellow btn btn-default m-t-1 clonable-button-add" type="button">Add Rule</button>
                            </div>
                        </div>
                   </div>
                </div>
                <div class="col-md-3">
                    @include("Pluma::partials.widget-saving")
                </div>
            </div>

        </div>
    </form>
@endsection

@section('pre-footer')
    @include("Pluma::partials.alert")
@endsection

@push("js")
    <script src="{{ assets('Pluma/vendor/jquery-slugger/dist/jquery.slugger.min.js') }}"></script>
    <script src="{{ assets('Pluma/vendor/jquery-cloner/dist/jquery.cloner.min.js') }}"></script>
    <script>
        $('[data-slugger]').slugger({
            target: '[name=label]',
            separator: " ",
            convertToLowerCase: false,
        });

        $('[data-slugger]').slugger({
            target: '[name=name]',
            separator: "_",
        });
        $(document).ready(function() {
            $('.select').material_select();
        });
    </script>
@endpush