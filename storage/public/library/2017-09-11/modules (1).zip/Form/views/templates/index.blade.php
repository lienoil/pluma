@extends("Pluma::layouts.admin")
@section("title", "All Templates")
@section("content")

    <div class="container-fluid">
        @include("Pluma::partials.alert")

        <div class="box no-border">
            <div class="box-header with-border">
                <h3 class="box-title">All Pages</h3>
            </div>
            <div class="box-body p-0">
                <a href="{{ route('templates.create') }}" class="btn waves-effect waves-light btn-yellow m-l-2 m-t-2 m-b-2">Create</a>
                <div class="pull-right m-r-2 m-t-3">
                    @include("Pluma::partials.trash", ['name'=>'templates'])
                </div>
                <div class="clear"></div>

                <div class="table-responsive p-0">
                    <table class="bordered">
                        <thead>
                            <tr>
                                <th><input type="checkbox"></th>
                                <th>Name</th>
                                <th>Created</th>
                                <th>Modified</th>
                            </tr>
                        </thead>
                        <tbody>
                            @if ( $resources->isEmpty() )
                                <tr>
                                    <td colspan="4" class="text-muted text-center">No resource found.</td>
                                </tr>
                            @endif
                            @foreach ( $resources as $i => $resource )
                                <tr>
                                    <td><input type="checkbox"></td>
                                    <td>
                                        {!! $resource->edit_link('templates', $resource->name) !!}
                                        <div class="options-block btn-group">
                                            <a class="btn btn-link btn-sm" href="{{ route('templates.edit', $resource->id) }}"><i class="fa fa-edit">&nbsp;</i>Edit</a>
                                            <a class="btn btn-link btn-sm" href="{{ route('templates.show', $resource->id) }}"><i class="fa fa-eye">&nbsp;</i>Show</a>
                                            @include("Pluma::partials.form-destroy", compact('resource'))
                                        </div>
                                    </td>
                                    <td>{{ $resource->created }}</td>
                                    <td>{{ $resource->modified }}</td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="card-footer">
                <div class="pull-right">
                    @include("Pluma::partials.pagination", compact("resources"))
                </div>
            </div>
        </div>
    </div>
@endsection