@extends("Pluma::layouts.admin")

@section("title", 'Edit Template')

@section("content")

    <div class="container-fluid">
        <div class="col-sm-12">
            <h3 class="page-title">Edit Template</h3>
        </div>
    </div>

    @include("Pluma::partials.alert")

    <form action="{{ route('templates.update', $resource->id) }}" method="POST">
        {{ csrf_field() }}
        {{ method_field('PUT') }}
        <div class="container-fluid">
            <div class="col-lg-9">
                <div class="card">
                    <div class="card-block">

                        <div class="form-group">
                            <input type="text" name="name" class="form-control form-control-dashed" value="{{ $resource->name }}" placeholder="Name" data-slugger>
                            @include("Pluma::errors.span", ['field' => 'name'])
                        </div>

                    </div>

                    <div class="code-editor">
                        <div class="form-group">
                            <textarea data-emmet emmet-syntax-html type="text" name="body" class="form-control form-control-dashed" placeholder="Structure" data-editor-mode="code">{{ $resource->body }}</textarea>
                            @include("Pluma::errors.span", ['field' => 'body'])
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-3">
                @include("Pluma::partials.widget-saving")
            </div>
        </div>
    </form>

@endsection

@push('css')
    {{-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/4.13.0/codemirror.min.css"> --}}
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/9.9.0/styles/monokai-sublime.min.css">
    <link rel="stylesheet" href="{{ assets("Pluma/css/debug.css") }}">
@endpush

@push('js')
    <script src="{{ assets("Pluma/vendor/emmet-textarea/emmet.min.js") }}"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/9.9.0/highlight.min.js"></script>
    <script>
        emmet.require('textarea').setup({
            pretty_break: true, // enable formatted line breaks (when inserting
                                // between opening and closing tag)
            use_tab: true       // expand abbreviations by Tab key
        });
    </script>
@endpush