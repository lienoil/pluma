@extends("Pluma::layouts.admin")

@section("content")
    @include("Pluma::partials.alert")

    <div class="container-fluid">
        <form action="{{ route('templates.store') }}" method="POST">
            <div class="row">
                <div class="col-md-9">
                    {{ csrf_field() }}
                    <div class="box no-border clonable-block" data-toggle="cloner">
                        <div class="box-header with-border">
                            <h3 class="box-title">New Template</h3>
                        </div>
                        <div class="box-body">
                            <div class="input-field">
                                <input type="text" name="name" class="validate inputfield m-b-0" value="{{ old('name') }}" data-slugger>
                                <label class="inputtext slug-form" for="name">Name</label>
                                @include("Pluma::errors.span", ['field' => 'name'])
                            </div>
                        </div>

                        <div class="code-editor">
                            <div class="form-group">
                                <textarea data-emmet emmet-syntax-html type="text" rows="10" name="body" class="form-control form-control-dashed" placeholder="Structure" data-editor-mode="code">{{ old('body') }}</textarea>
                                @include("Pluma::errors.span", ['field' => 'body'])
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-3">
                    @include("Pluma::partials.widget-saving")
                </div>
            </div>
        </form>
    </div>
@endsection


@push('css')
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/9.9.0/styles/monokai-sublime.min.css">
    {{-- <link rel="stylesheet" href="{{ assets("Pluma/css/debug.css") }}"> --}}

    <style>
        .code-editor {
            padding: 20px;
        }
    </style>
@endpush

@push('js')
    <script src="{{ assets("Pluma/vendor/emmet-textarea/emmet.min.js") }}"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/9.9.0/highlight.min.js"></script>
    <script>
        emmet.require('textarea').setup({
            pretty_break: true, // enable formatted line breaks (when inserting
                                // between opening and closing tag)
            use_tab: true       // expand abbreviations by Tab key
        });
    </script>
@endpush