@extends("Pluma::layouts.admin")
{{-- @section("title", 'Create Form') --}}
@section("content")

	<div class="container-fluid">
		<div class="row">
			<div class="col-md-9">
				<div class="box no-border">
					<div class="box-header with-border">
						<h3 class="box-title">Create Form</h3>
					</div>

					<div class="box-body">
						<form action="{{ route('forms.store') }}" method="POST">
							{{ csrf_field() }}

							<div class="input-field">
								<input type="text" name="name" class="validate inputfield m-b-0" value="{{ old('name') }}">
								<label class="inputtext" for="name">Name</label>
								@include("Pluma::errors.span", ['field' => 'name'])
							</div>

							<div class="input-field">
								<select class="inputfield" name="method" placeholder="Form Method" title="Form Method">
									@foreach( $methods as $key => $value )
										<option value="{{ $key }}">{{ $value }}</option>
									@endforeach
								</select>
								@include("Pluma::errors.span", ['field' => 'method'])
							</div>

							<div class="input-field m-t-3">
								<textarea id="description" name="description" cols="30" rows="10" class="materialize-textarea inputfield textarea-rows">{{ old('description') }}</textarea>
								<label class="inputtext" for="name">Description</label>
								@include("Pluma::errors.span", ['field' => 'description'])
							</div>

							<h4 class="box-title">Fields</h4>
							<div class="clonable-block" data-toggle="cloner">
								<div class="input-field">
									<div class="clonable row">
										<div class="col-sm-12 m-b-2">
											<div class="input-field">
												<span for="field_1" class="clonable-increment-for"><small>Field <span class="clonable-increment-text">1</span></small></span>
												{{-- <button class="close btn btn-link clonable-button-close" type="button"><i class="fa fa-close"></i></button> --}}
												<span role="button" class="close pull-right clonable-button-close" data-clone-close=""><i class="material-icons">close</i></span>
											</div>
											<select class="no-border inputfield clonable-increment-name clonable-increment-id clonable-increment-title" id="field_1" name="fields[0]" placeholder="Field 1" title="Field 1">
												@foreach ( $fields as $key => $value )
													<option value="{{ $key }}">{{ $value }}</option>
												@endforeach
											</select>
											@include("Pluma::errors.span", ['field' => 'fields'])
										</div>
									</div>
								</div>
								<div class="text-center m-2">
									<button class="no-bg no-border m-t-1 clonable-button-add text-orange" type="button">Add Field</button>
								</div>
							</div>

							<div class="input-field">
								<select id="template" name="template" class="inputfield">
									{{-- <option value="">Sample Template</option> --}}
									@foreach( $templates as $key => $value )
										<option value="{{ $key }}">{{ $value }}</option>
									@endforeach
								</select>
								<label class="inputtext" for="">Template</label>
								@include("Pluma::errors.span", ['field' => 'template'])
							</div>
						</form>
					</div>
				</div>
			</div>

			<div class="col-md-3">
				@include("Pluma::partials.widget-saving")
			</div>
		</div>
@endsection

@section("pre-footer")
	@include("Pluma::partials.alert")
@endsection

@push('css')
	<style>
		.select-wrapper .select-dropdown {
            margin-bottom: 0 !important;
        }
	</style>
@endpush

@push("js")
	<script src="{{ assets('Pluma/vendor/jquery-cloner/dist/jquery.cloner.min.js') }}"></script>
	<script>
		$(document).ready(function() {
    		$('select').material_select();
  		});
	</script>
@endpush