@extends("Pluma::layouts.admin")

@section("content")

	<div class="container-fluid">
		<div class="card">
			<div class="card-header box-header">
				<h3 class="box-title">All Forms</h3>
			</div>
			<div class="box-body p-0">
				<a href="{{ route('forms.create') }}" class="btn waves-effect waves-light btn-yellow m-l-2 m-t-2 m-b-2">Create</a>

				<div class="pull-right m-r-2 m-t-3">
                    @include("Pluma::partials.trash", ['name' => 'forms'])
                </div>

                <div class="table-responsive p-0">
					<table class="bordered">
						<thead>
							<tr class="p-l-2">
								<th class="p-l-2">Title</th>
								<th>Excerpt</th>
								<th>Created</th>
								<th>Modified</th>
								<th><span class="sr-only">Actions</span></th>
							</tr>
						</thead>
						<tbody>
							@if ( $resources->isEmpty() )
								<tr>
									<td colspan="4" class="p-l-2 text-muted text-center">No resource found.</td>
								</tr>
							@endif
							@foreach ( $resources as $i => $resource )
								<tr class="tline p-l-2 p-r-2">
									<td class="p-l-2">
										<a href="{{ route('forms.edit', $resource->id) }}">{{ $resource->title }}</a>
									</td>
									<td>{{ $resource->created }}</td>
									<td>{{ $resource->modified }}</td>
									{{-- btn --}}
									<td width="20" class="mailbox-name reveal-btn">
										<a class="delete-btn" data-toggle="tooltip" data-placement="top" title="show" href="{{ route('forms.show', $resource->id) }}"><i class="fa fa-eye"></i></a>
									</td>
									<td width="20" class="mailbox-name reveal-btn">
										<a class="delete-btn" data-toggle="tooltip" data-placement="top" title="edit" href="{{ route('forms.edit', $resource->id) }}"><i class="fa fa-edit"></i></a>
									</td>
									<td width="20" class="mailbox-name reveal-btn">
										<form class="form-inline" action="{{ route('forms.destroy', $resource->id) }}" method="POST">
											{{ csrf_field() }}
											{{ method_field('DELETE') }}
											<button type="submit" class="btn btn-link btn-sm btn-confirm" data-swal='{"title":"Are you sure?","text":"{{ $resource->name }} announcement will be moved to Trash.","type":"warning","showCancelButton":"true","confirmButtonText":"Remove"}'><i class="fa fa-trash">&nbsp;</i>Trash</button>
										</form>
									</td>
								</tr>
							@endforeach
						</tbody>
					</table>
				</div>
			</div>
			<div class="card-footer">
				<div class="pull-right">
					@include("Pluma::partials.pagination", compact('resources'))
				</div>
			</div>
		</div>
	</div>
@endsection

@push('post-footer')
	@include("Pluma::partials.alert")
@endpush