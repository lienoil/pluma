@extends("Pluma::layouts.admin")

@section("title", "$resource->name")

@section("content")

    <div class="container-fluid">
        <div class="col-sm-12">
            <h3 class="page-title">{{ $resource->name }}</h3>
        </div>
    </div>

    @include("Pluma::partials.alert")


    <div class="container-fluid">
        <div class="col-lg-9">
            <div class="card">
                <div class="card-block">

                    {!! $form !!}

                </div>
                <div class="card-footer text-xs-right">
                    <a href="{{ route('forms.edit', $resource->id) }}" class="btn btn-success"><i class="fa fa-edit">&nbsp;</i>Edit</a>
                    <a href="{{ route('forms.destroy', $resource->id) }}" class="btn btn-danger"><i class="fa fa-trash">&nbsp;</i>Delete</a>
                </div>
            </div>
        </div>

    </div>

@endsection
