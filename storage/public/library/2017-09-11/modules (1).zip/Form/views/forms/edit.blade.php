@extends("Pluma::layouts.admin")

@section("title", 'Edit Form')

@section("content")

    <div class="container-fluid">
        <div class="col-sm-12">
            <h3 class="page-title">Edit Form</h3>
        </div>
    </div>

    @include("Pluma::partials.alert")

    <form action="{{ route('forms.update', $resource->id) }}" method="POST">
        {{ csrf_field() }}
        {{ method_field('PUT') }}
        <div class="container-fluid">
            <div class="col-lg-9">
                <div class="card">
                    <div class="card-block">

                        <div class="form-group">
                            <input type="text" name="name" class="form-control form-control-dashed" value="{{ $resource->name }}" placeholder="Title">
                            @include("Pluma::errors.span", ['field' => 'name'])
                        </div>

                        <div class="form-group">
                            <select type="text" class="form-control form-control-dashed" name="method" placeholder="Form Method" title="Form Method">
                                @foreach( $methods as $key => $value )
                                    <option value="{{ $key }}" {{ $resource->method == $key ? 'selected="selected"' : "" }}>{{ $value }}</option>
                                @endforeach
                            </select>
                            @include("Pluma::errors.span", ['field' => 'method'])
                        </div>

                    </div>
                    <div class="card-block card-item">

                        <div class="form-group">
                            <textarea id="description" name="description" cols="30" rows="10" class="form-control form-control-dashed post-description" placeholder="Description">{{ $resource->description }}</textarea>
                            @include("Pluma::errors.span", ['field' => 'description'])
                        </div>

                    </div>

                    <div class="card-block card-item">
                        <h5 class="header-title text-muted">Fields</h5>

                        <div class="clonable-block" data-toggle="cloner-x" id="cloner">
                            <div class="form-group">

                                @if ( ! $resource->fields || count( $resource->fields ) == 0 )
                                    <div class="clonable row">
                                        <div class="col-sm-12">
                                            <div class="card card-item">
                                                <div class="card-block">
                                                    <div class="form-group">
                                                        <label for="field_1" class="clonable-increment-for">Field <span class="clonable-increment-text">1</span></label>
                                                        <button class="close btn btn-link clonable-button-close" type="button"><i class="fa fa-close"></i></button>
                                                    </div>
                                                    <select class="form-control form-control-dashed clonable-increment-name clonable-increment-id clonable-increment-title" id="field_1" name="fields[0]" title="Field 1">
                                                        @foreach ( $fields as $key => $value )
                                                            <option value="{{ $key }}">{{ $value }}</option>
                                                        @endforeach
                                                    </select>
                                                    {{-- <input type="hidden" class="clonable-increment-name clonable-increment-value" name="fields[0][sort]" value="1"> --}}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                @else
                                    @foreach ( $resource->fields as $i => $field )
                                        <div class="clonable row">
                                            <div class="col-sm-12">
                                                <div class="card card-item">
                                                    <div class="card-block">
                                                        <div class="form-group">
                                                            <label for="field_{{ $i+1 }}" class="clonable-increment-for">Field <span class="clonable-increment-text">{{ $i+1 }}</span></label>
                                                            <button class="close btn btn-link clonable-button-close" type="button"><i class="fa fa-close"></i></button>
                                                        </div>
                                                        <select class="form-control form-control-dashed clonable-increment-name clonable-increment-id clonable-increment-title" id="field_{{ $i+1 }}" name="fields[{{ $i }}]" title="Field {{ $i+1 }}">
                                                            @foreach ( $fields as $key => $value )
                                                                <option value="{{ $key }}" {{ $field->id == $key ? 'selected="selected"' : "" }}>{{ $value }}</option>
                                                            @endforeach
                                                        </select>
                                                        {{-- <input type="hidden" class="clonable-increment-name clonable-increment-value" name="fields[{{ $i }}][sort]" value="{{ $field->pivot->sort }}"> --}}
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    @endforeach
                                @endif

                                @include("Pluma::errors.span", ['field' => 'fields'])
                            </div>

                            <button class="btn btn-secondary clonable-button-add" type="button">Add Field</button>
                        </div>
                    </div>

                    <div class="card-block card-item">

                        <div class="form-group">
                            <label for="template" class="header-title text-muted"><strong>Template</strong></label>
                            <select id="template" class="form-control form-control-dashed" name="template" placeholder="Form Template" title="Form Template">
                                @foreach( $templates as $key => $value )
                                    <option value="{{ $key }}" {{ $resource->template->id == $key ? 'selected="selected"' : "" }}>{{ $value }}</option>
                                @endforeach
                            </select>
                            @include("Pluma::errors.span", ['field' => 'template'])
                        </div>

                    </div>

                </div>
            </div>

            <div class="col-lg-3">
                @include("Pluma::partials.widget-saving")
            </div>
        </div>
    </form>

@endsection

@push("js")
    <script src="{{ assets('Pluma/vendor/jquery-cloner/dist/jquery.cloner.min.js') }}"></script>
    <script>
        jQuery('#cloner').cloner({
            clearValueOnClone: false,
        });
    </script>
@endpush