<?php

namespace Form\Models;

use Form\Models\Form;
use Pluma\Models\Model;

class Template extends Model
{

    /**
     * The model that belongs to this model.
     *
     * @return \Form\Models\Form
     */
    public function forms()
    {
        return $this->hasMany( Form::class );
    }

}