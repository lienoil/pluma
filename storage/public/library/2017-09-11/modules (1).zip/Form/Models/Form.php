<?php

namespace Form\Models;

use Form\Models\Field;
use Form\Models\Template;
use Form\Support\Traits\Formable;
use Illuminate\Database\Eloquent\SoftDeletes;
use Pluma\Models\Model;

class Form extends Model
{
	use Formable, SoftDeletes;

    /**
     * The model that belongs to this model.
     *
     * @return \Form\Models\Form
     */
    public function fields()
    {
        return $this->belongsToMany( Field::class )->withPivot('sort');
    }

    /**
     * The model that belongs to this model.
     *
     * @return \Form\Models\Form
     */
    public function template()
    {
        return $this->belongsTo( Template::class );
    }

    public function getThumbnailAttribute()
    {
        return "https://www.quatral.com/wp-content/uploads/2016/03/google-forms-512.png";
    }

}