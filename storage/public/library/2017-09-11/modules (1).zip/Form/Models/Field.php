<?php

namespace Form\Models;

use Pluma\Models\Model;
use Form\Models\Form;

class Field extends Model
{

    public static $types = [
        'text' => 'Text Field',
        'select' => 'Select Field',
        'email' => 'Email Field',
        'textarea' => 'Textarea Field',
        'date' => 'Date Field',
        'checkbox' => 'Checkbox Field',
        'radio' => 'Radio Field',
    ];

    public static $rules = [
        'required' => 'Is required',
        'email' => 'Is email',
        'alphanumeric' => 'Is alphanumeric',
        'url' => 'Is URL',
        'date' => 'Is date',
        'time' => 'Is time',
        'datetime' => 'Is datetime',
        'rangelength' => 'Range length',
        'minchar' => 'Minimum character length',
        'maxchar' => 'Maximum character length',
        'minword' => 'Minimum word length',
        'maxword' => 'Maximum word length',
        'decimal' => 'Decimal',
        'numberonly' => 'Digits only',
    ];

    /**
     * The model that belongs to this model.
     *
     * @return \Form\Models\Field
     */
    public function forms()
    {
        return $this->belongsToMany( Form::class );
    }

    public function getAttributesAttribute()
    {
        return unserialize( $this->attr );
    }

    public function getRulesToArrayAttribute()
    {
        return unserialize( $this->rules );
    }

    public function AttrToHtml()
    {
        $attributes = unserialize( $this->attr );
        $html = "";

        foreach ( $attributes as $attribute ) {
            if ( ! empty( $attribute ) && "" != $attribute['key'] ) {
                $key = $attribute['key'];
                $value = $attribute['value'];
                $html .= "$key='$value'";
            }
        }

        return $html;
    }
}