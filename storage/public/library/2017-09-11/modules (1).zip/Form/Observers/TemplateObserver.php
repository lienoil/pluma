<?php

namespace Form\Observers;

use Form\Models\Template;

class TemplateObserver
{
    /**
     * Listen to the Template created event.
     *
     * @param  Template  $template
     * @return void
     */
    public function created(Template $template)
    {
        // save templates
        session()->flash('title', $template->title);
        session()->flash('icon', "fa fa-check");
        session()->flash('message', "Template successfully saved");
        session()->flash('type', 'info');
    }

    /**
     * Listen to the Template updated event.
     *
     * @param  Template  $template
     * @return void
     */
    public function updated(Template $template)
    {
        session()->flash('title', $template->title);
        session()->flash('icon', "fa fa-check");
        session()->flash('message', "Template successfully updated");
        session()->flash('type', 'info');
    }

    /**
     * Listen to the Template deleted event.
     *
     * @param  Template  $template
     * @return void
     */
    public function deleted(Template $template)
    {
        session()->flash('title', $template->title);
        session()->flash('icon', "fa fa-check");
        session()->flash('message', "Template successfully moved to trash");
        session()->flash('type', 'info');
    }

    /**
     * Listen to the Template restored event.
     *
     * @param  Template  $template
     * @return void
     */
    public function restored(Template $template)
    {
        session()->flash('title', $template->title);
        session()->flash('icon', "fa fa-check");
        session()->flash('message', "Template successfully restored");
        session()->flash('type', 'info');
    }
}