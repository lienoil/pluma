<?php

namespace Form\Observers;

use Form\Models\Form;
use Form\Requests\FormRequest;

class FormObserver
{
	/**
	 * Listen to the Form created event.
	 *
	 * @param  Form  $form
	 * @return void
	 */
	public function created(Form $form)
	{
		// save fields
		session()->flash('title', $form->title);
		session()->flash('icon', "fa fa-check");
		session()->flash('message', "Form successfully saved");
		session()->flash('type', 'info');
	}

	/**
	 * Listen to the Form updated event.
	 *
	 * @param  Form  $form
	 * @return void
	 */
	public function updated(Form $form)
	{
		session()->flash('title', $form->title);
		session()->flash('icon', "fa fa-check");
		session()->flash('message', "Form successfully updated");
		session()->flash('type', 'info');
	}

	/**
	 * Listen to the Form deleted event.
	 *
	 * @param  Form  $form
	 * @return void
	 */
	public function deleted(Form $form)
	{
		session()->flash('title', $form->title);
		session()->flash('icon', "fa fa-check");
		session()->flash('message', "Form successfully removed");
		session()->flash('type', 'info');
	}

	/**
	 * Listen to the Form restored event.
	 *
	 * @param  Form  $form
	 * @return void
	 */
	public function restored(Form $form)
	{
		session()->flash('title', $form->title);
		session()->flash('icon', "fa fa-check");
		session()->flash('message', "Form successfully restored");
		session()->flash('type', 'info');
	}
}