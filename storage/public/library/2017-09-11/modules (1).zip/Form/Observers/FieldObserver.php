<?php

namespace Form\Observers;

use Form\Models\Field;

class FieldObserver
{
    /**
     * Listen to the Field created event.
     *
     * @param  Field  $field
     * @return void
     */
    public function created(Field $field)
    {
        // save fields
        session()->flash('title', $field->title);
        session()->flash('icon', "fa fa-check");
        session()->flash('message', "Field successfully saved");
        session()->flash('type', 'info');
    }

    /**
     * Listen to the Field updated event.
     *
     * @param  Field  $field
     * @return void
     */
    public function updated(Field $field)
    {
        session()->flash('title', $field->title);
        session()->flash('icon', "fa fa-check");
        session()->flash('message', "Field successfully updated");
        session()->flash('type', 'info');
    }

    /**
     * Listen to the Field deleted event.
     *
     * @param  Field  $field
     * @return void
     */
    public function deleted(Field $field)
    {
        session()->flash('title', $field->title);
        session()->flash('icon', "fa fa-check");
        session()->flash('message', "Field successfully moved to trash");
        session()->flash('type', 'info');
    }

    /**
     * Listen to the Field restored event.
     *
     * @param  Field  $field
     * @return void
     */
    public function restored(Field $field)
    {
        session()->flash('title', $field->title);
        session()->flash('icon', "fa fa-check");
        session()->flash('message', "Field successfully restored");
        session()->flash('type', 'info');
    }
}