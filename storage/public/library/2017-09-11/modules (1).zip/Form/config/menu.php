<?php

return [
	/**
	 * Forms
	 *
	 */
	'form' => [
		'name' => 'form',
		'slug' => 'forms',
		'parent' => true,
		// 'is_always_viewable' => true,
		'order' => 70,
		'icon' => [
			'class' => 'icon-form-builder',
			'tag' => 'i',
			'content' => '&nbsp;',
		], // or can be a html string e.g. <span class="fa fa-edit">&nbsp;</span>
		'label' => [
			'singular_name' => 'Form Builder',
			'plural_name' => 'Form Builder',
		],
	],
	'view-form' => [
		'is_child_of' => 'form',
		'name' => 'view-form',
		'slug' => '/',
		// 'is_always_viewable' => true,
		// 'order' => 1,
		'label' => [
			'singular_name' => 'All Form',
			'plural_name' => 'All Forms',
		],
	],
	'create-form' => [
		'is_child_of' => 'form',
		'name' => 'create-form',
		'slug' => 'create',
		// 'is_always_viewable' => true,
		// 'order' => 2,
		'label' => [
			'singular_name' => 'Create Form',
			'plural_name' => 'Create Form',
		],
	],

	/**
	 * Fields
	 *
	 */
	'view-field' => [
		'is_child_of' => 'form',
		'name' => 'view-field',
		'slug' => 'fields',
		// 'before' => '<hr>',
		'icon' => [
			'class' => 'fa fa-check-square-o',
			'tag' => 'i',
			'content' => '&nbsp;',
		],
		'label' => [
			'singular_name' => 'Field',
			'plural_name' => 'Fields',
		],
	],

	/**
	 * Templates
	 *
	 */
	'view-template' => [
		'is_child_of' => 'form',
		'name' => 'view-template',
		'slug' => 'templates',
		// 'before' => '<hr>',
		'icon' => [
			'class' => 'fa fa-file-text-o',
			'tag' => 'i',
			'content' => '&nbsp;',
		],
		'label' => [
			'singular_name' => 'Template',
			'plural_name' => 'Templates',
		],
	],

	/**
	 * Form Trash
	 */
	'trash-form' => [
		'is_child_of' => 'form',
		'name' => 'trash-form',
		'slug' => 'trash',
		// 'before' => '<hr>',
		// 'is_always_viewable' => true,
		// 'order' => 2,
		'icon' => [
			'class' => 'fa fa-trash',
			'tag' => 'i',
			'content' => '&nbsp;',
		],
		'label' => [
			'singular_name' => 'Trash',
			'plural_name' => 'Trash',
		],
	],
];