<?php

namespace Form\Providers;

use Form\Models\Field;
use Form\Models\Form;
use Form\Models\Template;
use Form\Observers\FieldObserver;
use Form\Observers\FormObserver;
use Form\Observers\TemplateObserver;
use Illuminate\Support\ServiceProvider;
use Schema;

/**
 * FormServiceProvider
 * The service provider for the modules. After being registered
 * it will make sure that each of the modules are properly loaded
 * i.e. with their routes, views etc.
 *
 * @author John Lioneil Dionisio <john.dionisio1@gmail.com>
 * @package Pluma
 */
class FormServiceProvider extends ServiceProvider
{
	/**
	 * Will make sure that the required modules have been fully loaded
	 *
	 * @return void
	 */
	public function boot()
	{
		$this->observe();
	}

	/**
	 * Register the application services.
	 *
	 * @return void
	 */
	public function register()
	{
		//
	}

	/**
	 * Observable Models
	 *
	 * @return void
	 */
	public function observe()
	{
		if ( Schema::hasTable('forms') ) {
			Form::observe( FormObserver::class );
		}

		if ( Schema::hasTable('fields') ) {
			Field::observe( FieldObserver::class );
		}

		if ( Schema::hasTable('templates') ) {
			Template::observe( TemplateObserver::class );
		}
	}
}